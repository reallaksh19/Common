import fs from 'fs';
import path from 'path';
import assert from 'assert';
import ts from 'typescript';
import { Pro2D_buildMockState, Pro2D_toSceneBundle, Pro2D_mergeSceneIntoState } from './js/pro2dcanvas/Pro2D_Canonical.mjs';
import { Pro2D_validateState } from './js/pro2dcanvas/Pro2D_ValidationEngine.mjs';
import { Pro2D_runBenchmark } from './js/pro2dcanvas/Pro2D_Benchmark.mjs';
import { Pro2D_exportSimpleSvg } from './js/pro2dcanvas/Pro2D_SvgAdapter.mjs';
import { Pro2D_exportSimpleDxf, Pro2D_importSimpleDxf } from './js/pro2dcanvas/Pro2D_DxfAdapter.mjs';
import { Pro2D_runEmitPipeline, Pro2D_extractPipelineInput } from './js/pro2dcanvas/Pro2D_EmitEngine.mjs';
import { Pro2D_getLeftRailTools } from './js/pro2dcanvas/Pro2D_ToolRegistry.mjs';

const base = path.resolve('.');
const results = [];
function ok(name, detail='PASS') { results.push({name, status:'PASS', detail}); }
function fail(name, err) { results.push({name, status:'FAIL', detail: err?.message || String(err)}); }

try {
  const doc = Pro2D_buildMockState();
  assert(Object.keys(doc.entities).length >= 4);
  const validation = Pro2D_validateState(doc);
  assert(validation.summary.totalEntities >= 4);
  ok('canonical_build_and_validate', JSON.stringify(validation.summary));

  const bundle = Pro2D_toSceneBundle(doc);
  assert(Object.keys(bundle.segments).length >= 2);
  const live = Pro2D_mergeSceneIntoState(doc, bundle);
  assert(Object.keys(live.entities).length >= 2);
  ok('scene_bundle_roundtrip', `${Object.keys(bundle.segments).length} segments`);

  const svg = Pro2D_exportSimpleSvg(doc);
  assert(svg.includes('data-pro2d-id'));
  ok('svg_export_metadata', 'data-pro2d-* preserved');

  const dxf = Pro2D_exportSimpleDxf(bundle);
  assert(dxf.includes('SECTION') && dxf.includes('ENTITIES') && dxf.includes('EOF'));
  const parsed = Pro2D_importSimpleDxf(dxf);
  assert(parsed.length >= 2);
  ok('dxf_minimal_ascii_export_import', `${parsed.length} entities`);

  const metrics = Pro2D_runEmitPipeline(Pro2D_extractPipelineInput(doc)).metrics;
  assert(metrics.routePointCount >= 2 && metrics.finalElementCount >= 2);
  ok('emit_pipeline_live_doc', JSON.stringify(metrics));

  const bench = Pro2D_runBenchmark(doc);
  assert(bench.phase1LoadMs >= 0 && bench.phase3Validate10kMs >= 0);
  ok('benchmark_executes', JSON.stringify(bench));

  const leftTools = Pro2D_getLeftRailTools().map((t) => t.id);
  assert(leftTools[0] === 'pan');
  ['valve','support','flange','fvf','reducer'].forEach((id) => assert(!leftTools.includes(id)));
  ok('left_rail_de_duplicates_fittings', leftTools.join(','));

  const files = fs.readdirSync('./js/pro2dcanvas');
  ['Pro2D_Canonical.mjs','Pro2D_ValidationEngine.mjs','Pro2D_Benchmark.mjs','Pro2D_SvgAdapter.mjs','Pro2D_MockData.mjs','Pro2D_EmitEngine.mjs','Pro2D_RibbonConfig.mjs'].forEach((f) => assert(files.includes(f)));
  ok('missing_modules_added');

  const compileTargets = [
    './js/pro2dcanvas/Pro2D_AppShell.tsx',
    './js/pro2dcanvas/Pro2D_CoorOpsPanel.tsx',
    './js/pro2dcanvas/Pro2D_DebugDock.tsx',
    './js/pro2dcanvas/Pro2D_LeftRail.tsx',
    './js/pro2dcanvas/Pro2D_PropertyPanel.tsx',
    './js/pro2dcanvas/Pro2D_Ribbon.tsx',
    './js/smart2dcanvas/Smart2Dcanvas_CanvasViewport.tsx',
    './js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx',
    './js/smart2dcanvas/Smart2Dcanvas_SceneStore.ts',
    './js/smart2dcanvas/Smart2Dcanvas_SnapEngine.ts',
  ];
  for (const file of compileTargets) {
    const src = fs.readFileSync(file, 'utf8');
    const out = ts.transpileModule(src, { compilerOptions: { jsx: ts.JsxEmit.ReactJSX, module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2020 }, fileName: file, reportDiagnostics: true });
    const syntactic = (out.diagnostics || []).filter((d) => d.category === ts.DiagnosticCategory.Error);
    assert(syntactic.length === 0, `${file}: ${syntactic.map((d) => d.messageText).join('; ')}`);
  }
  ok('tsx_transpile_check', `${compileTargets.length} files`);

  const storeText = fs.readFileSync('./js/smart2dcanvas/Smart2Dcanvas_SceneStore.ts', 'utf8');
  assert(storeText.includes('underlayImages') && storeText.includes('nodes: clone(state.nodes)'));
  assert(storeText.includes('delete state.fittings[id];') && storeText.includes('delete state.underlayImages[id];'));
  ok('scene_store_history_and_delete_coverage');

} catch (err) {
  fail('test_run', err);
}

const failed = results.filter((r) => r.status === 'FAIL');
console.log(JSON.stringify({results, failedCount: failed.length}, null, 2));
if (failed.length) process.exit(1);
