# Revised pass / smoke / benchmark results

- **canonical_build_and_validate**: PASS — {"errors":0,"warnings":0,"totalEntities":4,"totalNodes":3,"totalRoutes":1}
- **scene_bundle_roundtrip**: PASS — 2 segments
- **svg_export_metadata**: PASS — data-pro2d-* preserved
- **dxf_minimal_ascii_export_import**: PASS — 4 entities
- **emit_pipeline_live_doc**: PASS — {"routePointCount":4,"emitCount":2,"autoSupportCount":2,"finalElementCount":5,"totalRouteLength":440,"bore":250}
- **benchmark_executes**: PASS — {"phase1LoadMs":0.001,"phase1ValidateMs":0.009,"phase1SceneBundleMs":0.03,"phase2EmitPipelineMs":0.019,"phase3Load10kMs":10.017,"phase3Validate10kMs":2.67}
- **left_rail_de_duplicates_fittings**: PASS — pan,select,marquee,measure,line,bend,tee,break,connect,stretch,gapClean,overlapSolver,underlay,minimap
- **missing_modules_added**: PASS — PASS
- **tsx_transpile_check**: PASS — 10 files
- **scene_store_history_and_delete_coverage**: PASS — PASS

Smoke verdict: PASS

Notes:
- Tests validate canonical state, live scene merge, SVG/DXF export subset, left-rail de-duplication, missing-module closure, TSX transpilation, and scene-store snapshot/delete coverage.
- These are module-level and integration-structure tests, not full browser Playwright tests.