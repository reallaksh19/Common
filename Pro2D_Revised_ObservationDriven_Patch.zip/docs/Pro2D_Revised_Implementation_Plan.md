# Pro2D Observation-Driven Implementation Plan

This plan is derived from the user observations and the revised patch.

## P0 — Merge-safety and UX cleanup
Goal: make the delta self-contained and remove misleading UI.

Tasks:
1. keep the missing support modules in-tree
2. keep **Pan** first in left rail
3. keep fitting insert commands out of the left rail
4. keep fitting commands only in:
   - ribbon
   - CoorOps / Coor2PCF panel
5. preserve honest implemented/disabled state for bend, tee, repair tools, radar, issues

Done in this patch:
- yes

## P1 — Canonical command wiring
Goal: convert shell-level button activation into real edit commands.

Add:
- `Pro2D_CommandBus`
- `Pro2D_CommandReducer`
- command types:
  - `PIPE_ADD`
  - `PIPE_BREAK`
  - `TEE_INSERT`
  - `BEND_INSERT`
  - `INLINE_INSERT`
  - `SUPPORT_ATTACH`
  - `ENTITY_PATCH`

Required first command implementations:
- valve insert
- flange insert
- reducer insert
- support attach
- break

Reason:
Without a command path, ribbon/rail/operator buttons remain mostly cosmetic.

## P2 — Insertion segmentation logic
Goal: bring forward true CoorCanvas/Coor2PCF authoring behavior.

Required logic:
1. split segment on inline insert
2. place valve/flange/FVF on existing pipe
3. attach support to legal node or station along host segment
4. preserve route continuity when insertion occurs
5. store inserted fitting/support provenance in canonical state

Files to add:
- `Pro2D_InsertEngine.mjs`
- `Pro2D_SegmentSplit.mjs`

## P3 — Bend / tee automation
Goal: close the biggest domain gap from the audit.

Required:
- corner → bend conversion
- intersection → tee/olet conversion
- reducer orientation rules
- branch legality validation
- route continuity recompute

Files to add:
- `Pro2D_BendEngine.mjs`
- `Pro2D_TeeEngine.mjs`

## P4 — Property panel depth
Goal: move from inspector-lite to real editor.

Add typed editors for:
- bore
n- wall thickness
- spec key
- material
- support type
- valve type
- reducer type
- layer
- display label
- dynamic metadata with source badges

Also add:
- dirty state marker
- apply/revert per-entity edit buffer

## P5 — Debug/validation depth
Goal: make audits and smoke tests faster.

Add:
- severity levels
- clear/copy/export log
- benchmark profile selector
- validation by category:
  - connectivity
  - route continuity
  - support anchoring
  - imported metadata integrity

## P6 — Snap and tracing depth
Goal: approach the requested AutoCAD-style workflow.

Add snaps:
- center
- perpendicular
- tangent
- extension
- grid

Add tracing:
- underlay picker
- calibration points
- transform save/load
- opacity/lock UI

## P7 — Browser-level smoke tests
Goal: stop accepting Node-only evidence for UI-heavy changes.

Minimum tests:
1. shell mounts
2. ribbon renders
3. left rail order is correct
4. no fitting duplication in left rail
5. load mock updates viewport
6. property panel follows selection
7. validate button updates debug dock
8. export SVG generates preview
9. export DXF generates preview
10. logs can be filtered and copied

## Recommended sequencing
1. P0 merge-safety and honesty
2. P1 command bus
3. P2 insertion segmentation
4. P3 bend/tee automation
5. P4 property depth
6. P5 validation/debug depth
7. P6 snap/tracing depth
8. P7 browser smoke tests

## Acceptance rule
Do not call the package merge-ready until:
- bend and tee are real
- inline insertion splits segments correctly
- repair tools are no longer placeholders
- browser-level smoke tests exist
- property edits round-trip into canonical state and viewport
