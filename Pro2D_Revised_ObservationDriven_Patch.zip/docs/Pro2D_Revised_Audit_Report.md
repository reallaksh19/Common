# Pro2D Revised Audit Report — Observation-Driven Revision

This revision explicitly incorporates the user observations from `Pasted markdown.md`, especially:
- remove repeated fitting icons from the left panel
- keep **Pan** as the first left-rail icon
- treat the previous delta as **not merge-ready** because of unresolved imports, stale state usage, misleading metrics, weak undo coverage, thin snapping, and pseudo-DXF export. fileciteturn4file0

## 1. What was missed previously

The earlier patch audit identified the broad gaps, but it underweighted five concrete issues that your observations correctly called out:

1. **Left rail information architecture**
   - fitting commands were repeated in both the ribbon/operator panels and the left rail
   - this made the left rail noisy and reduced the clarity of the dedicated CoorCanvas/Coor2PCF operator area

2. **Build completeness as the first gate**
   - the previous delta was still not self-contained because `Pro2D_AppShell.tsx` and `Pro2D_Ribbon.tsx` referenced missing local modules
   - without those files, no “pass/smoke” claim is meaningful

3. **Store/doc split**
   - property panel state was driven from `doc.entities`
   - viewport/store-side edits lived in Zustand state
   - this allowed stale inspector data and weak editor correctness

4. **False-confidence pipeline metrics**
   - emit/support counts were being generated from mock route/mock emits instead of the current document
   - this makes the metrics panel look operational even when it is disconnected from the live scene

5. **Undo/snap/deletion depth**
   - snapshot coverage excluded `nodes` and `underlayImages`
   - selection delete did not cover fittings/underlays/nodes
   - selection cycling only walked segments
   - snap engine only supported endpoint/inline/support

## 2. What the revised patch changes

## A. Build blockers closed
Added the missing modules so the delta is self-contained:
- `js/pro2dcanvas/Pro2D_Canonical.mjs`
- `js/pro2dcanvas/Pro2D_ValidationEngine.mjs`
- `js/pro2dcanvas/Pro2D_Benchmark.mjs`
- `js/pro2dcanvas/Pro2D_SvgAdapter.mjs`
- `js/pro2dcanvas/Pro2D_MockData.mjs`
- `js/pro2dcanvas/Pro2D_EmitEngine.mjs`
- `js/pro2dcanvas/Pro2D_RibbonConfig.mjs`
- `js/smart2dcanvas/Smart2Dcanvas_CanvasViewport.tsx`
- `js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx`

Result: unresolved local imports reduced from **9** to **0**.

## B. Left rail de-duplicated
Per your observation, fitting icons were removed from the left rail:
- removed from left rail: `valve`, `support`, `flange`, `fvf`, `reducer`
- kept in dedicated operator/ribbon surfaces
- `pan` is now the **first left-rail icon**

New left rail order:
- pan
- select
- marquee
- measure
- pipe
- bend
- tee
- break
- connect
- stretch
- gap clean
- overlap
- underlay
- radar

This is the correct split:
- left rail = navigation + drafting + repair mode surface
- CoorOps/ribbon = piping/fitting authoring surface

## C. Live-state property sync
`Pro2D_AppShell.tsx` now derives a **live document** from the current scene store using:
- `Pro2D_mergeSceneIntoState(doc, scene)`

`Pro2D_PropertyPanel.tsx` now reads from the live document and includes basic write-back for:
- `layerId`
- `display.label`
- `routeId`

This does not complete full professional property editing, but it removes the stale-doc correctness defect.

## D. Pipeline metrics now use the current document
The previous mock-only route metrics defect is fixed.

Before:
- pipeline metrics were computed from mock route + mock emits

Now:
- `Pro2D_extractPipelineInput(liveDoc)` derives route/emits from the current document
- `Pro2D_runEmitPipeline(...)` feeds the live metrics panel

This makes Route / Emit metrics more truthful.

## E. Scene store integrity improved
`Smart2Dcanvas_SceneStore.ts` was expanded so that history and delete coverage are materially better.

Changes:
- snapshots now include:
  - `nodes`
  - `segments`
  - `inlineItems`
  - `supports`
  - `fittings`
  - `underlayImages`
- all mutating update/add/remove actions now push history
- `deleteSelected()` now deletes:
  - segments
  - inline items
  - supports
  - fittings
  - underlays
  - nodes
- `selectNext()` / `selectPrev()` now traverse all selectable object categories
- `loadSceneBundle()` now restores `nodes` and `underlayImages`

This does not yet deliver fully acceptance-ready topology editing, but it closes the largest correctness holes.

## F. Snap engine improved
`Smart2Dcanvas_SnapEngine.ts` now supports:
- endpoint
- midpoint
- inline
- support
- nearest
- intersection

This is still not full AutoCAD-level snapping, but it is a meaningful step beyond endpoint-only behavior.

## G. DXF exporter upgraded
The previous exporter wrote a pseudo-CSV-like format inside a DXF-looking wrapper.

Now:
- exporter writes a **minimal ASCII DXF-style ENTITIES section** using group codes
- importer reads that same minimal subset
- fitting type mismatch was corrected to use uppercase fitting types consistently

Important honesty note:
- this is still **minimal DXF subset support**, not a full standards-compliant CAD interchange implementation
- but it is no longer the previous pseudo-format defect

## H. Debug dock strengthened
`Pro2D_DebugDock.tsx` now includes:
- timestamps
- category labels
- info/error filtering
- copy log
- clear log

This still needs export/download and richer severity control later, but it is now materially more useful for audit/debug sessions.

## 3. Revised gap analysis after the patch

## What is now closed
- build completeness gate for local imports
- repeated fitting icons in left rail
- pan-first left rail ordering
- stale doc/property mismatch at the shell level
- false-confidence mock-only pipeline metrics
- weak delete coverage for fittings/underlays/nodes
- missing snapshot coverage for nodes/underlays
- thin snap engine baseline
- ribbon config missing

## What is still incomplete
These remain real gaps and are **not** being overstated as solved:

1. **Bend / tee authoring**
   - still surfaced but not canonically wired

2. **Repair tools**
   - break / connect / stretch / gap clean / overlap solver still need real command pipelines

3. **Professional piping insertion semantics**
   - no true segment split logic for inline valve/flange/support insertion yet
   - no compound FVF insertion semantics yet

4. **Tracing/underlay workflow**
   - viewport can render underlay data if present
   - image picker / calibration workflow is still missing

5. **Minimap/radar**
   - still planned only

6. **Property editor depth**
   - basic write-back exists now, but not full typed engineering editing

7. **Topology graph richness**
   - node/route semantics are improved, but not yet at professional piping graph level

## 4. Acceptance position after the revision

### Quantitative revised posture
- package/build completeness: **5/5 for this local delta package**
- shell/operator surfacing: **4.5/5**
- actual implemented tool behavior: **still ~2.5/5**
- repair/edit implementation: **still low**
- snapping depth: **improved from ~1.5/5 to ~2.5/5**
- undo/redo integrity: **improved from ~1.5/5 to ~3/5**
- property/debug observability: **improved from ~2.5/5 to ~3.5/5**
- overall professional readiness: **still not merge-ready**, but materially stronger than the original delta

## Final verdict
This revised patch is **not the final Pro2D solution**, but it is a much better **integration-safe scaffold** because it now:
- builds as a self-contained delta
- uses live scene-derived metrics
- removes left-rail duplication
- improves store/history correctness
- improves snap depth
- adds concrete debug affordances

It is the right base for the next implementation step.
