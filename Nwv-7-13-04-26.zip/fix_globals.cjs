const fs = require('fs');
let cfg = fs.readFileSync('/app/eslint.config.js', 'utf8');
if (!cfg.includes('globals.node')) {
  cfg = cfg.replace('globals: globals.browser,', 'globals: {\n        ...globals.browser,\n        ...globals.node,\n        ...globals.serviceworker,\n      },');
  fs.writeFileSync('/app/eslint.config.js', cfg);
}
