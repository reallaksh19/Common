const fs = require('fs');

// 1. /app/public/sw.js
let sw = fs.readFileSync('/app/public/sw.js', 'utf8');
sw = sw.replace(/\/\* eslint-env serviceworker \*\/\n/, '');
sw = sw.replace(/catch \(_error\)/g, 'catch (error)'); // Revert previous attempt to avoid used vars issue
sw = sw.replace(/catch \(error\)/g, 'catch (_error)'); // and we will disable no-unused-vars on that line or just remove the param.
sw = sw.replace(/catch \(_error\)/g, 'catch ()'); // Just standard catch () block if ES2019+ is ok, wait, eslint might complain about syntax, let's just use `catch (e) { /* ignore */ }`
sw = sw.replace(/catch \(\)/g, 'catch (_error)');
fs.writeFileSync('/app/public/sw.js', sw);
// Wait, the unused _error will still be flagged unless we configure eslint to allow _ prefix.
// The config already has: argsIgnorePattern: '^_', varsIgnorePattern: '^_'
// Let's check eslint.config.js for that.

// 2. /app/scripts/benchmark_run.js
let benchRun = fs.readFileSync('/app/scripts/benchmark_run.js', 'utf8');
benchRun = benchRun.replace(/const _score = computeImpactScore/g, 'const score = computeImpactScore');
fs.writeFileSync('/app/scripts/benchmark_run.js', benchRun);

// 3. /app/src/App.jsx
let app = fs.readFileSync('/app/src/App.jsx', 'utf8');
app = app.replace(/let timerOut;\n/g, '');
app = app.replace(/timer = setInterval\(\(\) => \{/g, 'const timerOut = setTimeout(() => { timer = setInterval(() => {');
app = app.replace(/\}, 200\);\n    \} else \{/g, '}, 200); }, 0);\n    } else {');
app = app.replace(/return \(\) => clearInterval\(timer\);/g, 'return () => {\n      clearInterval(timer);\n      if (typeof timerOut !== \'undefined\') clearTimeout(timerOut);\n    };');
fs.writeFileSync('/app/src/App.jsx', app);

// 4. /app/src/components/WeatherIcons.jsx
let weatherIcons = fs.readFileSync('/app/src/components/WeatherIcons.jsx', 'utf8');
weatherIcons = weatherIcons.replace(/getIconId,\s*/g, '');
fs.writeFileSync('/app/src/components/WeatherIcons.jsx', weatherIcons);

// 5. /app/src/intelligence/classification.js
let classification = fs.readFileSync('/app/src/intelligence/classification.js', 'utf8');
classification = classification.replace(/const countMatches = /g, '// eslint-disable-next-line no-unused-vars\nconst countMatches = ');
fs.writeFileSync('/app/src/intelligence/classification.js', classification);

