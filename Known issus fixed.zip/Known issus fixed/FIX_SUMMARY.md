# Fix Summary – Known Issues Patch

This patch directly addresses the five known issues called out by the user.

## 1. Asset library and usage tracking

### What changed
- Added `src/components/parent/PageEditor/AssetLibrary.jsx`
- Added `GET /api/list` to the backend for topic-scoped asset browsing
- Added asset upload, replace, delete, preview, tag editing, and “use in block” actions
- Added asset usage scanning via `src/utils/assetUsage.js`
- Added per-topic `assets-manifest.json` support for tags

### Why
Parents were forced to type raw asset paths by hand. The new asset library reduces pathing errors and makes it clear which pages reference a file before deletion or replacement.

## 2. Draft / publish / export indicators

### What changed
- Added `src/services/topicStateService.js`
- Parent pages now record and show:
  - last draft save
  - last published save
  - export count / last export time
- Parent subject and page editors show state indicators

### Why
This makes the content state visible. A parent can now tell whether a topic is only a draft, already saved for student use, or previously exported.

## 3. Version history and undo

### What changed
- Backend now snapshots previous JSON files into `.history/` before overwriting them
- Added `GET /api/history` and `POST /api/restore-version`
- Parent page editor now displays version history and allows restore
- Asset replacement also snapshots the previous asset version before overwrite

### Why
This gives parents a practical undo / rollback path instead of forcing them to fall back to an old ZIP export.

## 4. Slug and topic/page path consistency

### What changed
- Added `src/utils/contentPaths.js`
- Introduced shared helpers for:
  - topic IDs
  - page IDs
  - page slugs
  - page file names
  - subject folder normalization
- Updated loaders and parent routes to use these helpers
- Updated `public/Physics/optics/topic.json` so page file references match actual files
- `jsonContentService` now tries safe fallback candidates if a page file path is stale

### Why
This removes brittle manual assumptions and makes import/export and editor routing more consistent.

## 5. AI provider abstraction

### What changed
- Added `src/services/aiProvider.js`
- `RightSidebar.jsx` now uses `getAiProvider()` instead of calling Gemini directly
- The UI can now switch between a mock provider and Gemini-backed provider without changing component logic

### Why
This reduces coupling and makes it much easier to move later to Firebase AI Logic or a serverless provider route.

## Validation
- `npm run build` completed successfully after the patch.
