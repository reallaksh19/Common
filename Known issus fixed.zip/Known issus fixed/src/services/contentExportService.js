import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { loadTopicWithPages } from './jsonContentService.js';
import { markTopicExported } from './topicStateService.js';

function collectAssetPaths(topic, subjectFolder, topicFolder) {
  const found = new Set();
  const prefix = `/${subjectFolder}/${topicFolder}/assets/`;
  if (topic.coverAssetPath?.startsWith(prefix)) found.add(topic.coverAssetPath);
  (topic._fullPages || []).forEach((pageRef) => {
    const page = pageRef._fullData;
    const scan = (value) => {
      if (!value) return;
      if (typeof value === 'string') {
        if (value.startsWith(prefix)) found.add(value);
        return;
      }
      if (Array.isArray(value)) return value.forEach(scan);
      if (typeof value === 'object') return Object.values(value).forEach(scan);
    };
    scan(page?.blocks || []);
    scan(page?.attachments || []);
  });
  return [...found];
}

export async function exportPack(subjects, topics) {
  const pack = { version: 1, topics: [], pages: {} };
  const zip = new JSZip();

  for (const topicMeta of topics) {
    if (topicMeta.source !== 'json') continue;
    const subjectFolder = topicMeta.subjectFolder || subjects.find((s) => s.id === topicMeta.subjectId)?.folder || subjects.find((s) => s.id === topicMeta.subjectId)?.title || topicMeta.subjectId;
    const topicFolder = topicMeta.folder || topicMeta.id;
    const topic = await loadTopicWithPages(subjectFolder, topicFolder);
    if (!topic) continue;

    const exportTopic = { ...topicMeta, ...topic };
    delete exportTopic._fullPages;
    delete exportTopic.source;
    pack.topics.push(exportTopic);

    for (const page of topic._fullPages || []) {
      if (page._fullData) pack.pages[page.id] = page._fullData;
    }

    const assetPaths = collectAssetPaths(topic, subjectFolder, topicFolder);
    for (const assetPath of assetPaths) {
      try {
        const res = await fetch(assetPath);
        if (!res.ok) continue;
        const blob = await res.blob();
        const filename = assetPath.split('/').pop();
        zip.file(`assets/${topicFolder}/${filename}`, blob);
      } catch {
        // ignore asset fetch failures
      }
    }

    markTopicExported(`${topicMeta.subjectId}/${topicFolder}`);
  }

  zip.file('content-pack.json', JSON.stringify(pack, null, 2));
  const blob = await zip.generateAsync({ type: 'blob' });
  saveAs(blob, 'content-pack.zip');
}
