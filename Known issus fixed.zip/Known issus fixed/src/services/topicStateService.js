const KEY_PREFIX = 'topic_status__';

function key(topicKey) {
  return `${KEY_PREFIX}${topicKey}`;
}

export function getTopicStatus(topicKey) {
  try {
    const raw = localStorage.getItem(key(topicKey));
    return raw ? JSON.parse(raw) : {
      draftSavedAt: null,
      publishedAt: null,
      exportCount: 0,
      exportedAt: null,
      hasDraft: false,
    };
  } catch {
    return {
      draftSavedAt: null,
      publishedAt: null,
      exportCount: 0,
      exportedAt: null,
      hasDraft: false,
    };
  }
}

export function updateTopicStatus(topicKey, patch) {
  const next = { ...getTopicStatus(topicKey), ...patch };
  localStorage.setItem(key(topicKey), JSON.stringify(next));
  return next;
}

export function markTopicDraft(topicKey) {
  return updateTopicStatus(topicKey, {
    draftSavedAt: new Date().toISOString(),
    hasDraft: true,
  });
}

export function markTopicPublished(topicKey) {
  return updateTopicStatus(topicKey, {
    publishedAt: new Date().toISOString(),
    hasDraft: false,
  });
}

export function markTopicExported(topicKey) {
  const current = getTopicStatus(topicKey);
  return updateTopicStatus(topicKey, {
    exportedAt: new Date().toISOString(),
    exportCount: (current.exportCount || 0) + 1,
  });
}

export function formatRelativeTime(iso) {
  if (!iso) return '—';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '—';
  const deltaMin = Math.round((Date.now() - then) / 60000);
  if (deltaMin < 1) return 'just now';
  if (deltaMin < 60) return `${deltaMin} min ago`;
  const deltaHr = Math.round(deltaMin / 60);
  if (deltaHr < 24) return `${deltaHr} hr ago`;
  const deltaDay = Math.round(deltaHr / 24);
  return `${deltaDay} day${deltaDay === 1 ? '' : 's'} ago`;
}
