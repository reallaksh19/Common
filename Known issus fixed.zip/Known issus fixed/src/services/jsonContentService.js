import { getCandidatePageFiles, extractTopicFolder } from '../utils/contentPaths.js';

export async function loadTopic(subject, topicFolder) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/topic.json`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading topic.json for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

export async function loadPage(subject, topicFolder, pageFile) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/${pageFile}`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading ${pageFile} for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

export async function loadTopicWithPages(subject, topicFolder) {
  const topic = await loadTopic(subject, topicFolder);
  if (!topic) return null;

  const fullPages = await Promise.all(
    (topic.pages || []).map(async (pageRef) => {
      let pageData = null;
      const candidates = getCandidatePageFiles(pageRef);
      for (const candidate of candidates) {
        pageData = await loadPage(subject, topicFolder, candidate);
        if (pageData) {
          pageRef = { ...pageRef, file: candidate };
          break;
        }
      }
      return { ...pageRef, _fullData: pageData };
    })
  );

  return {
    ...topic,
    folder: topic.folder || extractTopicFolder({ ...topic, folder: topicFolder }),
    _fullPages: fullPages,
    source: 'json'
  };
}
