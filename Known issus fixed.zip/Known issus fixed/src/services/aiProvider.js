import { callGemini } from './geminiService.js';

function getPageText(pageBlocks = []) {
  return pageBlocks
    .filter((b) => b.type === 'paragraph' || b.type === 'heading')
    .map((b) => b.data?.text || '')
    .join(' ')
    .slice(0, 1500);
}

function createMockProvider() {
  return {
    id: 'mock',
    async summarizePage() {
      return 'Here is a 3-line recap of the page content: This page explains the concept clearly. It shows how it applies in real life. It also points out common mistakes.';
    },
    async explainPage() {
      return 'Think of it like building with blocks. Each small idea combines to make the bigger result easier to understand.';
    },
  };
}

function createGeminiProvider(apiKey) {
  return {
    id: 'gemini',
    async summarizePage({ pageTitle, pageBlocks }) {
      const prompt = `Summarise this page for a student in 3 bullet points. Page title: "${pageTitle}". Content: ${getPageText(pageBlocks)}`;
      return callGemini(prompt, apiKey);
    },
    async explainPage({ pageTitle, pageBlocks }) {
      const prompt = `Explain "${pageTitle}" using a real-world analogy for a student. Content context: ${getPageText(pageBlocks)}`;
      return callGemini(prompt, apiKey);
    },
  };
}

export function getAiProvider(settings = {}) {
  const apiKey = settings.geminiApiKey || '';
  if (!apiKey || apiKey === 'mock-key') {
    return createMockProvider();
  }
  return createGeminiProvider(apiKey);
}
