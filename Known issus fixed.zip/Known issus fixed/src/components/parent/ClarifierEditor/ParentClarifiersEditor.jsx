import React, { useState } from 'react';
import { ClarifierForm } from './ClarifierForm.jsx';
import { generateClarifierId } from '../../../utils/idFactory.js';
import { saveJSON } from '../../../services/parentApiService.js';
import { extractPageSlug } from '../../../utils/contentPaths.js';

export function ParentClarifiersEditor({ subjectId, subjectFolder, topicFolder, topicPages = [] }) {
  const [selectedPageId, setSelectedPageId] = useState(topicPages[0]?.id || null);
  const pageObj = topicPages.find((page) => page.id === selectedPageId);
  const pageSlug = pageObj ? extractPageSlug(pageObj) : selectedPageId;
  const initialClarifiers = pageObj?._fullData?.clarifiers || [];

  const onSave = async (updatedClarifiers) => {
    if (!pageObj) return;
    const updatedPage = { ...pageObj._fullData, clarifiers: updatedClarifiers };
    await saveJSON(`${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`, updatedPage);
    alert('Clarifiers saved!');
  };

  const [clarifiers, setClarifiers] = useState(initialClarifiers);
  const [selectedId, setSelectedId] = useState(null);

  React.useEffect(() => {
    setClarifiers(initialClarifiers);
  }, [selectedPageId]);

  const handleAdd = () => {
    const newId = generateClarifierId(pageSlug, clarifiers.length + 1);
    const newClarifier = { id: newId, type: 'tip', title: 'New Tip', body: '' };
    setClarifiers([...clarifiers, newClarifier]);
    setSelectedId(newId);
  };

  const handleChange = (id, newClarifier) => {
    setClarifiers(clarifiers.map((clarifier) => (clarifier.id === id ? newClarifier : clarifier)));
  };

  return (
    <div>
      <div className="p-4 border-b bg-gray-50 flex items-center">
        <label className="font-bold mr-4">Select Page:</label>
        <select className="border rounded p-2" value={selectedPageId || ''} onChange={(e) => setSelectedPageId(e.target.value)}>
          {topicPages.map((page) => <option key={page.id} value={page.id}>{page.title}</option>)}
        </select>
        <button onClick={() => onSave(clarifiers)} className="ml-auto bg-blue-600 text-white px-4 py-2 rounded font-bold">💾 Save</button>
      </div>
      <div className="flex h-[calc(100vh-180px)] border rounded bg-white overflow-hidden">
        <div className="w-1/3 border-r pr-4 flex flex-col p-4">
          <button onClick={handleAdd} className="w-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold p-2 rounded mb-4">
            + Add Clarifier
          </button>
          <div className="flex-1 overflow-y-auto">
            {clarifiers.map((clarifier) => (
              <div
                key={clarifier.id}
                onClick={() => setSelectedId(clarifier.id)}
                className={`p-3 mb-2 border rounded cursor-pointer ${clarifier.id === selectedId ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
              >
                <div className="text-xs text-gray-500 font-bold uppercase">{clarifier.type}</div>
                <div className="text-sm font-bold">{clarifier.title || '(Untitled)'}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="flex-1 p-4 overflow-y-auto flex flex-col">
          <div className="flex justify-end mb-4">
            <button onClick={() => onSave(clarifiers)} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
              💾 Save Clarifiers
            </button>
          </div>
          <ClarifierForm clarifier={clarifiers.find((clarifier) => clarifier.id === selectedId)} onChange={handleChange} />
        </div>
      </div>
    </div>
  );
}
