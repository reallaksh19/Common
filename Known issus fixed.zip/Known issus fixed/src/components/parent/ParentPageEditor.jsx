import React, { useMemo, useState, useEffect } from 'react';
import { BlockList } from './PageEditor/BlockList.jsx';
import { BlockEditorPanel } from './PageEditor/BlockEditorPanel.jsx';
import { BlockToolbar } from './PageEditor/BlockToolbar.jsx';
import { AssetLibrary } from './PageEditor/AssetLibrary.jsx';
import { generateBlockId } from '../../utils/idFactory.js';
import { getHistory, readJSON, restoreVersion, saveJSON } from '../../services/parentApiService.js';
import { computeAssetUsageMap } from '../../utils/assetUsage.js';
import { markTopicDraft, markTopicPublished, getTopicStatus, formatRelativeTime } from '../../services/topicStateService.js';

export function ParentPageEditor({ subjectId, subjectFolder, topicFolder, pageSlug, topicPages = [], topicTitle = '' }) {
  const [blocks, setBlocks] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [historyEntries, setHistoryEntries] = useState([]);
  const [topicPagesData, setTopicPagesData] = useState(topicPages);

  const topicKey = `${subjectId}/${topicFolder}`;
  const draftKey = `parent_draft__${subjectId}__${topicFolder}__${pageSlug}`;
  const filePath = `${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`;

  const usageMap = useMemo(
    () => computeAssetUsageMap(topicPagesData, `${subjectFolder}/${topicFolder}/assets/`),
    [topicPagesData, subjectFolder, topicFolder]
  );
  const status = getTopicStatus(topicKey);

  const reloadHistory = async () => {
    setHistoryEntries(await getHistory(filePath).catch(() => []));
  };

  const reloadTopicPages = async () => {
    try {
      const topicData = await readJSON(`${subjectFolder}/${topicFolder}/topic.json`);
      const detailed = await Promise.all(
        (topicData.pages || []).map(async (pageRef) => ({
          ...pageRef,
          _fullData: await readJSON(`${subjectFolder}/${topicFolder}/${pageRef.file}`)
            .catch(() => null),
        }))
      );
      setTopicPagesData(detailed.filter((page) => page._fullData));
    } catch {
      setTopicPagesData(topicPages);
    }
  };

  useEffect(() => {
    async function load() {
      const draftStr = localStorage.getItem(draftKey);
      let draftData = null;
      if (draftStr) {
        try {
          draftData = JSON.parse(draftStr);
        } catch {}
      }

      try {
        const fileData = await readJSON(filePath);
        if (draftData && JSON.stringify(draftData) !== JSON.stringify(fileData.blocks)) {
          if (window.confirm('Restore unsaved draft?')) {
            setBlocks(draftData);
            setHasUnsavedChanges(true);
          } else {
            setBlocks(fileData.blocks || []);
            localStorage.removeItem(draftKey);
          }
        } else {
          setBlocks(fileData.blocks || []);
        }
      } catch {
        if (draftData) {
          setBlocks(draftData);
          setHasUnsavedChanges(true);
        }
      }
      reloadHistory();
      reloadTopicPages();
    }
    load();
  }, [filePath, draftKey]);

  useEffect(() => {
    if (!hasUnsavedChanges) return undefined;
    const timer = setInterval(() => {
      localStorage.setItem(draftKey, JSON.stringify(blocks));
      markTopicDraft(topicKey);
    }, 10000);
    return () => clearInterval(timer);
  }, [blocks, hasUnsavedChanges, draftKey, topicKey]);

  const handleSave = async () => {
    try {
      let existing = { id: `${subjectId}-${topicFolder}-${pageSlug}`, title: pageSlug, blocks: [], clarifiers: [], questions: [], attachments: [] };
      try {
        existing = await readJSON(filePath);
      } catch {}
      existing.blocks = blocks;
      await saveJSON(filePath, existing);
      setHasUnsavedChanges(false);
      localStorage.removeItem(draftKey);
      markTopicPublished(topicKey);
      await reloadHistory();
      await reloadTopicPages();
      alert('Saved!');
    } catch {
      alert('Failed to save');
    }
  };

  const handleAddBlock = (type) => {
    const id = generateBlockId(pageSlug, blocks.length + 1);
    const newBlock = { id, type, data: {} };
    const idx = blocks.findIndex((b) => b.id === selectedId);
    const newBlocks = [...blocks];
    if (idx >= 0) newBlocks.splice(idx + 1, 0, newBlock);
    else newBlocks.push(newBlock);
    setBlocks(newBlocks);
    setSelectedId(id);
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const handleBlockChange = (id, newData) => {
    setBlocks(blocks.map((b) => (b.id === id ? { ...b, data: newData } : b)));
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const handleReorder = (oldIndex, newIndex) => {
    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(oldIndex, 1);
    newBlocks.splice(newIndex, 0, moved);
    setBlocks(newBlocks);
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const handleDelete = (id) => {
    setBlocks(blocks.filter((b) => b.id !== id));
    if (selectedId === id) setSelectedId(null);
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const handleDuplicate = (id) => {
    const block = blocks.find((b) => b.id === id);
    if (!block) return;
    const newId = generateBlockId(pageSlug, blocks.length + 1);
    const newBlock = { ...block, id: newId, data: JSON.parse(JSON.stringify(block.data)) };
    const idx = blocks.findIndex((b) => b.id === id);
    const newBlocks = [...blocks];
    newBlocks.splice(idx + 1, 0, newBlock);
    setBlocks(newBlocks);
    setSelectedId(newId);
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const selectedBlock = blocks.find((b) => b.id === selectedId);

  const handleRestoreVersion = async (versionName) => {
    if (!window.confirm('Restore this previous version? Current file will be snapshotted before restore.')) return;
    await restoreVersion(filePath, versionName);
    const restored = await readJSON(filePath);
    setBlocks(restored.blocks || []);
    setHasUnsavedChanges(false);
    localStorage.removeItem(draftKey);
    markTopicPublished(topicKey);
    await reloadHistory();
    await reloadTopicPages();
  };

  return (
    <div className="flex h-[calc(100vh-80px)] gap-4">
      <div className="w-1/4 border-r pr-4 flex flex-col h-full">
        <div className="mb-4">
          <BlockToolbar onAddBlock={handleAddBlock} />
        </div>
        <div className="flex-1 overflow-y-auto">
          <BlockList
            blocks={blocks}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onReorder={handleReorder}
            onDuplicate={handleDuplicate}
            onDelete={handleDelete}
          />
        </div>
      </div>
      <div className="flex-1 pl-2 flex flex-col h-full overflow-y-auto">
        <div className="flex justify-between items-center mb-4 pb-2 border-b">
          <div>
            <div className="text-gray-800 font-bold">{topicTitle || topicFolder} / {pageSlug}</div>
            <div className="text-xs text-gray-500">
              Draft: {status.hasDraft ? formatRelativeTime(status.draftSavedAt) : 'none'} · Published: {formatRelativeTime(status.publishedAt)} · Exported: {status.exportCount || 0} time(s)
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-gray-500 font-bold">
              {hasUnsavedChanges ? <span className="text-amber-500">● Unsaved changes</span> : 'All changes saved'}
            </div>
            <button onClick={handleSave} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
              💾 Save Page
            </button>
          </div>
        </div>
        <BlockEditorPanel
          block={selectedBlock}
          onChange={handleBlockChange}
        />
        <AssetLibrary
          subjectFolder={subjectFolder}
          topicFolder={topicFolder}
          usageMap={usageMap}
          block={selectedBlock}
          onUseAsset={(patch) => handleBlockChange(selectedBlock.id, { ...selectedBlock.data, ...patch })}
        />
      </div>
      <div className="w-80 border-l pl-4 overflow-y-auto">
        <h4 className="font-bold text-sm uppercase text-gray-600 mb-3">Version History</h4>
        <div className="space-y-2">
          {historyEntries.map((entry) => (
            <div key={entry.name} className="border rounded p-3 bg-gray-50">
              <div className="text-sm font-medium break-all">{entry.name}</div>
              <button onClick={() => handleRestoreVersion(entry.name)} className="mt-2 text-xs bg-white border px-2 py-1 rounded">Restore</button>
            </div>
          ))}
          {!historyEntries.length && <div className="text-sm text-gray-500">No prior versions yet.</div>}
        </div>
      </div>
    </div>
  );
}
