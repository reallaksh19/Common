import React, { useState, useEffect, useRef } from 'react';
import JSZip from 'jszip';
import { ContentPackSchema } from '../../content/contentPackSchema.js';
import { checkBackendStatus, createDirectory, saveJSON, uploadAsset } from '../../services/parentApiService.js';
import { exportPack } from '../../services/contentExportService.js';
import { getTopicStatus, formatRelativeTime } from '../../services/topicStateService.js';

export function ParentDashboard({ subjects = [], topics = [] }) {
  const [backendOk, setBackendOk] = useState(true);
  const fileInputRef = useRef(null);
  const [importErrors, setImportErrors] = useState([]);
  const [isImporting, setIsImporting] = useState(false);

  useEffect(() => {
    checkBackendStatus().then((ok) => setBackendOk(ok));
  }, []);

  const handleExport = () => {
    exportPack(subjects, topics);
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsImporting(true);
    setImportErrors([]);

    try {
      const zip = await JSZip.loadAsync(file);
      const contentFile = zip.file('content-pack.json');
      if (!contentFile) throw new Error('content-pack.json not found in zip');

      const pack = JSON.parse(await contentFile.async('string'));
      const validation = ContentPackSchema.safeParse(pack);
      if (!validation.success) {
        setImportErrors(validation.error.errors.map((err) => `${err.path.join('.')}: ${err.message}`));
        setIsImporting(false);
        return;
      }

      const topicFolderById = {};
      const pagePathById = {};
      for (const topic of pack.topics) {
        const subject = subjects.find((s) => s.id.toLowerCase() === topic.subjectId.toLowerCase()) || { title: topic.subjectId, folder: topic.subjectId };
        const subjectFolder = subject.folder || subject.title;
        const topicFolder = topic.folder || (topic.id.includes('-') ? topic.id.split('-').slice(1).join('-') : topic.id);
        topicFolderById[topic.id] = { subjectFolder, topicFolder };
        await createDirectory(`${subjectFolder}/${topicFolder}/pages`);
        await createDirectory(`${subjectFolder}/${topicFolder}/assets`);
        const normalizedPages = (topic.pages || []).map((pageRef) => {
          const normalizedFile = `pages/${pageRef.file?.split('/').pop()}`;
          pagePathById[pageRef.id] = { subjectFolder, topicFolder, file: normalizedFile };
          return { ...pageRef, file: normalizedFile };
        });
        const topicToSave = { ...topic, pages: normalizedPages };
        await saveJSON(`${subjectFolder}/${topicFolder}/topic.json`, topicToSave);
      }

      for (const [pageId, pageData] of Object.entries(pack.pages)) {
        const mapped = pagePathById[pageId];
        const location = mapped || (() => {
          const parts = (pageData.topicId || '').split('-');
          return { subjectFolder: parts[0], topicFolder: parts.slice(1).join('-'), file: `pages/${pageId}.json` };
        })();
        await saveJSON(`${location.subjectFolder}/${location.topicFolder}/${location.file}`, pageData);
      }

      const assetEntries = Object.values(zip.files).filter((entry) => !entry.dir && entry.name.startsWith('assets/'));
      for (const entry of assetEntries) {
        const parts = entry.name.split('/');
        const topicFolder = parts[1];
        const filename = parts.slice(2).join('/');
        const topicLocation = Object.values(topicFolderById).find((info) => info.topicFolder === topicFolder);
        if (!topicLocation || !filename) continue;
        const blob = await entry.async('blob');
        const fileToUpload = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
        await uploadAsset(fileToUpload, `${topicLocation.subjectFolder}/${topicLocation.topicFolder}/assets/${filename}`);
      }

      alert(`Import complete: ${pack.topics.length} topics, ${Object.keys(pack.pages).length} pages restored.`);
      window.location.reload();
    } catch (err) {
      setImportErrors([err.message]);
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div>
      {!backendOk && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 flex items-center shadow-sm">
          <span className="text-2xl mr-3">🔌</span>
          <div>
            <p className="font-bold text-lg">Backend server not running</p>
            <p>Changes cannot be saved to disk. Start the server with <code className="bg-red-200 px-1 rounded">node server.js</code></p>
          </div>
        </div>
      )}

      {importErrors.length > 0 && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 shadow-sm">
          <strong className="font-bold">Import failed:</strong>
          <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
            {importErrors.map((err, i) => <li key={i} className="font-mono">{err}</li>)}
          </ul>
          <button onClick={() => setImportErrors([])} className="mt-3 text-sm underline font-bold hover:text-red-900">Dismiss</button>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Subjects Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {subjects.map((subject) => {
          const subjectTopics = topics.filter((topic) => topic.subjectId === subject.id);
          const pageCount = subjectTopics.reduce((count, topic) => count + (topic.pages?.length || 0), 0);
          const latestStatus = subjectTopics.map((topic) => getTopicStatus(`${subject.id}/${topic.folder || topic.id}`));
          const lastPublished = latestStatus.map((status) => status.publishedAt).filter(Boolean).sort().reverse()[0];
          return (
            <div key={subject.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4 pb-4 border-b">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-xl shadow-sm mr-4" style={{ backgroundColor: subject.color || '#4f46e5' }}>
                  {subject.title === 'Physics' ? '⚛️' : subject.title === 'Mathematics' ? '➗' : subject.title === 'Chemistry' ? '🧪' : '📚'}
                </div>
                <h3 className="text-xl font-bold text-gray-800">{subject.title}</h3>
              </div>
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span className="font-medium">Topics</span>
                <span className="bg-gray-100 px-2 py-0.5 rounded font-bold">{subjectTopics.length}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span className="font-medium">Pages</span>
                <span className="bg-gray-100 px-2 py-0.5 rounded font-bold">{pageCount}</span>
              </div>
              <div className="text-xs text-gray-500 mb-6">Last published: {formatRelativeTime(lastPublished)}</div>
              <a href={`#/parent/subject/${subject.id}`} className="block w-full text-center bg-indigo-50 text-indigo-700 font-bold py-2 rounded hover:bg-indigo-100 transition-colors">
                Manage content →
              </a>
            </div>
          );
        })}
      </div>

      <div className="flex gap-4 border-t pt-6 bg-white p-6 rounded-xl shadow-sm border mt-8">
        <div className="flex-1">
          <h3 className="font-bold text-lg mb-2">Content Operations</h3>
          <p className="text-gray-500 text-sm mb-4">Export your current topics and pages into a portable ZIP pack, or restore from an existing pack.</p>
          <div className="flex gap-4">
            <button onClick={handleExport} className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 flex items-center font-medium bg-white shadow-sm">
              <span className="mr-2 text-indigo-600 font-bold">⬇</span> Export Pack
            </button>
            <button disabled={isImporting} onClick={() => fileInputRef.current?.click()} className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 flex items-center font-medium bg-white shadow-sm">
              <span className="mr-2 text-indigo-600 font-bold">⬆</span> {isImporting ? 'Importing…' : 'Import Pack'}
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept=".zip" onChange={handleImport} />
          </div>
        </div>
      </div>
    </div>
  );
}
