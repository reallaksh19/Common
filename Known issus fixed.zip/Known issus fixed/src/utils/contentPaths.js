import { slugify } from './slugify.js';

export function normalizeSubjectFolder(subject, subjects = []) {
  if (!subject) return '';
  const raw = typeof subject === 'string' ? subject : (subject.folder || subject.title || subject.id || '');
  const byId = subjects.find((s) => s.id === raw || s.title === raw || s.folder === raw);
  if (byId) return byId.folder || byId.title || byId.id;
  return raw;
}

export function buildTopicId(subjectId, topicFolder) {
  return `${subjectId}-${slugify(topicFolder)}`;
}

export function extractTopicFolder(topic = {}) {
  if (topic.folder) return topic.folder;
  if (topic.id && topic.subjectId && topic.id.startsWith(`${topic.subjectId}-`)) {
    return topic.id.slice(topic.subjectId.length + 1);
  }
  if (topic.title) return slugify(topic.title);
  return '';
}

export function buildPageSlug(title = '', fallback = 'page') {
  const s = slugify(title || fallback);
  return s || fallback;
}

export function buildPageId(topicId, pageSlug) {
  return `${topicId}-${pageSlug}`;
}

export function buildPageFile(pageSlug) {
  return `pages/${pageSlug}.json`;
}

export function extractPageSlug(pageRef = {}) {
  if (pageRef.file) {
    const fromFile = pageRef.file.split('/').pop()?.replace(/\.json$/i, '');
    if (fromFile) return fromFile;
  }
  if (pageRef.id && pageRef.topicId && pageRef.id.startsWith(`${pageRef.topicId}-`)) {
    return pageRef.id.slice(pageRef.topicId.length + 1);
  }
  if (pageRef.id) {
    return pageRef.id.split('-').slice(2).join('-') || pageRef.id;
  }
  return buildPageSlug(pageRef.title || 'page');
}

export function getCandidatePageFiles(pageRef = {}) {
  const candidates = new Set();
  if (pageRef.file) candidates.add(pageRef.file);
  const slug = extractPageSlug(pageRef);
  if (slug) candidates.add(buildPageFile(slug));
  if (pageRef.id) candidates.add(buildPageFile(pageRef.id));
  if (pageRef.title) candidates.add(buildPageFile(buildPageSlug(pageRef.title)));
  return [...candidates];
}
