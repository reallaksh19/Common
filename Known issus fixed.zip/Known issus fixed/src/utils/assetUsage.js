function collectStrings(value, out) {
  if (!value) return;
  if (typeof value === 'string') {
    out.push(value);
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((item) => collectStrings(item, out));
    return;
  }
  if (typeof value === 'object') {
    Object.values(value).forEach((item) => collectStrings(item, out));
  }
}

export function computeAssetUsageMap(topicPages = [], assetPrefix = '') {
  const usage = {};
  topicPages.forEach((pageRef) => {
    const page = pageRef?._fullData || pageRef;
    if (!page) return;
    const strings = [];
    collectStrings(page.blocks || [], strings);
    collectStrings(page.attachments || [], strings);
    strings.forEach((value) => {
      if (typeof value !== 'string') return;
      const looksLikeAsset = assetPrefix ? value.includes(assetPrefix) : /assets\//i.test(value);
      if (!looksLikeAsset) return;
      const normalized = value.startsWith('/') ? value.slice(1) : value;
      usage[normalized] = usage[normalized] || [];
      if (!usage[normalized].some((entry) => entry.pageId === page.id)) {
        usage[normalized].push({ pageId: page.id, title: page.title || pageRef?.title || page.id });
      }
    });
  });
  return usage;
}
