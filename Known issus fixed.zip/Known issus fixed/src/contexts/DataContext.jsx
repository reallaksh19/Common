import React, { createContext, useContext, useState, useEffect } from 'react';
import { loadTopicWithPages } from '../services/jsonContentService.js';
import { normalizeSubjectFolder } from '../utils/contentPaths.js';

export const DataContext = createContext({
  subjects: [],
  topics: [],
  loadingState: 'loading'
});

const demoSubjects = [
  { id: 'physics', title: 'Physics', folder: 'Physics', icon: 'FlaskConical', color: '#0ea5e9', order: 1 },
  { id: 'mathematics', title: 'Mathematics', folder: 'Mathematics', icon: 'Calculator', color: '#8b5cf6', order: 2 },
  { id: 'chemistry', title: 'Chemistry', folder: 'chemistry', icon: 'FlaskRound', color: '#ec4899', order: 3 },
  { id: 'biology', title: 'Biology', folder: 'Biology', icon: 'Dna', color: '#10b981', order: 4 },
  { id: 'english', title: 'English', folder: 'English', icon: 'BookOpen', color: '#f59e0b', order: 5 }
];

export const DataProvider = ({ children }) => {
  const [data, setData] = useState({ subjects: demoSubjects, topics: [], loadingState: 'loading' });

  useEffect(() => {
    async function loadData() {
      const loadedTopics = [];

      try {
        const response = await fetch('/api/topics');
        if (response.ok) {
          const topicList = await response.json();
          for (const { subject, topic } of topicList) {
            try {
              const loadedTopic = await loadTopicWithPages(subject, topic);
              if (loadedTopic) {
                const subjectMatch = demoSubjects.find((s) => s.id.toLowerCase() === loadedTopic.subjectId?.toLowerCase())
                  || demoSubjects.find((s) => normalizeSubjectFolder(s) === subject);
                loadedTopic.source = 'json';
                loadedTopic.folder = topic;
                if (subjectMatch) {
                  loadedTopic.subjectId = subjectMatch.id;
                  loadedTopic.subjectFolder = subject;
                }
                loadedTopics.push(loadedTopic);
              }
            } catch (e) {
              console.error(`Error loading topic ${topic} in ${subject}`, e);
            }
          }
        }
      } catch (e) {
        console.warn('Backend not available, trying static fallback', e);
        const knownTopics = {
          Physics: ['Gravity', 'optics'],
          chemistry: ['chemical-kinetics'],
        };

        for (const [subjectFolder, topicFolders] of Object.entries(knownTopics)) {
          for (const topicFolder of topicFolders) {
            try {
              const topic = await loadTopicWithPages(subjectFolder, topicFolder);
              if (topic) {
                topic.source = 'json';
                topic.folder = topicFolder;
                const subjectMatch = demoSubjects.find((s) => normalizeSubjectFolder(s) === subjectFolder || s.id === topic.subjectId);
                if (subjectMatch) topic.subjectId = subjectMatch.id;
                loadedTopics.push(topic);
              }
            } catch {
              // Ignore missing files in static fallback
            }
          }
        }
      }

      setData({
        subjects: demoSubjects,
        topics: loadedTopics,
        loadingState: 'ready'
      });
    }

    loadData();
  }, []);

  return (
    <DataContext.Provider value={data}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => useContext(DataContext);
