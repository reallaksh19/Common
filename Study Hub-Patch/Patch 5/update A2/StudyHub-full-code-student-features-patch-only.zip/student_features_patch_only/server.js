import express from 'express';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { fileURLToPath } from 'url';
import createDOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = 3001;
app.use(express.json());

function getSafePath(relativePath) {
  if (!relativePath) throw new Error('Missing path');
  const publicDir = path.resolve(__dirname, 'public');
  const cleanRelative = relativePath.replace(/^\/+/, '');
  const fullPath = path.resolve(publicDir, cleanRelative);
  if (!fullPath.startsWith(publicDir)) {
    throw new Error('Invalid path: Directory traversal not allowed');
  }
  return fullPath;
}

function ensureJsonFile(relativePath, defaultValue) {
  const fullPath = getSafePath(relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  if (!fs.existsSync(fullPath)) {
    fs.writeFileSync(fullPath, JSON.stringify(defaultValue, null, 2));
  }
  return fullPath;
}

function readJsonFile(relativePath, fallback) {
  try {
    const fullPath = ensureJsonFile(relativePath, fallback);
    return JSON.parse(fs.readFileSync(fullPath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJsonFile(relativePath, data) {
  const fullPath = getSafePath(relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, JSON.stringify(data, null, 2));
  return fullPath;
}

const upload = multer({ dest: 'public/uploads/' });

function writeVersionSnapshot(fullPath) {
  if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) return;
  const parsed = path.parse(fullPath);
  const historyDir = path.join(parsed.dir, '.history');
  fs.mkdirSync(historyDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const versionName = `${parsed.name}__${stamp}${parsed.ext}`;
  fs.copyFileSync(fullPath, path.join(historyDir, versionName));
}

app.get('/api/health', (req, res) => {
  res.json({ success: true });
});

app.post('/api/json', (req, res) => {
  try {
    const { path: relativePath, data } = req.body;
    if (!relativePath || !data) return res.status(400).json({ error: 'Missing path or data' });
    const fullPath = getSafePath(relativePath);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    if (fs.existsSync(fullPath)) writeVersionSnapshot(fullPath);
    fs.writeFileSync(fullPath, JSON.stringify(data, null, 2));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/json', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });
    const fullPath = getSafePath(relativePath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'File not found' });
    const content = fs.readFileSync(fullPath, 'utf8');
    res.json(JSON.parse(content));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/mkdir', (req, res) => {
  try {
    const relativePath = req.body.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });
    const fullPath = getSafePath(relativePath);
    fs.mkdirSync(fullPath, { recursive: true });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });
    const finalPath = req.body.path || (`/uploads/${file.filename}${path.extname(file.originalname)}`);
    const fullPath = getSafePath(finalPath);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    if (fs.existsSync(fullPath)) {
      writeVersionSnapshot(fullPath);
      fs.unlinkSync(fullPath);
    }
    fs.renameSync(file.path, fullPath);
    if (fullPath.endsWith('.svg')) {
      const window = new JSDOM('').window;
      const DOMPurify = createDOMPurify(window);
      let content = fs.readFileSync(fullPath, 'utf8');
      content = DOMPurify.sanitize(content, { USE_PROFILES: { svg: true, svgFilters: true } });
      fs.writeFileSync(fullPath, content);
    }
    res.json({ path: finalPath.startsWith('/') ? finalPath : `/${finalPath}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/file', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });
    const fullPath = getSafePath(relativePath);
    if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/list', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });
    const fullPath = getSafePath(relativePath);
    if (!fs.existsSync(fullPath)) return res.json([]);
    const items = fs.readdirSync(fullPath, { withFileTypes: true }).map((entry) => ({
      name: entry.name,
      type: entry.isDirectory() ? 'directory' : 'file',
      path: `${relativePath.replace(/\/+$/, '')}/${entry.name}`,
    }));
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/student-signals', (req, res) => {
  try {
    const store = readJsonFile('.system/student-signals.json', []);
    let signals = Array.isArray(store) ? store : [];
    const { topicId, pageId, subjectId } = req.query;
    if (subjectId) signals = signals.filter((entry) => entry.subjectId === subjectId);
    if (topicId) signals = signals.filter((entry) => entry.topicId === topicId);
    if (pageId) signals = signals.filter((entry) => entry.pageId === pageId);
    res.json(signals.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/student-signals', (req, res) => {
  try {
    const signal = req.body.signal;
    if (!signal || !signal.topicId || !signal.pageId) return res.status(400).json({ error: 'Incomplete student signal' });
    const store = readJsonFile('.system/student-signals.json', []);
    const next = Array.isArray(store) ? store : [];
    next.push({
      id: signal.id || `signal-${Date.now()}`,
      ...signal,
    });
    writeJsonFile('.system/student-signals.json', next);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/subjects', (req, res) => {
  try {
    const publicDir = path.resolve(__dirname, 'public');
    const subjectsList = [];
    const subjectDirs = fs.readdirSync(publicDir, { withFileTypes: true })
      .filter((dirent) => dirent.isDirectory() && !dirent.name.startsWith('.') && !['uploads', 'dist', 'test'].includes(dirent.name))
      .map((dirent) => dirent.name);
    const defaultColors = ['#0ea5e9', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b'];
    for (let i = 0; i < subjectDirs.length; i += 1) {
      const subject = subjectDirs[i];
      const subjectJsonPath = path.join(publicDir, subject, 'subject.json');
      if (fs.existsSync(subjectJsonPath)) {
        try {
          const content = JSON.parse(fs.readFileSync(subjectJsonPath, 'utf8'));
          subjectsList.push({ id: subject, folder: subject, ...content });
        } catch {
          subjectsList.push({ id: subject, folder: subject, title: subject.charAt(0).toUpperCase() + subject.slice(1), icon: 'BookOpen', color: defaultColors[i % defaultColors.length], order: i + 1 });
        }
      } else {
        subjectsList.push({ id: subject, folder: subject, title: subject.charAt(0).toUpperCase() + subject.slice(1), icon: 'BookOpen', color: defaultColors[i % defaultColors.length], order: i + 1 });
      }
    }
    res.json(subjectsList);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/history', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });
    const fullPath = getSafePath(relativePath);
    const parsed = path.parse(fullPath);
    const historyDir = path.join(parsed.dir, '.history');
    if (!fs.existsSync(historyDir)) return res.json([]);
    const versions = fs.readdirSync(historyDir, { withFileTypes: true })
      .filter((entry) => entry.isFile() && entry.name.startsWith(parsed.name + '__') && entry.name.endsWith(parsed.ext))
      .map((entry) => ({ name: entry.name, path: `${relativePath.replace(/\/+$/, '')}.history/${entry.name}` }))
      .sort((a, b) => b.name.localeCompare(a.name));
    res.json(versions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/restore-version', (req, res) => {
  try {
    const { path: relativePath, versionName } = req.body;
    if (!relativePath || !versionName) return res.status(400).json({ error: 'Missing path or versionName' });
    const fullPath = getSafePath(relativePath);
    const parsed = path.parse(fullPath);
    const historyDir = path.join(parsed.dir, '.history');
    const sourcePath = path.join(historyDir, versionName);
    if (!fs.existsSync(sourcePath)) return res.status(404).json({ error: 'Version not found' });
    if (fs.existsSync(fullPath)) writeVersionSnapshot(fullPath);
    fs.copyFileSync(sourcePath, fullPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/topics', (req, res) => {
  try {
    const publicDir = path.resolve(__dirname, 'public');
    const topics = [];
    const subjects = fs.readdirSync(publicDir, { withFileTypes: true })
      .filter((dirent) => dirent.isDirectory() && !dirent.name.startsWith('.') && !['uploads', 'dist', 'test'].includes(dirent.name))
      .map((dirent) => dirent.name);
    for (const subject of subjects) {
      const subjectPath = path.join(publicDir, subject);
      const possibleTopics = fs.readdirSync(subjectPath, { withFileTypes: true })
        .filter((dirent) => dirent.isDirectory())
        .map((dirent) => dirent.name);
      for (const topic of possibleTopics) {
        if (fs.existsSync(path.join(subjectPath, topic, 'topic.json'))) {
          topics.push({ subject, topic });
        }
      }
    }
    res.json(topics);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.use(express.static(path.join(__dirname, 'public')));
app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
