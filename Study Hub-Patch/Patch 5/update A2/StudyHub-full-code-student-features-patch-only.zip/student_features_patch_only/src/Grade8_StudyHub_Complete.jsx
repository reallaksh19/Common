import React, { useState } from 'react';
import { ParentPinLock } from './components/parent/ParentPinLock.jsx';
import { ParentLayout } from './components/parent/ParentLayout.jsx';
import { ParentDashboard } from './components/parent/ParentDashboard.jsx';
import { ParentSubjectView } from './components/parent/ParentSubjectView.jsx';
import { ParentTopicEditor } from './components/parent/ParentTopicEditor.jsx';
import { ParentPageEditor } from './components/parent/ParentPageEditor.jsx';
import { ParentQuestionsEditor } from './components/parent/QuestionEditor/ParentQuestionsEditor.jsx';
import { ParentClarifiersEditor } from './components/parent/ClarifierEditor/ParentClarifiersEditor.jsx';
import { ParentQuestionLibrary } from './components/parent/ParentQuestionLibrary.jsx';

import { useData } from './contexts/DataContext.jsx';
import { StudyGuide } from './components/StudyGuide/index.jsx';
import { LandingPage } from './components/LandingPage.jsx';
import { TopicHome } from './components/student/TopicHome.jsx';

export default function App() {
  const [parentUnlocked, setParentUnlocked] = useState(
    sessionStorage.getItem('parent_unlocked') === 'true'
  );

  const { subjects, topics, loadingState } = useData();
  const [route, setRoute] = useState(window.location.hash || '#/');
  const [pagesRead, setPagesRead] = useState(() => {
    try {
      const stored = localStorage.getItem('pagesRead');
      if (stored) return new Set(JSON.parse(stored));
    } catch (e) {}
    return new Set();
  });

  const handleMarkRead = (pageId) => {
    setPagesRead((prev) => {
      const next = new Set(prev);
      next.add(pageId);
      localStorage.setItem('pagesRead', JSON.stringify(Array.from(next)));
      return next;
    });
  };

  React.useEffect(() => {
    const handleHashChange = () => setRoute(window.location.hash || '#/');
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const isAppRoute = route.startsWith('#/parent') || route.startsWith('#/student') || route.startsWith('#/topic');

  if (isAppRoute && loadingState === 'loading') {
    return <div>Loading data...</div>;
  }

  if (route.startsWith('#/parent')) {
    if (!parentUnlocked) {
      return <ParentPinLock onUnlocked={() => setParentUnlocked(true)} />;
    }

    const parts = route.replace('#/parent', '').split('/').filter(Boolean);
    let Content = null;

    if (parts.length === 0) {
      Content = <ParentDashboard subjects={subjects} topics={topics} />;
    } else if (parts[0] === 'subject' && parts[1]) {
      const subjectId = parts[1];
      const subject = subjects.find((entry) => entry.id === subjectId);
      const subjectFolder = subject?.folder || subject?.title || subject?.id || subjectId;
      const subjectTopics = topics.filter((topic) => topic.subjectId === subjectId);

      if (parts.length === 2) {
        Content = <ParentSubjectView subject={subject} topics={subjectTopics} />;
      } else if (parts[2] === 'topic' && parts[3]) {
        const topicFolder = parts[3];

        if (parts.length === 4) {
          Content = <ParentTopicEditor subjectId={subjectId} subjectFolder={subjectFolder} topicFolder={topicFolder} />;
        } else if (parts[4] === 'question-library') {
          const topic = topics.find((entry) => entry.subjectId === subjectId && entry.folder === topicFolder);
          Content = <ParentQuestionLibrary subjectId={subjectId} subjectFolder={subjectFolder} topicFolder={topicFolder} topicPages={topic?._fullPages || []} />;
        } else if (parts[4] === 'page' && parts[5]) {
          const pageSlug = parts[5];
          if (parts.length === 6) {
            const topic = topics.find((entry) => entry.subjectId === subjectId && entry.folder === topicFolder);
            Content = <ParentPageEditor subjectId={subjectId} subjectFolder={subjectFolder} topicFolder={topicFolder} pageSlug={pageSlug} topicPages={topic?._fullPages || []} topicTitle={topic?.title || topicFolder} />;
          } else if (parts[6] === 'questions') {
            const topic = topics.find((entry) => entry.subjectId === subjectId && entry.folder === topicFolder);
            const pageRef = topic?._fullPages?.find((page) => page.file?.includes(pageSlug) || page.id?.endsWith(pageSlug) || page.id === pageSlug);
            const page = pageRef?._fullData;
            if (page) {
              Content = (
                <ParentQuestionsEditor
                  pageSlug={pageSlug}
                  initialQuestions={page.questions || []}
                  pageBlocks={page.blocks || []}
                  pageClarifiers={page.clarifiers || []}
                  onSave={async (newQuestions) => {
                    const { saveJSON } = await import('./services/parentApiService.js');
                    const updatedPage = { ...page, questions: newQuestions };
                    await saveJSON(`${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`, updatedPage);
                    alert('Questions saved!');
                  }}
                />
              );
            } else {
              Content = <div>Loading page data or page not found…</div>;
            }
          }
        } else if (parts[4] === 'clarifiers') {
          const topic = topics.find((entry) => entry.subjectId === subjectId && entry.folder === topicFolder);
          if (topic) {
            Content = <ParentClarifiersEditor subjectId={subjectId} subjectFolder={subjectFolder} topicFolder={topicFolder} topicPages={topic._fullPages || []} />;
          } else {
            Content = <div>Loading topic data…</div>;
          }
        }
      }
    }

    return <ParentLayout>{Content || <div>Route not found</div>}</ParentLayout>;
  }

  if (route.startsWith('#/topic/')) {
    const parts = route.replace('#/topic/', '').split('/');
    const topicId = parts[0];
    const topic = topics.find((entry) => entry.id === topicId);

    if (!topic) return <div>Topic not found</div>;
    const subject = subjects.find((entry) => entry.id === topic.subjectId);

    if (parts.length >= 3 && parts[1] === 'page') {
      const pageId = parts[2];
      const pageRef = topic._fullPages?.find((candidate) => candidate.id === pageId);
      const page = pageRef?._fullData ? { ...pageRef, ...pageRef._fullData, estimatedMinutes: pageRef.estimatedMinutes, __pageFile: pageRef.file, __pageSlug: pageRef.file?.split('/').pop()?.replace(/\.json$/i, '') } : null;

      return (
        <StudyGuide
          subject={subject}
          topic={topic}
          page={page}
          pagesRead={pagesRead}
          onMarkRead={handleMarkRead}
          settings={{ geminiApiKey: localStorage.getItem('geminiApiKey') || '' }}
          onPageChange={(targetId) => {
            if (targetId === 'home') {
              window.location.hash = `#/topic/${topic.id}`;
            } else {
              window.location.hash = `#/topic/${topic.id}/page/${targetId}`;
            }
          }}
        />
      );
    }

    return <TopicHome subject={subject} topic={topic} progress={{ pagesRead }} />;
  }

  if (route === '#/student') {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Student Dashboard</h1>
        <div className="grid grid-cols-2 gap-4">
          {subjects.map((subject) => (
            <div key={subject.id} className="border p-6 rounded shadow-sm hover:shadow-md">
              <h2 className="text-xl font-bold mb-2">{subject.title}</h2>
              {topics.filter((topic) => topic.subjectId === subject.id).map((topic) => (
                <div key={topic.id}>
                  <a href={`#/topic/${topic.id}`} className="text-blue-600 hover:underline">{topic.title}</a>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="mt-8 pt-4 border-t">
          <a href="#/parent" className="text-gray-500 hover:text-gray-800">Parent Access</a>
          <a href="#/" className="ml-4 text-gray-500 hover:text-gray-800">Back Home</a>
        </div>
      </div>
    );
  }

  return <LandingPage />;
}
