import React, { useMemo, useState } from 'react';
import { getAiProvider } from '../../services/aiProvider.js';
import { readJSON, saveJSON, uploadAsset } from '../../services/parentApiService.js';

const MODES = [
  { value: 'explain', label: 'Explain more simply' },
  { value: 'concept', label: 'Explain the concept' },
  { value: 'solve', label: 'Solve step by step' },
  { value: 'reasoning', label: 'Explain the reasoning' },
  { value: 'example', label: 'Give a real-life example' },
];

function makeClarifierId(pageId, mode) {
  return `${pageId}-ai-${mode}-${Date.now()}`;
}

export function ShowMoreDetailModal({ open, onClose, settings = {}, subject, topic, page, subjectFolder, topicFolder, pageSlug }) {
  const aiProvider = useMemo(() => getAiProvider(settings), [settings]);
  const [mode, setMode] = useState('explain');
  const [focusText, setFocusText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [saveStatus, setSaveStatus] = useState('idle');

  if (!open) return null;

  const generate = async () => {
    setLoading(true);
    setSaveStatus('idle');
    try {
      const output = await aiProvider.getDetailedHelp({
        grade: 'Grade 9',
        subjectTitle: subject?.title || subject?.id || '',
        topicTitle: topic?.title || topic?.id || '',
        pageTitle: page?.title || '',
        pageBlocks: page?.blocks || [],
        mode,
        focusText,
      });
      setResult(output || 'No extra detail generated.');
    } catch (err) {
      alert(err.message || 'Could not generate more detail.');
    } finally {
      setLoading(false);
    }
  };

  const saveAsHelper = async () => {
    if (!result) return;
    setSaveStatus('saving-helper');
    try {
      const pagePath = `${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`;
      const existing = await readJSON(pagePath);
      const clarifier = {
        id: makeClarifierId(existing.id || pageSlug, mode),
        type: 'tip',
        title: `AI help: ${MODES.find((m) => m.value === mode)?.label || mode}`,
        body: result,
      };
      await saveJSON(pagePath, {
        ...existing,
        clarifiers: [...(existing.clarifiers || []), clarifier],
      });
      setSaveStatus('saved-helper');
    } catch (err) {
      alert(err.message || 'Could not save helper note.');
      setSaveStatus('idle');
    }
  };

  const saveAsResource = async () => {
    if (!result) return;
    setSaveStatus('saving-resource');
    try {
      const pagePath = `${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`;
      const existing = await readJSON(pagePath);
      const filename = `${pageSlug}-ai-${mode}-${Date.now()}.md`;
      const resourcePath = `${subjectFolder}/${topicFolder}/assets/generated/${filename}`;
      const blob = new Blob([`# ${page?.title || 'AI help'}\n\n${result}\n`], { type: 'text/markdown' });
      const file = new File([blob], filename, { type: 'text/markdown' });
      const uploadResult = await uploadAsset(file, resourcePath);
      const attachment = {
        id: `${existing.id || pageSlug}-ai-resource-${Date.now()}`,
        title: `AI saved note: ${MODES.find((m) => m.value === mode)?.label || mode}`,
        description: focusText || 'Generated from the student help popup.',
        path: uploadResult.path,
        kind: 'text',
        openMode: 'new_tab',
      };
      await saveJSON(pagePath, {
        ...existing,
        attachments: [...(existing.attachments || []), attachment],
      });
      setSaveStatus('saved-resource');
    } catch (err) {
      alert(err.message || 'Could not save resource note.');
      setSaveStatus('idle');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <div>
            <h3 className="text-xl font-bold">Show more detail</h3>
            <div className="text-sm text-gray-500">Use AI help for {subject?.title} → {topic?.title} → {page?.title}</div>
          </div>
          <button onClick={onClose} className="rounded border px-3 py-2 text-sm">Close</button>
        </div>
        <div className="space-y-4 p-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-bold">What do you want?</label>
              <select value={mode} onChange={(e) => setMode(e.target.value)} className="w-full rounded border p-2">
                {MODES.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-bold">Focus area (optional)</label>
              <input
                value={focusText}
                onChange={(e) => setFocusText(e.target.value)}
                className="w-full rounded border p-2"
                placeholder="Example: explain why the angle is measured from the normal"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={generate} disabled={loading} className="rounded bg-purple-600 px-4 py-2 font-bold text-white hover:bg-purple-700 disabled:opacity-60">
              {loading ? 'Generating…' : 'Generate help'}
            </button>
          </div>
          <div className="rounded-xl border bg-gray-50 p-4">
            <div className="mb-2 text-sm font-bold text-gray-600">AI output</div>
            <div className="min-h-[180px] whitespace-pre-wrap text-sm text-gray-800">{result || 'Choose the kind of help you want, then generate it here.'}</div>
          </div>
          <div className="flex flex-wrap gap-2 border-t pt-4">
            <button onClick={saveAsHelper} disabled={!result || saveStatus.startsWith('saving')} className="rounded bg-indigo-600 px-3 py-2 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-60">Save as helper note</button>
            <button onClick={saveAsResource} disabled={!result || saveStatus.startsWith('saving')} className="rounded border px-3 py-2 text-sm hover:bg-gray-50 disabled:opacity-60">Save as resource asset</button>
            {saveStatus === 'saved-helper' && <span className="text-sm text-green-700">Saved into the page helpers.</span>}
            {saveStatus === 'saved-resource' && <span className="text-sm text-green-700">Saved into page resources/assets.</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
