import React, { useEffect, useMemo, useState } from 'react';
import { readJSON } from '../../services/parentApiService.js';

const CATEGORY_LABELS = {
  reasoning: 'Reasoning',
  concept: 'Concepts',
  real_life: 'Real-life problems',
  exam_drill: 'Exam drill',
  mixed: 'Mixed',
};

function normalizeLibrary(raw) {
  if (!raw) return [];
  if (Array.isArray(raw.questions)) return raw.questions;
  if (Array.isArray(raw)) return raw;
  return [];
}

export function AddMoreQuestionsModal({ open, onClose, subjectFolder, topicFolder, topicTitle, onAddQuestions }) {
  const [libraryQuestions, setLibraryQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState('reasoning');

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    async function loadLibrary() {
      setLoading(true);
      try {
        const data = await readJSON(`${subjectFolder}/${topicFolder}/question-library.json`).catch(() => ({ questions: [] }));
        if (!cancelled) setLibraryQuestions(normalizeLibrary(data));
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadLibrary();
    return () => { cancelled = true; };
  }, [open, subjectFolder, topicFolder]);

  const categories = useMemo(() => {
    const counts = {};
    libraryQuestions.forEach((item) => {
      const cat = item.category || 'mixed';
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return Object.entries(counts).map(([value, count]) => ({
      value,
      count,
      label: CATEGORY_LABELS[value] || value,
    }));
  }, [libraryQuestions]);

  const filtered = libraryQuestions.filter((item) => (item.category || 'mixed') === category);

  if (!open) return null;

  const handleAdd = () => {
    const questions = filtered.map((item, index) => ({
      ...item.question,
      id: item.question?.id || `${topicFolder}-${category}-${index + 1}`,
      sourceCategory: item.category || category,
      sourceLibraryTitle: item.title || item.question?.prompt || `Extra ${category} question`,
    })).filter(Boolean);
    onAddQuestions(questions, category);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <div>
            <h3 className="text-xl font-bold">Add more questions</h3>
            <div className="text-sm text-gray-500">Choose a practice category from the {topicTitle} question library.</div>
          </div>
          <button onClick={onClose} className="rounded border px-3 py-2 text-sm">Close</button>
        </div>
        <div className="space-y-4 p-6">
          {loading ? (
            <div className="text-sm text-gray-600">Loading question library…</div>
          ) : categories.length === 0 ? (
            <div className="rounded border bg-amber-50 p-4 text-sm text-amber-900">
              No question library exists for this topic yet. Ask the parent to add category-based questions in the parent portal.
            </div>
          ) : (
            <>
              <div>
                <label className="mb-2 block text-sm font-bold">Category</label>
                <div className="grid gap-2 md:grid-cols-2">
                  {categories.map((entry) => (
                    <button
                      key={entry.value}
                      onClick={() => setCategory(entry.value)}
                      className={`rounded border p-3 text-left ${category === entry.value ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
                    >
                      <div className="font-bold">{entry.label}</div>
                      <div className="text-sm text-gray-500">{entry.count} available</div>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2 text-sm font-bold">Preview</div>
                <div className="max-h-64 space-y-2 overflow-y-auto rounded border p-3">
                  {filtered.map((item) => (
                    <div key={item.id} className="rounded bg-gray-50 p-3">
                      <div className="text-sm font-bold">{item.title || item.question?.prompt || 'Untitled question'}</div>
                      <div className="text-xs text-gray-500">{CATEGORY_LABELS[item.category] || item.category}</div>
                    </div>
                  ))}
                  {!filtered.length && <div className="text-sm text-gray-500">No questions in this category yet.</div>}
                </div>
              </div>
              <div className="flex justify-end gap-2 border-t pt-4">
                <button onClick={onClose} className="rounded border px-3 py-2 text-sm">Cancel</button>
                <button onClick={handleAdd} disabled={!filtered.length} className="rounded bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-60">
                  Add {filtered.length} questions
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
