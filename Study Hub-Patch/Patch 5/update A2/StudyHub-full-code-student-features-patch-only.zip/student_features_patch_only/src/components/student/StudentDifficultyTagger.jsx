import React, { useState } from 'react';
import { saveStudentSignal } from '../../services/parentApiService.js';

const TAG_OPTIONS = [
  { value: 'hard', label: 'I found this hard' },
  { value: 'need_parent_help', label: 'Need parent help' },
  { value: 'revise_later', label: 'Revise later' },
  { value: 'confused', label: 'I am confused' },
];

export function StudentDifficultyTagger({ subjectId, topicId, pageId }) {
  const [open, setOpen] = useState(false);
  const [tag, setTag] = useState(TAG_OPTIONS[0].value);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveStudentSignal({
        type: 'difficulty_tag',
        subjectId,
        topicId,
        pageId,
        tag,
        note,
        createdAt: new Date().toISOString(),
      });
      setSavedAt(new Date().toISOString());
      setNote('');
      setOpen(false);
    } catch (err) {
      alert(err.message || 'Could not save your learning tag right now.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-bold text-amber-900">Tell the app if this page feels difficult</div>
          <div className="text-sm text-amber-800">Your tag is reflected in the parent portal so help can be added later.</div>
        </div>
        <button
          onClick={() => setOpen((v) => !v)}
          className="rounded bg-amber-600 px-3 py-2 text-sm font-bold text-white hover:bg-amber-700"
        >
          {open ? 'Close' : 'Add learning tag'}
        </button>
      </div>
      {savedAt && <div className="mt-2 text-xs text-amber-900">Saved for parent review.</div>}
      {open && (
        <div className="mt-4 space-y-3 rounded-lg border bg-white p-4">
          <div>
            <label className="mb-1 block text-sm font-bold text-gray-700">Tag</label>
            <select value={tag} onChange={(e) => setTag(e.target.value)} className="w-full rounded border p-2">
              {TAG_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-sm font-bold text-gray-700">Optional note</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="h-24 w-full rounded border p-2"
              placeholder="Example: I do not understand why the ray bends towards the normal."
            />
          </div>
          <div className="flex justify-end gap-2">
            <button onClick={() => setOpen(false)} className="rounded border px-3 py-2 text-sm">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="rounded bg-indigo-600 px-3 py-2 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-60">
              {saving ? 'Saving…' : 'Save tag'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
