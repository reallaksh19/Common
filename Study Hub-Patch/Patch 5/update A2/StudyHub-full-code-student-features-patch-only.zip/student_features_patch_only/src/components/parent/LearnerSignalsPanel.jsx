import React, { useEffect, useMemo, useState } from 'react';
import { getStudentSignals } from '../../services/parentApiService.js';

function tagLabel(tag) {
  switch (tag) {
    case 'hard': return 'Found hard';
    case 'need_parent_help': return 'Need parent help';
    case 'revise_later': return 'Revise later';
    case 'confused': return 'Confused';
    default: return tag || 'Signal';
  }
}

export function LearnerSignalsPanel({ topicId }) {
  const [signals, setSignals] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function loadSignals() {
      if (!topicId) return;
      setLoading(true);
      try {
        const data = await getStudentSignals({ topicId }).catch(() => []);
        if (!cancelled) setSignals(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadSignals();
    return () => { cancelled = true; };
  }, [topicId]);

  const grouped = useMemo(() => {
    const map = {};
    signals.forEach((signal) => {
      const pageId = signal.pageId || 'unknown-page';
      map[pageId] = map[pageId] || [];
      map[pageId].push(signal);
    });
    return Object.entries(map);
  }, [signals]);

  return (
    <div className="mt-6 rounded-xl border bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <h4 className="text-sm font-bold uppercase text-gray-700">Learner signals</h4>
        <span className="text-xs text-gray-500">{signals.length} total</span>
      </div>
      {loading ? (
        <div className="text-sm text-gray-500">Loading signals…</div>
      ) : !grouped.length ? (
        <div className="text-sm text-gray-500">No student difficulty tags yet.</div>
      ) : (
        <div className="space-y-3">
          {grouped.map(([pageId, entries]) => (
            <div key={pageId} className="rounded border bg-gray-50 p-3">
              <div className="mb-2 text-sm font-bold text-gray-800">{pageId}</div>
              <div className="space-y-2 text-sm">
                {entries.slice(0, 4).map((signal) => (
                  <div key={signal.id || `${signal.tag}-${signal.createdAt}`} className="rounded bg-white p-2 border">
                    <div className="font-medium text-indigo-700">{tagLabel(signal.tag)}</div>
                    {signal.note && <div className="text-gray-700">{signal.note}</div>}
                    <div className="text-xs text-gray-400">{signal.createdAt ? new Date(signal.createdAt).toLocaleString() : ''}</div>
                  </div>
                ))}
                {entries.length > 4 && <div className="text-xs text-gray-500">+ {entries.length - 4} more</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
