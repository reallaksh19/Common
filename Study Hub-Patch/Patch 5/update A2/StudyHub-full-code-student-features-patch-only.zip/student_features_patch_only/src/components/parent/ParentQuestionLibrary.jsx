import React, { useEffect, useMemo, useState } from 'react';
import { readJSON, saveJSON } from '../../services/parentApiService.js';
import { QuestionForm } from './QuestionEditor/QuestionForm.jsx';
import { generateQuestionId } from '../../utils/idFactory.js';

const DEFAULT_LIBRARY = { questions: [] };
const CATEGORIES = [
  { value: 'reasoning', label: 'Reasoning' },
  { value: 'concept', label: 'Concepts' },
  { value: 'real_life', label: 'Real-life problems' },
  { value: 'exam_drill', label: 'Exam drill' },
  { value: 'mixed', label: 'Mixed' },
];

export function ParentQuestionLibrary({ subjectId, subjectFolder, topicFolder, topicPages = [] }) {
  const [library, setLibrary] = useState(DEFAULT_LIBRARY);
  const [selectedId, setSelectedId] = useState(null);
  const [filter, setFilter] = useState('all');
  const filePath = `${subjectFolder}/${topicFolder}/question-library.json`;

  useEffect(() => {
    async function load() {
      const data = await readJSON(filePath).catch(() => DEFAULT_LIBRARY);
      setLibrary(data?.questions ? data : DEFAULT_LIBRARY);
      if (data?.questions?.length) setSelectedId(data.questions[0].id);
    }
    load();
  }, [filePath]);

  const filteredQuestions = useMemo(() => {
    if (filter === 'all') return library.questions || [];
    return (library.questions || []).filter((item) => item.category === filter);
  }, [library, filter]);

  const selectedEntry = (library.questions || []).find((item) => item.id === selectedId);

  const saveLibrary = async (nextLibrary) => {
    setLibrary(nextLibrary);
    await saveJSON(filePath, nextLibrary);
  };

  const handleAdd = async () => {
    const category = 'concept';
    const id = `${topicFolder}-library-${Date.now()}`;
    const questionId = generateQuestionId(topicFolder, (library.questions || []).length + 1);
    const next = {
      ...library,
      questions: [
        ...(library.questions || []),
        {
          id,
          title: 'New library question',
          category,
          question: { id: questionId, type: 'mcq', prompt: '' },
        },
      ],
    };
    await saveLibrary(next);
    setSelectedId(id);
  };

  const handleChangeEntry = async (id, patch) => {
    const next = {
      ...library,
      questions: (library.questions || []).map((entry) => (entry.id === id ? { ...entry, ...patch } : entry)),
    };
    setLibrary(next);
  };

  const handleSave = async () => {
    await saveLibrary(library);
    alert('Question library saved!');
  };

  const handleDelete = async (id) => {
    const nextQuestions = (library.questions || []).filter((entry) => entry.id !== id);
    const next = { ...library, questions: nextQuestions };
    await saveLibrary(next);
    setSelectedId(nextQuestions[0]?.id || null);
  };

  return (
    <div className="flex h-[calc(100vh-90px)] gap-4">
      <div className="w-80 rounded-xl border bg-white p-4 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">Question Library</h2>
          <button onClick={handleAdd} className="rounded bg-indigo-600 px-3 py-2 text-sm font-bold text-white hover:bg-indigo-700">+ Add</button>
        </div>
        <div className="mb-3">
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="w-full rounded border p-2 text-sm">
            <option value="all">All categories</option>
            {CATEGORIES.map((cat) => <option key={cat.value} value={cat.value}>{cat.label}</option>)}
          </select>
        </div>
        <div className="space-y-2 overflow-y-auto">
          {filteredQuestions.map((entry) => (
            <div key={entry.id} className={`cursor-pointer rounded border p-3 ${selectedId === entry.id ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`} onClick={() => setSelectedId(entry.id)}>
              <div className="text-xs font-bold uppercase text-gray-500">{entry.category}</div>
              <div className="font-medium">{entry.title || entry.question?.prompt || 'Untitled question'}</div>
            </div>
          ))}
          {!filteredQuestions.length && <div className="text-sm text-gray-500">No questions in this category yet.</div>}
        </div>
      </div>
      <div className="flex-1 rounded-xl border bg-white p-4 shadow-sm overflow-y-auto">
        {!selectedEntry ? (
          <div className="text-sm text-gray-500">Select or add a library question.</div>
        ) : (
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-bold">Library title</label>
                <input className="w-full rounded border p-2" value={selectedEntry.title || ''} onChange={(e) => handleChangeEntry(selectedEntry.id, { title: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold">Category</label>
                <select className="w-full rounded border p-2" value={selectedEntry.category || 'concept'} onChange={(e) => handleChangeEntry(selectedEntry.id, { category: e.target.value })}>
                  {CATEGORIES.map((cat) => <option key={cat.value} value={cat.value}>{cat.label}</option>)}
                </select>
              </div>
            </div>
            <QuestionForm
              question={selectedEntry.question}
              pageBlocks={topicPages.flatMap((page) => page._fullData?.blocks || [])}
              pageClarifiers={topicPages.flatMap((page) => page._fullData?.clarifiers || [])}
              onChange={(_, newQuestion) => handleChangeEntry(selectedEntry.id, { question: newQuestion })}
            />
            <div className="flex justify-between border-t pt-4">
              <button onClick={() => handleDelete(selectedEntry.id)} className="rounded border border-red-300 px-3 py-2 text-sm text-red-700 hover:bg-red-50">Delete</button>
              <button onClick={handleSave} className="rounded bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-700">Save library</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
