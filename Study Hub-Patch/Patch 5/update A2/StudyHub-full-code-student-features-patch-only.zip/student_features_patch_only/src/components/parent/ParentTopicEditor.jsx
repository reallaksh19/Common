import React, { useState, useEffect } from 'react';
import { ParentPageEditor } from './ParentPageEditor.jsx';
import { validateTopic } from '../../content/contentPackSchema.js';
import { readJSON, saveJSON } from '../../services/parentApiService.js';
import { slugify } from '../../utils/slugify.js';
import { buildPageFile, buildPageId, extractPageSlug } from '../../utils/contentPaths.js';
import { formatRelativeTime, getTopicStatus } from '../../services/topicStateService.js';
import { LearnerSignalsPanel } from './LearnerSignalsPanel.jsx';

export function ParentTopicEditor({ subjectId, subjectFolder, topicFolder }) {
  const [topicData, setTopicData] = useState({ id: `${subjectId}-${topicFolder}`, subjectId, pages: [] });
  const [activePageSlug, setActivePageSlug] = useState(null);
  const [validationErrors, setValidationErrors] = useState([]);

  const topicFilePath = `${subjectFolder}/${topicFolder}/topic.json`;
  const status = getTopicStatus(`${subjectId}/${topicFolder}`);

  useEffect(() => {
    async function load() {
      try {
        const fileData = await readJSON(topicFilePath);
        setTopicData(fileData);
        if (fileData.pages?.length) {
          setActivePageSlug(extractPageSlug(fileData.pages[0]));
        }
      } catch (err) {
        console.error('Failed to load topic', err);
      }
    }
    load();
  }, [topicFilePath]);

  useEffect(() => {
    const res = validateTopic(topicData);
    setValidationErrors(res.success ? [] : [res.error]);
  }, [topicData]);

  const handleAddPage = async () => {
    const title = window.prompt('Enter new page title:');
    if (!title) return;

    const pageSlug = slugify(title);
    const topicId = topicData.id || `${subjectId}-${topicFolder}`;
    const newPageMeta = {
      id: buildPageId(topicId, pageSlug),
      file: buildPageFile(pageSlug),
      title,
      order: (topicData.pages?.length || 0) + 1,
      estimatedMinutes: 10
    };

    const newTopicData = { ...topicData, pages: [...(topicData.pages || []), newPageMeta] };
    const blankPage = {
      id: newPageMeta.id,
      topicId,
      title,
      blocks: [], clarifiers: [], questions: [], attachments: []
    };

    try {
      await saveJSON(`${subjectFolder}/${topicFolder}/${newPageMeta.file}`, blankPage);
      await saveJSON(topicFilePath, newTopicData);
      setTopicData(newTopicData);
      setActivePageSlug(pageSlug);
    } catch {
      alert('Failed to add page');
    }
  };

  const handlePageSelect = (pageRef) => {
    const slug = extractPageSlug(pageRef);
    setActivePageSlug(slug);
    window.location.hash = `#/parent/subject/${subjectId}/topic/${topicFolder}/page/${slug}`;
  };

  const activePage = (topicData.pages || []).find((page) => extractPageSlug(page) === activePageSlug);

  return (
    <div className="flex h-[calc(100vh-80px)]">
      <div className="w-1/4 border-r pr-4 flex flex-col p-4 bg-gray-50">
        <h2 className="font-bold text-xl mb-2">Pages</h2>
        <div className="text-xs text-gray-500 mb-4">
          Draft {status.hasDraft ? formatRelativeTime(status.draftSavedAt) : '—'} · Published {formatRelativeTime(status.publishedAt)}
        </div>
        <div className="mb-4 flex gap-2">
          <a href={`#/parent/subject/${subjectId}/topic/${topicFolder}/question-library`} className="flex-1 rounded border bg-white px-3 py-2 text-center text-sm font-medium hover:bg-gray-50">Question library</a>
        </div>
        <div className="space-y-2">
          {(topicData.pages || []).map((pageRef) => {
            const slug = extractPageSlug(pageRef);
            return (
              <div
                key={pageRef.id}
                className={`p-2 cursor-pointer border rounded ${slug === activePageSlug ? 'bg-indigo-100 border-indigo-400 font-bold' : 'bg-white hover:border-indigo-200'}`}
                onClick={() => handlePageSelect(pageRef)}
              >
                <div className="flex justify-between">
                  <span>{pageRef.title}</span>
                  <span className="text-gray-400 text-xs">{pageRef.estimatedMinutes}m</span>
                </div>
              </div>
            );
          })}
          <button onClick={handleAddPage} className="w-full mt-4 p-2 bg-white border border-dashed border-gray-400 rounded text-gray-600 hover:text-indigo-600 hover:border-indigo-400 transition-colors">
            + Add Page
          </button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto bg-white">
        {activePageSlug ? (
          <ParentPageEditor
            subjectId={subjectId}
            subjectFolder={subjectFolder}
            topicFolder={topicFolder}
            pageSlug={activePageSlug}
            topicPages={topicData.pages || []}
            topicTitle={topicData.title}
          />
        ) : (
          <div className="text-center text-gray-500 mt-20">Select a page or create a new one</div>
        )}
      </div>

      <div className="w-1/4 pl-4 border-l bg-gray-50 p-4 overflow-y-auto">
        <div className="mb-4 pb-2 border-b">
          {validationErrors.length === 0 ? (
            <span className="text-green-600 font-bold flex items-center gap-2"><span className="text-xl">✅</span> Valid Topic Config</span>
          ) : (
            <span className="text-amber-600 font-bold">⚠️ {validationErrors.length} validation errors</span>
          )}
        </div>
        {validationErrors.map((err, i) => (
          <div key={i} className="text-red-500 text-sm mb-2 p-2 bg-red-50 border border-red-200 rounded">{err}</div>
        ))}

        <div className="mt-2 space-y-4 text-sm text-gray-600">
          <div><strong>Topic Title:</strong> {topicData.title}</div>
          <div><strong>Difficulty:</strong> {topicData.difficulty}</div>
          <div><strong>Pages:</strong> {topicData.pages?.length || 0}</div>
          <div><strong>Active Page:</strong> {activePage?.title || '—'}</div>
          <div><strong>Exported:</strong> {status.exportCount || 0} time(s)</div>
        </div>

        <LearnerSignalsPanel topicId={topicData.id} />
      </div>
    </div>
  );
}
