import React, { useMemo, useState } from 'react';
import { LinkCardBlock } from '../blocks/LinkCardBlock.jsx';
import { ContentRenderer } from '../common/ContentRenderer.jsx';
import { getAiProvider } from '../../services/aiProvider.js';

export function RightSidebar({ clarifiers = [], relatedPages = [], settings = {}, pageBlocks = [], pageTitle = '', onOpenMoreDetail }) {
  const [aiSummary, setAiSummary] = useState(null);
  const [aiExplanation, setAiExplanation] = useState(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const aiProvider = useMemo(() => getAiProvider(settings), [settings]);

  const getClarifierStyle = (type) => {
    switch (type) {
      case 'tip': return { bg: 'bg-blue-50', border: 'border-blue-200', icon: '💡' };
      case 'warning': return { bg: 'bg-amber-50', border: 'border-amber-200', icon: '⚠️' };
      case 'key_fact': return { bg: 'bg-indigo-50', border: 'border-indigo-500', icon: '📌' };
      case 'common_mistake': return { bg: 'bg-red-50', border: 'border-red-200', icon: '❌' };
      case 'did_you_know': return { bg: 'bg-emerald-50', border: 'border-emerald-200', icon: '🌟' };
      default: return { bg: 'bg-gray-50', border: 'border-gray-200', icon: 'ℹ️' };
    }
  };

  const runAi = async (task, setter) => {
    setLoadingAi(true);
    try {
      const result = task === 'summary'
        ? await aiProvider.summarizePage({ pageTitle, pageBlocks })
        : await aiProvider.explainPage({ pageTitle, pageBlocks });
      setter(result);
    } catch (err) {
      alert(err.message || 'AI unavailable right now');
    } finally {
      setLoadingAi(false);
    }
  };

  return (
    <div className="right-sidebar">
      {clarifiers.length > 0 && (
        <div className="mb-6">
          <h3 className="font-bold text-lg mb-3">Concept Tips</h3>
          {clarifiers.map((clarifier) => {
            const style = getClarifierStyle(clarifier.type);
            return (
              <div key={clarifier.id} className={`${style.bg} ${style.border} border rounded p-3 mb-3`}>
                <div className="font-bold mb-1 flex items-center">
                  <span className="mr-2">{style.icon}</span>
                  {clarifier.title}
                </div>
                <div className="text-sm">
                  <ContentRenderer content={clarifier.body} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {relatedPages.length > 0 && (
        <div className="mb-6">
          <h3 className="font-bold text-lg mb-3">Related Pages</h3>
          {relatedPages.map((page) => (
            <div key={page.id} className="mb-2">
              <LinkCardBlock title={page.title} url={page.url || `#/topic/${page.topicId}/page/${page.id}`} linkType="page" />
            </div>
          ))}
        </div>
      )}

      {pageBlocks.length > 0 && (
        <div className="mb-6 border-t pt-4">
          <h3 className="font-bold text-lg mb-3 flex items-center"><span className="mr-2">🤖</span> AI Assist</h3>
          <div className="flex flex-col gap-2">
            <button onClick={() => runAi('summary', setAiSummary)} disabled={loadingAi} className="px-3 py-2 bg-purple-50 text-purple-700 border border-purple-200 rounded hover:bg-purple-100 text-sm font-bold text-left transition-colors flex items-center justify-between">
              <span>✨ Summarise this page</span>
            </button>
            <button onClick={() => runAi('explain', setAiExplanation)} disabled={loadingAi} className="px-3 py-2 bg-purple-50 text-purple-700 border border-purple-200 rounded hover:bg-purple-100 text-sm font-bold text-left transition-colors flex items-center justify-between">
              <span>✨ Explain differently</span>
            </button>
            <button onClick={onOpenMoreDetail} className="px-3 py-2 bg-white text-purple-700 border border-purple-200 rounded hover:bg-purple-50 text-sm font-bold text-left transition-colors">
              ➕ Show more detail
            </button>
          </div>

          {loadingAi && <div className="mt-4 text-sm text-purple-600 font-bold animate-pulse">Thinking...</div>}

          {aiSummary && (
            <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded relative">
              <button onClick={() => setAiSummary(null)} className="absolute top-1 right-2 text-gray-400 hover:text-gray-800">✕</button>
              <h4 className="font-bold text-purple-800 text-sm mb-1">Summary</h4>
              <p className="text-sm text-purple-900 whitespace-pre-wrap">{aiSummary}</p>
            </div>
          )}

          {aiExplanation && (
            <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded relative">
              <button onClick={() => setAiExplanation(null)} className="absolute top-1 right-2 text-gray-400 hover:text-gray-800">✕</button>
              <h4 className="font-bold text-purple-800 text-sm mb-1">Different Explanation</h4>
              <p className="text-sm text-purple-900 whitespace-pre-wrap">{aiExplanation}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
