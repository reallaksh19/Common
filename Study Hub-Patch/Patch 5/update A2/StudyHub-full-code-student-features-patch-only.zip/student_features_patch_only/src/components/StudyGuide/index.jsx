import React, { useEffect, useMemo, useRef, useState } from 'react';
import { RightSidebar } from './RightSidebar.jsx';
import { BlockRenderer } from '../blocks/BlockRenderer.jsx';
import { QuizSection } from '../QuizSection/index.jsx';
import { LinkCardBlock } from '../blocks/LinkCardBlock.jsx';
import { StudentDifficultyTagger } from '../student/StudentDifficultyTagger.jsx';
import { ShowMoreDetailModal } from '../student/ShowMoreDetailModal.jsx';
import { AddMoreQuestionsModal } from '../student/AddMoreQuestionsModal.jsx';

function buildAttachmentUrl(attachment) {
  return attachment.url || attachment.path;
}

export function StudyGuide({ subject, topic, page, pagesRead, onMarkRead, onPageChange, settings = {} }) {
  const lastBlockRef = useRef(null);
  const [showAiModal, setShowAiModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [extraQuestions, setExtraQuestions] = useState([]);
  const [extraCategory, setExtraCategory] = useState('');

  useEffect(() => {
    if (!lastBlockRef.current || !page) return;

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        onMarkRead(page.id);
      }
    }, { threshold: 0.5 });

    observer.observe(lastBlockRef.current);
    return () => observer.disconnect();
  }, [page, onMarkRead]);

  useEffect(() => {
    setExtraQuestions([]);
    setExtraCategory('');
  }, [page?.id]);

  if (!page) return <div>Page not found</div>;

  const clarifiers = page.clarifiers || [];
  const attachments = page.attachments || [];
  const relatedPages = (page.relatedPageIds || []).map((id) => {
    const related = (topic?.pages || []).find((candidate) => candidate.id === id);
    return related ? { id: related.id, title: related.title, topicId: topic.id, url: `#/topic/${topic.id}/page/${related.id}` } : null;
  }).filter(Boolean);

  const currentIndex = topic.pages.findIndex((candidate) => candidate.id === page.id);
  const prevPage = currentIndex > 0 ? topic.pages[currentIndex - 1] : null;
  const nextPage = currentIndex < topic.pages.length - 1 ? topic.pages[currentIndex + 1] : null;
  const subjectFolder = subject?.folder || subject?.title || subject?.id;
  const pageSlug = page.__pageSlug || page.__pageFile?.split('/').pop()?.replace(/\.json$/i, '') || page.id;

  return (
    <>
      <div className="flex h-screen overflow-hidden">
        <div className="w-64 bg-gray-50 border-r p-4 overflow-y-auto">
          <h2 className="font-bold text-lg mb-4">{topic.title}</h2>
          <div className="space-y-2">
            {topic.pages.map((candidate) => {
              const isRead = pagesRead.has(candidate.id);
              const isCurrent = candidate.id === page.id;
              return (
                <div
                  key={candidate.id}
                  onClick={() => onPageChange(candidate.id)}
                  className={`p-2 rounded cursor-pointer text-sm ${isCurrent ? 'bg-blue-100 text-blue-800 font-bold' : 'hover:bg-gray-200'}`}
                >
                  {isRead ? '✅' : (isCurrent ? '▶' : '○')} {candidate.title}
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 relative">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8 border-b pb-4">
              <h1 className="text-4xl font-bold mb-2">{page.title}</h1>
              <div className="text-gray-500 text-sm">~{page.estimatedMinutes || 5} min read</div>
            </div>

            <StudentDifficultyTagger subjectId={subject?.id} topicId={topic?.id} pageId={page.id} />

            <div className="mb-6 flex flex-wrap gap-2">
              <button onClick={() => setShowAiModal(true)} className="rounded bg-purple-600 px-4 py-2 text-sm font-bold text-white hover:bg-purple-700">Show more detail</button>
              <button onClick={() => setShowQuestionModal(true)} className="rounded border px-4 py-2 text-sm font-bold hover:bg-gray-50">Add more questions</button>
            </div>

            <div className="blocks mb-12">
              {(page.blocks || []).map((block, idx) => {
                const isLast = idx === page.blocks.length - 1;
                return (
                  <div key={block.id} ref={isLast ? lastBlockRef : null}>
                    <BlockRenderer block={block} />
                  </div>
                );
              })}
            </div>

            {attachments.length > 0 && (
              <div className="mb-12 rounded-xl border bg-white p-5 shadow-sm">
                <h3 className="mb-3 text-xl font-bold">Helpful resources</h3>
                <div className="space-y-2">
                  {attachments.map((attachment) => (
                    <LinkCardBlock
                      key={attachment.id || attachment.path}
                      title={attachment.title}
                      description={attachment.description}
                      url={buildAttachmentUrl(attachment)}
                      linkType={attachment.kind === 'pdf' ? 'pdf' : 'external'}
                    />
                  ))}
                </div>
              </div>
            )}

            {(page.questions && page.questions.length > 0) && (
              <QuizSection
                questions={page.questions}
                pageBlocks={page.blocks}
                clarifiers={page.clarifiers}
                pageAttachments={attachments}
                relatedPages={relatedPages}
                onComplete={() => onMarkRead(page.id)}
                title="Page practice"
              />
            )}

            {extraQuestions.length > 0 && (
              <QuizSection
                key={`${page.id}-${extraCategory}-${extraQuestions.length}`}
                questions={extraQuestions}
                pageBlocks={page.blocks}
                clarifiers={page.clarifiers}
                pageAttachments={attachments}
                relatedPages={relatedPages}
                title={`Extra ${extraCategory || 'practice'}`}
              />
            )}

            <div className="mt-12 flex justify-between pt-4 border-t">
              {prevPage ? (
                <button onClick={() => onPageChange(prevPage.id)} className="text-blue-600 hover:underline">
                  ← {prevPage.title}
                </button>
              ) : <span />}
              {nextPage ? (
                <button onClick={() => onPageChange(nextPage.id)} className="px-4 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">
                  Next: {nextPage.title} →
                </button>
              ) : <span />}
            </div>
          </div>
        </div>

        <div className="w-80 bg-gray-50 border-l p-4 overflow-y-auto hidden lg:block">
          <RightSidebar
            clarifiers={clarifiers}
            relatedPages={relatedPages}
            pageBlocks={page.blocks}
            pageTitle={page.title}
            settings={settings}
            onOpenMoreDetail={() => setShowAiModal(true)}
          />
        </div>
      </div>

      <ShowMoreDetailModal
        open={showAiModal}
        onClose={() => setShowAiModal(false)}
        settings={settings}
        subject={subject}
        topic={topic}
        page={page}
        subjectFolder={subjectFolder}
        topicFolder={topic.folder || topic.id}
        pageSlug={pageSlug}
      />

      <AddMoreQuestionsModal
        open={showQuestionModal}
        onClose={() => setShowQuestionModal(false)}
        subjectFolder={subjectFolder}
        topicFolder={topic.folder || topic.id}
        topicTitle={topic.title}
        onAddQuestions={(questions, category) => {
          setExtraQuestions(questions);
          setExtraCategory(category);
        }}
      />
    </>
  );
}
