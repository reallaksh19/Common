import { callGemini } from './geminiService.js';

function getPageText(pageBlocks = []) {
  return pageBlocks
    .filter((b) => b.type === 'paragraph' || b.type === 'heading' || b.type === 'bullets')
    .map((b) => {
      if (b.type === 'bullets') return (b.data?.items || []).join(' ');
      return b.data?.text || '';
    })
    .join(' ')
    .slice(0, 2200);
}

function createMockProvider() {
  return {
    id: 'mock',
    async summarizePage() {
      return 'Here is a 3-line recap of the page content: This page explains the concept clearly. It shows how it applies in real life. It also points out common mistakes.';
    },
    async explainPage() {
      return 'Think of it like building with blocks. Each small idea combines to make the bigger result easier to understand.';
    },
    async getDetailedHelp({ mode = 'explain', pageTitle, topicTitle, focusText = '' }) {
      const focus = focusText ? ` Focus area: ${focusText}.` : '';
      const templates = {
        concept: `Simple concept help for ${pageTitle}: Start with the basic idea, define the important words, then connect it to one example.${focus}`,
        solve: `Step-by-step solve mode for ${pageTitle}: 1) Identify what is given. 2) Choose the right rule or formula. 3) Substitute carefully. 4) Check the final answer.${focus}`,
        reasoning: `Reasoning help for ${pageTitle}: Explain why the rule works, not just the final answer. Compare correct and incorrect thinking.${focus}`,
        example: `Real-world example for ${pageTitle}: Use a school-level example connected to ${topicTitle}.${focus}`,
        explain: `A simpler explanation for ${pageTitle}: Use grade-appropriate language and one quick memory tip.${focus}`,
      };
      return templates[mode] || templates.explain;
    },
  };
}

function createGeminiProvider(apiKey) {
  return {
    id: 'gemini',
    async summarizePage({ pageTitle, pageBlocks }) {
      const prompt = `Summarise this page for a student in 3 bullet points. Page title: "${pageTitle}". Content: ${getPageText(pageBlocks)}`;
      return callGemini(prompt, apiKey);
    },
    async explainPage({ pageTitle, pageBlocks }) {
      const prompt = `Explain "${pageTitle}" using a real-world analogy for a student. Content context: ${getPageText(pageBlocks)}`;
      return callGemini(prompt, apiKey);
    },
    async getDetailedHelp({ grade = 'Grade 9', subjectTitle = '', topicTitle = '', pageTitle = '', pageBlocks = [], mode = 'explain', focusText = '' }) {
      const modeInstructions = {
        concept: 'Explain the concept simply using very clear language, definitions, and one memory tip.',
        solve: 'Solve the idea step by step, as if tutoring a student, and include one worked mini-example.',
        reasoning: 'Explain the reasoning deeply. Contrast correct thinking with common mistakes.',
        example: 'Give a real-life example and connect it back to the lesson clearly.',
        explain: 'Explain differently and more slowly than the original page.',
      };
      const prompt = [
        `You are helping a ${grade} student.`,
        `Subject: ${subjectTitle}. Topic: ${topicTitle}. Page: ${pageTitle}.`,
        `User asked for: ${mode}.`,
        modeInstructions[mode] || modeInstructions.explain,
        focusText ? `Focus request from the learner: ${focusText}` : '',
        'Keep the response educational, structured, and concise enough for a popup help window.',
        `Lesson context: ${getPageText(pageBlocks)}`,
      ].filter(Boolean).join(' ');
      return callGemini(prompt, apiKey);
    },
  };
}

export function getAiProvider(settings = {}) {
  const apiKey = settings.geminiApiKey || '';
  if (!apiKey || apiKey === 'mock-key') {
    return createMockProvider();
  }
  return createGeminiProvider(apiKey);
}
