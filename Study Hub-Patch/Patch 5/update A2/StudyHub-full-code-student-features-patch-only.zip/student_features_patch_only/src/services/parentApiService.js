function normalizeErrorMessage(payload, fallback) {
  if (!payload) return fallback;
  if (typeof payload === 'string') return payload;
  return payload.error || payload.message || fallback;
}

async function ensureOk(res, fallbackMessage) {
  if (!res.ok) {
    let payload = null;
    try {
      payload = await res.json();
    } catch {}
    throw new Error(normalizeErrorMessage(payload, fallbackMessage));
  }
  return res.json();
}

export async function checkBackendStatus() {
  try {
    const res = await fetch('/api/health');
    return res.ok;
  } catch {
    return false;
  }
}

export async function saveJSON(path, data) {
  const res = await fetch('/api/json', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, data })
  });
  return ensureOk(res, 'Failed to save JSON');
}

export async function readJSON(path) {
  const res = await fetch(`/api/json?path=${encodeURIComponent(path)}`);
  return ensureOk(res, 'Failed to read JSON');
}

export async function createDirectory(path) {
  const res = await fetch('/api/mkdir', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path })
  });
  return ensureOk(res, 'Failed to create directory');
}

export async function uploadAsset(file, customPath) {
  const formData = new FormData();
  formData.append('file', file);
  if (customPath) formData.append('path', customPath);

  const res = await fetch('/api/upload', {
    method: 'POST',
    body: formData
  });
  return ensureOk(res, 'Failed to upload asset');
}

export async function deleteFile(path) {
  const res = await fetch(`/api/file?path=${encodeURIComponent(path)}`, {
    method: 'DELETE'
  });
  return ensureOk(res, 'Failed to delete file');
}

export async function listFiles(path) {
  const res = await fetch(`/api/list?path=${encodeURIComponent(path)}`);
  return ensureOk(res, 'Failed to list files');
}

export async function getHistory(path) {
  const res = await fetch(`/api/history?path=${encodeURIComponent(path)}`);
  return ensureOk(res, 'Failed to load history');
}

export async function restoreVersion(path, versionName) {
  const res = await fetch('/api/restore-version', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, versionName })
  });
  return ensureOk(res, 'Failed to restore version');
}

export async function saveStudentSignal(signal) {
  const res = await fetch('/api/student-signals', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ signal })
  });
  return ensureOk(res, 'Failed to save student signal');
}

export async function getStudentSignals(params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') query.set(key, value);
  });
  const qs = query.toString();
  const res = await fetch(`/api/student-signals${qs ? `?${qs}` : ''}`);
  return ensureOk(res, 'Failed to load student signals');
}
