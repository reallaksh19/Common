import React, { useState } from 'react';
import { LinkCardBlock } from '../blocks/LinkCardBlock.jsx';
import { callGemini } from '../../services/geminiService.js';
import { ContentRenderer } from '../common/ContentRenderer.jsx';

export function RightSidebar({ clarifiers = [], relatedPages = [], settings = {}, pageBlocks = [], pageTitle = '', pageResources = [] }) {
  const [aiSummary, setAiSummary] = useState(null);
  const [aiExplanation, setAiExplanation] = useState(null);
  const [loadingAi, setLoadingAi] = useState(false);

  const getClarifierStyle = (type) => {
    switch (type) {
      case 'tip': return { bg: 'bg-blue-50', border: 'border-blue-200', icon: '💡' };
      case 'warning': return { bg: 'bg-amber-50', border: 'border-amber-200', icon: '⚠️' };
      case 'key_fact': return { bg: 'bg-indigo-50', border: 'border-indigo-500', icon: '📌' };
      case 'common_mistake': return { bg: 'bg-red-50', border: 'border-red-200', icon: '❌' };
      case 'did_you_know': return { bg: 'bg-emerald-50', border: 'border-emerald-200', icon: '🌟' };
      default: return { bg: 'bg-gray-50', border: 'border-gray-200', icon: 'ℹ️' };
    }
  };

  const getPageText = () => pageBlocks
    .filter((block) => block.type === 'paragraph' || block.type === 'heading')
    .map((block) => block.data.text || '')
    .join(' ')
    .slice(0, 1500);

  const handleSummarise = async () => {
    setLoadingAi(true);
    try {
      if (!settings.geminiApiKey) {
        setAiSummary('Here is a quick recap: focus on the main definition, the key worked example, and the most common mistake shown on this page.');
      } else {
        const response = await callGemini(`Summarise this page in 3 bullet points. ${pageTitle}. ${getPageText()}`, settings.geminiApiKey);
        setAiSummary(response);
      }
    } finally {
      setLoadingAi(false);
    }
  };

  const handleExplain = async () => {
    setLoadingAi(true);
    try {
      if (!settings.geminiApiKey) {
        setAiExplanation('Try this angle: connect the page idea to a real exam task, then re-read the helper notes and the worked example.');
      } else {
        const response = await callGemini(`Explain ${pageTitle} differently for a learner. ${getPageText()}`, settings.geminiApiKey);
        setAiExplanation(response);
      }
    } finally {
      setLoadingAi(false);
    }
  };

  return (
    <div className="right-sidebar space-y-6">
      {clarifiers.length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-3">Concept tips</h3>
          {clarifiers.map((clarifier) => {
            const style = getClarifierStyle(clarifier.type);
            return (
              <div key={clarifier.id} className={`${style.bg} ${style.border} border rounded p-3 mb-3`}>
                <div className="font-bold mb-1 flex items-center"><span className="mr-2">{style.icon}</span>{clarifier.title}</div>
                <div className="text-sm"><ContentRenderer content={clarifier.body} /></div>
              </div>
            );
          })}
        </div>
      )}

      {pageResources.length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-3">Helpful resources</h3>
          <div className="space-y-2">
            {pageResources.map((resource) => (
              <a key={resource.id} href={resource.path || resource.url} target="_blank" rel="noreferrer" className="block border rounded-lg p-3 bg-white hover:bg-gray-50">
                <div className="font-semibold">{resource.title}</div>
                <div className="text-xs text-gray-500">{resource.description}</div>
              </a>
            ))}
          </div>
        </div>
      )}

      {relatedPages.length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-3">Related pages</h3>
          {relatedPages.map((page) => (
            <div key={page.id} className="mb-2">
              <LinkCardBlock title={page.title} url={`#/topic/${page.topicId}/page/${page.id}`} linkType="page" />
            </div>
          ))}
        </div>
      )}

      {pageBlocks.length > 0 && (
        <div className="border-t pt-4">
          <h3 className="font-bold text-lg mb-3">Study support</h3>
          <div className="flex flex-col gap-2">
            <button onClick={handleSummarise} disabled={loadingAi} className="px-3 py-2 bg-purple-50 text-purple-700 border border-purple-200 rounded hover:bg-purple-100 text-sm font-bold text-left">✨ Summarise this page</button>
            <button onClick={handleExplain} disabled={loadingAi} className="px-3 py-2 bg-purple-50 text-purple-700 border border-purple-200 rounded hover:bg-purple-100 text-sm font-bold text-left">✨ Explain differently</button>
          </div>
          {loadingAi && <div className="mt-4 text-sm text-purple-600 font-bold animate-pulse">Thinking...</div>}
          {aiSummary && <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded"><h4 className="font-bold text-purple-800 text-sm mb-1">Summary</h4><p className="text-sm text-purple-900 whitespace-pre-wrap">{aiSummary}</p></div>}
          {aiExplanation && <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded"><h4 className="font-bold text-purple-800 text-sm mb-1">Different explanation</h4><p className="text-sm text-purple-900 whitespace-pre-wrap">{aiExplanation}</p></div>}
        </div>
      )}
    </div>
  );
}
