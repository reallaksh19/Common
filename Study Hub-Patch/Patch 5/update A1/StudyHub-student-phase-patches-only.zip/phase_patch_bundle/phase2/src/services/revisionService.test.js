import { buildRevisionSummary } from './revisionService.js';
import { createEmptyLearningState } from './learningProgressService.js';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const topic = {
  id: 'math-topic',
  pages: [
    { id: 'p1', title: 'Whole Numbers', revisionSummary: ['Numbers include zero'] },
    { id: 'p2', title: 'Laws of Exponents', revisionSummary: ['a^m × a^n = a^(m+n)'] }
  ]
};
const state = createEmptyLearningState();
state.pageProgress.p1 = { mastery: 0.8, needsRevision: false };
state.pageProgress.p2 = { mastery: 0.4, needsRevision: true };
const summary = buildRevisionSummary(topic, state);
assert(summary.count === 1, 'only one page should require revision');
assert(summary.cards[0].id === 'p2', 'laws of exponents should be flagged');
console.log('revisionService tests passed');
