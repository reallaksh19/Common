import { buildRevisionSummary } from '../src/services/revisionService.js';
import { createEmptyLearningState } from '../src/services/learningProgressService.js';

const topic = {
  id: 'benchmark-topic',
  pages: Array.from({ length: 400 }, (_, idx) => ({
    id: `page-${idx + 1}`,
    title: `Page ${idx + 1}`,
    revisionSummary: [`Summary ${idx + 1}`]
  }))
};
const state = createEmptyLearningState();
for (let i = 0; i < topic.pages.length; i += 1) {
  state.pageProgress[topic.pages[i].id] = { mastery: i % 7 === 0 ? 0.45 : 0.82, needsRevision: i % 5 === 0 };
}
const start = performance.now();
const summary = buildRevisionSummary(topic, state);
const elapsed = performance.now() - start;
console.log(JSON.stringify({ cards: summary.count, elapsedMs: Number(elapsed.toFixed(2)) }, null, 2));
