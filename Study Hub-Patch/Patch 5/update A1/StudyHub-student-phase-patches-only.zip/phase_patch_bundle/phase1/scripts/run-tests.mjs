import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const root = new URL('../src/', import.meta.url);
const files = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.test.js')) files.push(full);
  }
}

walk(path.resolve(new URL(root).pathname));
for (const file of files.sort()) {
  await import(pathToFileURL(file).href);
}
console.log(`Executed ${files.length} test files`);
