import { createEmptyLearningState, markPageRead, applyQuestionOutcome, calculateTopicStats } from '../src/services/learningProgressService.js';

function buildMockTopic(pageCount = 40, questionsPerPage = 10) {
  const pages = [];
  for (let i = 0; i < pageCount; i += 1) {
    pages.push({
      id: `page-${i + 1}`,
      title: `Page ${i + 1}`,
      prerequisitePageIds: i === 0 ? [] : [`page-${i}`],
      conceptTags: [`concept-${Math.ceil((i + 1) / 5)}`],
      questions: Array.from({ length: questionsPerPage }, (_, idx) => ({ id: `q-${i + 1}-${idx + 1}`, conceptTags: [`concept-${Math.ceil((i + 1) / 5)}`] }))
    });
  }
  return { id: 'mock-topic', pages };
}

const topic = buildMockTopic(60, 12);
let state = createEmptyLearningState();
const start = performance.now();
for (const page of topic.pages) {
  state = markPageRead(state, topic.id, page.id);
  for (const [index, question] of page.questions.entries()) {
    state = applyQuestionOutcome(state, {
      topicId: topic.id,
      page,
      question,
      result: { status: index % 3 === 0 ? 'wrong' : 'correct' }
    });
  }
}
const stats = calculateTopicStats(topic, state);
const elapsed = performance.now() - start;
console.log(JSON.stringify({
  pages: topic.pages.length,
  questionAttempts: Object.keys(state.questionAttempts).length,
  revisionQueue: state.revisionQueue.length,
  completionPct: stats.completionPct,
  elapsedMs: Number(elapsed.toFixed(2))
}, null, 2));
