import React, { useEffect, useRef } from 'react';
import { RightSidebar } from './RightSidebar.jsx';
import { BlockRenderer } from '../blocks/BlockRenderer.jsx';
import { QuizSection } from '../QuizSection/index.jsx';
import { isPageUnlocked } from '../../services/learningProgressService.js';

export function StudyGuide({ subject, topic, page, studyState, onMarkRead, onPageChange, onPageOpen }) {
  const lastBlockRef = useRef(null);

  useEffect(() => {
    if (page?.id && onPageOpen) {
      onPageOpen(page.id);
    }
  }, [page?.id, onPageOpen]);

  useEffect(() => {
    if (!lastBlockRef.current || !page) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        onMarkRead(page.id);
      }
    }, { threshold: 0.5 });
    observer.observe(lastBlockRef.current);
    return () => observer.disconnect();
  }, [page, onMarkRead]);

  if (!page) return <div>Page not found</div>;

  const clarifiers = page.clarifiers || [];
  const relatedPages = (page.relatedPageIds || []).map((id) => {
    const pageMeta = (topic?.pages || []).find((candidate) => candidate.id === id);
    return pageMeta ? { id: pageMeta.id, title: pageMeta.title, topicId: topic.id } : null;
  }).filter(Boolean);

  const currentIndex = topic.pages.findIndex((candidate) => candidate.id === page.id);
  const prevPage = currentIndex > 0 ? topic.pages[currentIndex - 1] : null;
  const nextPage = currentIndex < topic.pages.length - 1 ? topic.pages[currentIndex + 1] : null;

  return (
    <div className="flex h-screen overflow-hidden bg-white">
      <div className="w-72 bg-gray-50 border-r p-4 overflow-y-auto hidden md:block">
        <h2 className="font-bold text-lg mb-4">{topic.title}</h2>
        <div className="space-y-2">
          {(topic.pages || []).map((pageMeta) => {
            const progress = studyState.pageProgress?.[pageMeta.id] || {};
            const unlocked = isPageUnlocked(pageMeta, studyState);
            const isCurrent = pageMeta.id === page.id;
            return (
              <button
                key={pageMeta.id}
                disabled={!unlocked}
                onClick={() => unlocked && onPageChange(pageMeta.id)}
                className={`w-full p-2 rounded text-left text-sm ${isCurrent ? 'bg-blue-100 text-blue-800 font-bold' : unlocked ? 'hover:bg-gray-200' : 'opacity-60 cursor-not-allowed bg-gray-100'}`}
              >
                {progress.read ? '✅' : unlocked ? (isCurrent ? '▶' : '○') : '🔒'} {pageMeta.title}
                <div className="text-xs text-gray-500 ml-6 mt-1">{((progress.mastery ?? 0.5) * 100).toFixed(0)}% mastery</div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 relative">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8 border-b pb-4">
            <div className="text-sm text-gray-500 mb-2">{subject.title} · {topic.title}</div>
            <h1 className="text-4xl font-bold mb-2">{page.title}</h1>
            <div className="text-gray-500 text-sm">~{page.estimatedMinutes || 5} min read</div>
          </div>

          <div className="blocks mb-12">
            {(page.blocks || []).map((block, index) => {
              const isLast = index === page.blocks.length - 1;
              return (
                <div key={block.id} ref={isLast ? lastBlockRef : null}>
                  <BlockRenderer block={block} />
                </div>
              );
            })}
          </div>

          {page.attachments?.length > 0 && (
            <div className="mb-12 border rounded-xl p-4 bg-gray-50">
              <h3 className="font-bold text-lg mb-3">Helpful resources</h3>
              <div className="space-y-3">
                {page.attachments.map((attachment) => (
                  <a key={attachment.id} href={attachment.path || attachment.url} target="_blank" rel="noreferrer" className="block border rounded-lg p-3 bg-white hover:bg-gray-50">
                    <div className="font-semibold">{attachment.title}</div>
                    <div className="text-sm text-gray-500">{attachment.description}</div>
                  </a>
                ))}
              </div>
            </div>
          )}

          {(page.questions && page.questions.length > 0) && (
            <QuizSection
              topic={topic}
              page={page}
              questions={page.questions}
              pageBlocks={page.blocks}
              clarifiers={page.clarifiers}
              onComplete={() => onMarkRead(page.id)}
            />
          )}

          <div className="mt-12 flex justify-between pt-4 border-t">
            {prevPage ? (
              <button onClick={() => onPageChange(prevPage.id)} className="text-blue-600 hover:underline">
                ← {prevPage.title}
              </button>
            ) : <span />}
            {nextPage ? (
              <button onClick={() => onPageChange(nextPage.id)} className="px-4 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">
                Next: {nextPage.title} →
              </button>
            ) : <span />}
          </div>
        </div>
      </div>

      <div className="w-80 bg-gray-50 border-l p-4 overflow-y-auto hidden lg:block">
        <RightSidebar clarifiers={clarifiers} relatedPages={relatedPages} pageBlocks={page.blocks} pageTitle={page.title} />
      </div>
    </div>
  );
}
