function normalizePageFileCandidates(pageRef, topicFolder) {
  const original = pageRef.file || '';
  const fileName = original.split('/').pop();
  const pageIdTail = `${pageRef.id}.json`;
  const slugTail = `${pageRef.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.json`;

  return Array.from(new Set([
    original,
    fileName ? `pages/${fileName}` : null,
    `pages/${pageRef.id}.json`,
    `pages/${pageRef.id.replace(`${topicFolder}-`, '')}.json`,
    `pages/${pageRef.id.replace(/^[^-]+-/, '')}.json`,
    slugTail ? `pages/${slugTail}` : null,
    pageIdTail ? `pages/${pageIdTail}` : null
  ].filter(Boolean)));
}

export async function loadTopic(subject, topicFolder) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/topic.json`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading topic.json for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

export async function loadPage(subject, topicFolder, pageFile) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/${pageFile}`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading ${pageFile} for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

async function loadPageWithFallback(subject, topicFolder, pageRef) {
  const candidates = normalizePageFileCandidates(pageRef, topicFolder);
  for (const candidate of candidates) {
    const pageData = await loadPage(subject, topicFolder, candidate);
    if (pageData) {
      return { fileResolved: candidate, pageData };
    }
  }
  return { fileResolved: pageRef.file, pageData: null };
}

export async function loadTopicWithPages(subject, topicFolder) {
  const topic = await loadTopic(subject, topicFolder);
  if (!topic) return null;

  const fullPages = await Promise.all(
    (topic.pages || []).map(async (pageRef) => {
      const { pageData, fileResolved } = await loadPageWithFallback(subject, topicFolder, pageRef);
      return {
        ...pageRef,
        file: fileResolved,
        _fullData: pageData ? {
          ...pageData,
          estimatedMinutes: pageData.estimatedMinutes ?? pageRef.estimatedMinutes,
          difficulty: pageData.difficulty ?? pageRef.difficulty,
          prerequisitePageIds: pageData.prerequisitePageIds ?? pageRef.prerequisitePageIds,
          relatedPageIds: pageData.relatedPageIds ?? pageRef.relatedPageIds,
          conceptTags: pageData.conceptTags ?? pageRef.conceptTags ?? [],
          revisionSummary: pageData.revisionSummary ?? []
        } : null
      };
    })
  );

  return {
    ...topic,
    folder: topic.folder || topicFolder,
    _fullPages: fullPages,
    source: 'json'
  };
}
