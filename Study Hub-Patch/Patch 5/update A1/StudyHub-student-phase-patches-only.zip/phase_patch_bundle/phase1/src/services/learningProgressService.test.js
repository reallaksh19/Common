import {
  createEmptyLearningState,
  isPageUnlocked,
  getNextRecommendedPage,
  calculateTopicStats,
  applyQuestionOutcome,
  markPageRead
} from './learningProgressService.js';

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

const topic = {
  id: 'math-number-systems',
  pages: [
    { id: 'p1', title: 'Intro' },
    { id: 'p2', title: 'Exponents', prerequisitePageIds: ['p1'] }
  ]
};

let state = createEmptyLearningState();
assert(isPageUnlocked(topic.pages[0], state) === true, 'first page should be unlocked');
assert(isPageUnlocked(topic.pages[1], state) === false, 'second page should be locked before reading prerequisite');
state = markPageRead(state, topic.id, 'p1');
assert(isPageUnlocked(topic.pages[1], state) === true, 'second page should unlock after prerequisite read');
assert(getNextRecommendedPage(topic, state).id === 'p2', 'next recommended page should be p2');

const page = { id: 'p2', questions: [], conceptTags: ['laws-of-exponents'] };
const question = { id: 'q1', conceptTags: ['laws-of-exponents'] };
state = applyQuestionOutcome(state, { topicId: topic.id, page, question, result: { status: 'wrong' } });
assert(state.pageProgress.p2.needsRevision === true, 'wrong answer should flag revision');
assert(state.revisionQueue.length > 0, 'wrong answer should create revision queue entry');
state = applyQuestionOutcome(state, { topicId: topic.id, page, question, result: { status: 'correct' } });
assert(state.questionAttempts.q1.correctCount === 1, 'correct count should increment');
const stats = calculateTopicStats(topic, state);
assert(stats.totalPages === 2, 'topic should have 2 pages');
console.log('learningProgressService tests passed');
