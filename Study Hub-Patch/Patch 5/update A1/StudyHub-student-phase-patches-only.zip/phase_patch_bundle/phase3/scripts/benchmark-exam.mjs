const topic = {
  id: 'exam-topic',
  _fullPages: Array.from({ length: 30 }, (_, pageIdx) => ({
    _fullData: {
      id: `page-${pageIdx + 1}`,
      blocks: [],
      clarifiers: [],
      questions: Array.from({ length: 15 }, (_, qIdx) => ({
        id: `q-${pageIdx + 1}-${qIdx + 1}`,
        mode: qIdx % 3 === 0 ? 'exam_drill' : 'practice',
        conceptTags: qIdx % 2 === 0 ? ['laws-of-exponents'] : ['irrational-numbers']
      }))
    }
  }))
};
const start = performance.now();
const questions = topic._fullPages.flatMap((pageRef) => pageRef._fullData.questions.filter((q) => q.mode === 'exam_drill' && q.conceptTags.includes('laws-of-exponents')));
const elapsed = performance.now() - start;
console.log(JSON.stringify({ selectedQuestions: questions.length, elapsedMs: Number(elapsed.toFixed(3)) }, null, 2));
