import React from 'react';
import { QuizSection } from '../QuizSection/index.jsx';

function collectExamQuestions(topic, filterTag) {
  const pages = topic._fullPages || [];
  const collected = [];
  pages.forEach((pageRef) => {
    const page = pageRef._fullData;
    if (!page?.questions) return;
    page.questions.forEach((question) => {
      const matchesMode = question.mode === 'exam_drill' || question.examOnly;
      const matchesTag = filterTag ? (question.conceptTags || []).includes(filterTag) : true;
      if (matchesMode && matchesTag) {
        collected.push({ page, question });
      }
    });
  });
  return collected;
}

export function ExamMode({ topic, filterTag, onOpenPage }) {
  const collected = collectExamQuestions(topic, filterTag);
  const firstPage = collected[0]?.page;
  const questions = collected.map((item) => item.question);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="mb-6">
        <div className="text-sm text-gray-500 mb-2">Exam drill</div>
        <h1 className="text-3xl font-bold">{topic.title} exam practice</h1>
        <p className="text-gray-600 mt-2">This mode pulls together MCQs and practice questions marked for exam drilling.</p>
      </div>
      {questions.length === 0 ? (
        <div className="border rounded-xl p-6 bg-amber-50 text-amber-800">
          No exam-drill questions are tagged yet for {filterTag || 'this topic'}. Add question metadata like <code>mode: "exam_drill"</code> to enable this view.
        </div>
      ) : (
        <QuizSection topic={topic} page={firstPage} questions={questions} pageBlocks={firstPage?.blocks || []} clarifiers={firstPage?.clarifiers || []} />
      )}
      <div className="mt-6">
        <button onClick={() => onOpenPage(firstPage?.id || topic.pages?.[0]?.id)} className="px-4 py-2 border rounded-lg hover:bg-gray-50">Open source page</button>
      </div>
    </div>
  );
}
