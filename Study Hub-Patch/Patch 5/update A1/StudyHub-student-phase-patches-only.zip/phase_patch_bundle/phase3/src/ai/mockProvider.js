export const mockProvider = {
  mode: 'mock',
  async summarizePage({ pageTitle }) {
    return `Quick recap for ${pageTitle}: focus on the main rule, the worked example, and the common mistake highlighted on the page.`;
  },
  async explainDifferently({ pageTitle }) {
    return `Alternative explanation for ${pageTitle}: connect the idea to a smaller real-world example, then test it with a one-line calculation.`;
  }
};
