import { resolveAiProvider } from './aiProvider.js';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const mock = resolveAiProvider();
assert(mock.mode === 'mock', 'default provider should be mock');
const gemini = resolveAiProvider({ apiKey: 'abc', mode: 'gemini' });
assert(gemini.mode === 'gemini', 'gemini provider should resolve when key present');
console.log('aiProvider tests passed');
