import { mockProvider } from './mockProvider.js';
import { createGeminiProvider } from './geminiProvider.js';

export function resolveAiProvider({ apiKey, mode = 'mock' } = {}) {
  if (mode === 'gemini' && apiKey) {
    return createGeminiProvider(apiKey);
  }
  return mockProvider;
}
