import { callGemini } from '../services/geminiService.js';

export function createGeminiProvider(apiKey) {
  return {
    mode: 'gemini',
    async summarizePage({ pageTitle, pageText }) {
      return callGemini(`Summarise this page in 3 bullet points for a student. ${pageTitle}. ${pageText}`, apiKey);
    },
    async explainDifferently({ pageTitle, pageText }) {
      return callGemini(`Explain ${pageTitle} differently for a learner. ${pageText}`, apiKey);
    }
  };
}
