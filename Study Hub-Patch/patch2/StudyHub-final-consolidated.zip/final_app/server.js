import express from 'express';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { fileURLToPath } from 'url';
import createDOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3001; // Or any port you prefer
app.use(express.json());


function getSafePath(relativePath) {
  if (!relativePath) throw new Error('Missing path');
  // Resolve the full path
  const publicDir = path.resolve(__dirname, 'public');
  // Remove leading slashes from relativePath so path.join works predictably
  const cleanRelative = relativePath.replace(/^\/+/, '');
  const fullPath = path.resolve(publicDir, cleanRelative);

  if (!fullPath.startsWith(publicDir)) {
    throw new Error('Invalid path: Directory traversal not allowed');
  }
  return fullPath;
}


const upload = multer({ dest: 'public/uploads/' });

// Basic health check
app.get('/api/health', (req, res) => {
  res.json({ success: true });
});

// JSON backend endpoints
app.post('/api/json', (req, res) => {
  try {
    const { path: relativePath, data } = req.body;
    if (!relativePath || !data) return res.status(400).json({ error: 'Missing path or data' });

    const fullPath = getSafePath(relativePath);
    // Ensure directory exists
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    fs.writeFileSync(fullPath, JSON.stringify(data, null, 2));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/json', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });

    const fullPath = getSafePath(relativePath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'File not found' });

    const content = fs.readFileSync(fullPath, 'utf8');
    res.json(JSON.parse(content));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/mkdir', (req, res) => {
  try {
    const relativePath = req.body.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });

    const fullPath = getSafePath(relativePath);
    fs.mkdirSync(fullPath, { recursive: true });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });

    let finalPath = req.body.path || ('/uploads/' + file.filename + path.extname(file.originalname));
    const fullPath = getSafePath(finalPath);

    // Ensure dir
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    // Move from multer dest
    fs.renameSync(file.path, fullPath);

    // Sanitize if SVG
    if (fullPath.endsWith('.svg')) {
      const window = new JSDOM('').window;
      const DOMPurify = createDOMPurify(window);
      let content = fs.readFileSync(fullPath, 'utf8');
      content = DOMPurify.sanitize(content, { USE_PROFILES: { svg: true, svgFilters: true } });
      fs.writeFileSync(fullPath, content);
    }

    res.json({ path: finalPath.startsWith('/') ? finalPath : '/' + finalPath });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/file', (req, res) => {
  try {
    const relativePath = req.query.path;
    if (!relativePath) return res.status(400).json({ error: 'Missing path' });

    const fullPath = getSafePath(relativePath);
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/topics', (req, res) => {
  try {
    const publicDir = path.resolve(__dirname, 'public');
    const topics = [];

    const subjects = fs.readdirSync(publicDir, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .map(dirent => dirent.name);

    for (const subject of subjects) {
      const subjectPath = path.join(publicDir, subject);
      const possibleTopics = fs.readdirSync(subjectPath, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name);

      for (const topic of possibleTopics) {
        if (fs.existsSync(path.join(subjectPath, topic, 'topic.json'))) {
           topics.push({ subject, topic });
        }
      }
    }

    res.json(topics);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
