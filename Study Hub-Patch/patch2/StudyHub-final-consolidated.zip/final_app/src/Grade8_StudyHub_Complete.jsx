import React, { useState } from 'react';
import { ParentPinLock } from './components/parent/ParentPinLock.jsx';
import { ParentLayout } from './components/parent/ParentLayout.jsx';
import { ParentDashboard } from './components/parent/ParentDashboard.jsx';
import { ParentSubjectView } from './components/parent/ParentSubjectView.jsx';
import { ParentTopicEditor } from './components/parent/ParentTopicEditor.jsx';
import { ParentPageEditor } from './components/parent/ParentPageEditor.jsx';
import { ParentQuestionsEditor } from './components/parent/QuestionEditor/ParentQuestionsEditor.jsx';
import { ParentClarifiersEditor } from './components/parent/ClarifierEditor/ParentClarifiersEditor.jsx';

import { useData } from './contexts/DataContext.jsx';
import { StudyGuide } from './components/StudyGuide/index.jsx';
import { LandingPage } from './components/LandingPage.jsx';

export default function App() {
  const [parentUnlocked, setParentUnlocked] = useState(
    sessionStorage.getItem('parent_unlocked') === 'true'
  );

  const { subjects, topics, loadingState } = useData();

  const [route, setRoute] = useState(window.location.hash || '#/');

  const [pagesRead, setPagesRead] = useState(() => {
    try {
      const stored = localStorage.getItem('pagesRead');
      if (stored) return new Set(JSON.parse(stored));
    } catch (e) {}
    return new Set();
  });

  const handleMarkRead = (pageId) => {
    setPagesRead(prev => {
      const next = new Set(prev);
      next.add(pageId);
      localStorage.setItem('pagesRead', JSON.stringify(Array.from(next)));
      return next;
    });
  };

  React.useEffect(() => {
    const handleHashChange = () => setRoute(window.location.hash || '#/');
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const isAppRoute = route.startsWith('#/parent') || route.startsWith('#/student') || route.startsWith('#/topic');

  if (isAppRoute && loadingState === 'loading') {
    return <div>Loading data...</div>;
  }

  // --- PARENT ROUTES ---
  if (route.startsWith('#/parent')) {
    if (!parentUnlocked) {
      return <ParentPinLock onUnlocked={() => setParentUnlocked(true)} />;
    }

    const parts = route.replace('#/parent', '').split('/').filter(Boolean);
    let Content = null;

    if (parts.length === 0) {
      Content = <ParentDashboard subjects={subjects} topics={topics} />;
    } else if (parts[0] === 'subject' && parts[1]) {
      const subjectId = parts[1];
      const subject = subjects.find(s => s.id === subjectId);
      const subjectTopics = topics.filter(t => t.subjectId === subjectId);

      if (parts.length === 2) {
        Content = <ParentSubjectView subject={subject} topics={subjectTopics} />;
      } else if (parts[2] === 'topic' && parts[3]) {
        const topicFolder = parts[3];

        if (parts.length === 4) {
          Content = <ParentTopicEditor subjectId={subjectId} topicFolder={topicFolder} />;
        } else if (parts[4] === 'page' && parts[5]) {
          const pageSlug = parts[5];

          if (parts.length === 6) {
            Content = <ParentPageEditor subjectId={subjectId} topicFolder={topicFolder} pageSlug={pageSlug} />;
          } else if (parts[6] === 'questions') {
            const topic = topics.find(t => t.subjectId === subjectId && t.folder === topicFolder);
            const page = topic?._fullPages?.find(p => p.id === pageSlug || p.file?.includes(pageSlug))?._fullData;

            if (page) {
                Content = <ParentQuestionsEditor
                    pageSlug={pageSlug}
                    initialQuestions={page.questions || []}
                    pageBlocks={page.blocks || []}
                    pageClarifiers={page.clarifiers || []}
                    onSave={async (newQuestions) => {
                        const { saveJSON } = await import('./services/parentApiService.js');
                        const updatedPage = { ...page, questions: newQuestions };
                        await saveJSON(`${subjectId}/${topicFolder}/pages/${pageSlug}.json`, updatedPage);
                        alert('Questions saved!');
                    }}
                />;
            } else {
                Content = <div>Loading page data or page not found... (Refresh or navigate from Topic Editor)</div>;
            }
          }
        } else if (parts[4] === 'clarifiers') {
          const topic = topics.find(t => t.subjectId === subjectId && t.folder === topicFolder);

          if (topic) {
              Content = <ParentClarifiersEditor
                  subjectId={subjectId}
                  topicFolder={topicFolder}
                  topicPages={topic._fullPages || []}
              />;
          } else {
              Content = <div>Loading topic data...</div>;
          }
        }
      }
    }

    return <ParentLayout>{Content || <div>Route not found</div>}</ParentLayout>;
  }

  // --- STUDENT ROUTES ---
  if (route.startsWith('#/topic/')) {
    const parts = route.replace('#/topic/', '').split('/');
    const topicId = parts[0];
    const topic = topics.find(t => t.id === topicId);

    if (!topic) return <div>Topic not found</div>;
    const subject = subjects.find(s => s.id === topic.subjectId);

    if (parts.length >= 3 && parts[1] === 'page') {
      const pageId = parts[2];
      const page = topic._fullPages?.find(p => p.id === pageId)?._fullData;

      return (
        <StudyGuide
          subject={subject}
          topic={topic}
          page={page}
          pagesRead={pagesRead}
          onMarkRead={handleMarkRead}
          settings={{ geminiApiKey: localStorage.getItem('geminiApiKey') || '' }}
          onPageChange={(targetId) => {
            if (targetId === 'home') {
              window.location.hash = `#/topic/${topic.id}`;
            } else {
              window.location.hash = `#/topic/${topic.id}/page/${targetId}`;
            }
          }}
        />
      );
    }

    return (
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">{topic.title} Pages</h1>
        {topic.pages?.map(p => (
          <div key={p.id} className="mb-2 border p-4 rounded hover:bg-gray-50 flex justify-between">
            <a href={`#/topic/${topic.id}/page/${p.id}`} className="text-blue-600 font-bold block">{p.title}</a>
            {pagesRead.has(p.id) && <span className="text-green-600 font-bold">✅ Read</span>}
          </div>
        ))}
      </div>
    );
  }

  if (route === '#/student') {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Student Dashboard</h1>
        <div className="grid grid-cols-2 gap-4">
          {subjects.map(s => (
            <div key={s.id} className="border p-6 rounded shadow-sm hover:shadow-md">
              <h2 className="text-xl font-bold mb-2">{s.title}</h2>
              {topics.filter(t => t.subjectId === s.id).map(t => (
                <div key={t.id}>
                  <a href={`#/topic/${t.id}`} className="text-blue-600 hover:underline">{t.title}</a>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="mt-8 pt-4 border-t">
           <a href="#/parent" className="text-gray-500 hover:text-gray-800">Parent Access</a>
           <a href="#/" className="ml-4 text-gray-500 hover:text-gray-800">Back Home</a>
        </div>
      </div>
    );
  }

  return <LandingPage />;
}
