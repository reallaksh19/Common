import React from 'react';

export function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <header className="bg-white/80 backdrop-blur-md border-b border-indigo-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="text-3xl">📚</span>
            <span className="font-bold text-2xl text-indigo-900 tracking-tight">StudyHub</span>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="#features" className="text-gray-600 hover:text-indigo-600 font-medium">Features</a>
            <a href="#how-it-works" className="text-gray-600 hover:text-indigo-600 font-medium">How it Works</a>
            <a href="#testimonials" className="text-gray-600 hover:text-indigo-600 font-medium">Success Stories</a>
          </nav>
          <div className="flex gap-4">
            <a href="#/parent" className="px-5 py-2 text-indigo-600 font-bold border-2 border-indigo-100 rounded-lg hover:bg-indigo-50 transition-colors">
              Parent Portal
            </a>
            <a href="#/student" className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-lg shadow-md hover:bg-indigo-700 hover:shadow-lg transition-all transform hover:-translate-y-0.5">
              Student Login
            </a>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="max-w-6xl mx-auto px-6 py-20 md:py-32 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-block px-4 py-1.5 bg-indigo-100 text-indigo-700 font-bold rounded-full text-sm mb-4">
              ✨ New: Parent Content Dashboard
            </div>
            <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 leading-tight">
              Master Your Studies <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                with Confidence
              </span>
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              An interactive learning platform tailored for your child. Featuring rich visual content, dynamic quizzes, and personalized concept clarifiers.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <a href="#/student" className="px-8 py-4 bg-indigo-600 text-white font-bold rounded-xl shadow-lg hover:bg-indigo-700 hover:shadow-xl transition-all transform hover:-translate-y-1">
                Start Learning Now →
              </a>
              <a href="#/parent" className="px-8 py-4 bg-white text-indigo-600 font-bold rounded-xl shadow-md border border-indigo-100 hover:bg-indigo-50 transition-colors">
                Explore Parent Tools
              </a>
            </div>

            <div className="flex items-center gap-6 pt-8 text-sm text-gray-500 font-medium border-t border-gray-200">
              <div className="flex items-center gap-2">
                <span className="text-green-500">✓</span> No Credit Card Required
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">✓</span> Free for 14 Days
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-400 to-purple-400 rounded-3xl transform rotate-3 scale-105 opacity-20 blur-xl"></div>
            <div className="bg-white border border-gray-200 rounded-3xl shadow-2xl p-6 relative z-10 transform -rotate-1 hover:rotate-0 transition-transform duration-300">
              <div className="flex gap-2 mb-4 border-b pb-4">
                <div className="w-3 h-3 rounded-full bg-red-400"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                <div className="w-3 h-3 rounded-full bg-green-400"></div>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-gray-800">Physics · Gravity</h3>
                  <span className="text-xs font-bold bg-indigo-100 text-indigo-700 px-2 py-1 rounded">Module 3/8</span>
                </div>
                <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                  <span className="text-2xl">🌍 🚀 🌙</span>
                </div>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-100 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-100 rounded w-full"></div>
                  <div className="h-3 bg-gray-100 rounded w-5/6"></div>
                </div>
                <div className="pt-4 border-t flex justify-between items-center">
                  <div className="flex gap-2">
                    <span className="px-2 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded text-xs font-bold">⚠️ Warning</span>
                    <span className="px-2 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded text-xs font-bold">💡 Tip</span>
                  </div>
                  <button className="bg-indigo-600 text-white px-4 py-1.5 rounded text-sm font-bold">Resume</button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature Grid */}
        <section id="features" className="bg-white py-20 border-y border-gray-100">
          <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Everything you need to succeed</h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">Built from the ground up to make science and math intuitive, interactive, and fun.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: '📐', title: 'Interactive Math', desc: 'Beautifully rendered KaTeX equations that scale perfectly on any device.' },
                { icon: '📊', title: 'Visual Diagrams', desc: 'Rich SVG diagrams and Mermaid charts that bring complex concepts to life.' },
                { icon: '🤖', title: 'AI Assistant', desc: 'Stuck on a concept? Use the built-in Gemini AI to explain things differently.' },
                { icon: '🎯', title: 'Smart Quizzes', desc: 'Not just multiple choice. Numeric tolerances, short answers, and concept strengtheners.' },
                { icon: '👨‍👩‍👧', title: 'Parent Dashboard', desc: 'Create, edit, and organize curriculum with an intuitive drag-and-drop block editor.' },
                { icon: '💡', title: 'Concept Clarifiers', desc: 'Targeted tips, warnings, and common mistakes appear right when students need them.' }
              ].map((feature, i) => (
                <div key={i} className="p-6 rounded-2xl bg-gray-50 border border-gray-100 hover:bg-indigo-50 hover:border-indigo-100 transition-colors">
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-gray-400 py-12 text-center">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2 text-white">
            <span className="text-2xl">📚</span>
            <span className="font-bold text-xl tracking-tight">StudyHub</span>
          </div>
          <div className="text-sm">
            © 2026 Harshi App. All rights reserved.
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#/parent" className="hover:text-white transition-colors">Parent Access</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
