import React from 'react';
import { HintCard } from './HintCard.jsx';
import { BlockRenderer } from '../blocks/BlockRenderer.jsx';

export function SupportMaterialCard({ hint, clarifiers = [], supportBlocks = [], retryAllowed, onRetry }) {
  const getClarifierStyle = (type) => {
    switch (type) {
      case 'tip': return { bg: 'bg-blue-50', border: 'border-blue-200', icon: '💡' };
      case 'warning': return { bg: 'bg-amber-50', border: 'border-amber-200', icon: '⚠️' };
      case 'key_fact': return { bg: 'bg-indigo-50', border: 'border-indigo-500', icon: '📌' };
      case 'common_mistake': return { bg: 'bg-red-50', border: 'border-red-200', icon: '❌' };
      case 'did_you_know': return { bg: 'bg-emerald-50', border: 'border-emerald-200', icon: '🌟' };
      default: return { bg: 'bg-gray-50', border: 'border-gray-200', icon: 'ℹ️' };
    }
  };

  return (
    <div className="support-material-card border-t border-gray-200 pt-4 mt-4">
      {hint && <HintCard text={hint} />}

      {clarifiers.map(clarifier => {
        const style = getClarifierStyle(clarifier.type);
        return (
          <div key={clarifier.id} className={`${style.bg} ${style.border} border rounded p-3 mb-3 text-sm`}>
            <div className="font-bold mb-1 flex items-center">
              <span className="mr-2">{style.icon}</span>
              {clarifier.title}
            </div>
            <div dangerouslySetInnerHTML={{ __html: clarifier.body }} />
          </div>
        );
      })}

      {supportBlocks.map(block => (
        <div key={block.id} className="mb-4">
          <BlockRenderer block={block} />
        </div>
      ))}

      <div className="flex gap-4 mt-4">
        {retryAllowed && (
          <button onClick={onRetry} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Try again
          </button>
        )}
        <button className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50">
          Move on →
        </button>
      </div>
    </div>
  );
}
