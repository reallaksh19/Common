import React from 'react';

export function TopicHome({ subject, topic, progress = { pagesRead: new Set() } }) {
  const pages = topic.pages || [];

  return (
    <div className="topic-home max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <div className="text-gray-500 text-sm mb-2">← {subject.title}</div>
        <h1 className="text-3xl font-bold mb-4">{topic.title}</h1>
        <div className="flex gap-4 text-sm text-gray-600 pb-4 border-b">
          <span>{pages.length} pages</span>
          <span>~{pages.reduce((acc, p) => acc + (p.estimatedMinutes || 0), 0)} min</span>
          <span>{topic.difficulty || 'Medium'}</span>
        </div>
      </div>

      <div className="page-list space-y-2">
        {pages.map((page, index) => {
          const isRead = progress.pagesRead.has(page.id);
          const prereqsMet = (page.prerequisitePageIds || []).every(id => progress.pagesRead.has(id));
          const isNext = !isRead && index > 0 && progress.pagesRead.has(pages[index-1].id);
          const isFirst = index === 0;

          let icon = '○';
          if (isRead) icon = '✅';
          else if (!prereqsMet) icon = '🔒';
          else if (isNext || (isFirst && !isRead)) icon = '▶';

          return (
            <div key={page.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded">
              <div className="flex items-center gap-4">
                <span className="w-6 text-center">{icon}</span>
                <span className={!prereqsMet ? 'text-gray-400' : isRead ? 'text-gray-600' : 'font-medium'}>
                  {page.title}
                </span>
                {!prereqsMet && <span className="text-xs text-amber-600 bg-amber-50 px-2 rounded">Prerequisite required</span>}
                {isNext && <span className="text-xs text-blue-600 bg-blue-50 px-2 rounded">Next up</span>}
              </div>
              <span className="text-sm text-gray-500">{page.estimatedMinutes} min</span>
            </div>
          );
        })}
      </div>

      <div className="mt-8 pt-4 border-t flex gap-4">
        <button className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">
          Resume →
        </button>
        <button className="px-6 py-2 border border-gray-300 rounded hover:bg-gray-50">
          Start from beginning
        </button>
      </div>
    </div>
  );
}
