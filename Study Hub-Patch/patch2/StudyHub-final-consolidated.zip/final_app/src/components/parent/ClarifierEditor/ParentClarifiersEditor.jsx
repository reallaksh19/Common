import React, { useState } from 'react';
import { ClarifierForm } from './ClarifierForm.jsx';
import { generateClarifierId } from '../../../utils/idFactory.js';

import { saveJSON } from '../../../services/parentApiService.js';

export function ParentClarifiersEditor({ subjectId, topicFolder, topicPages = [] }) {
  const [selectedPageId, setSelectedPageId] = useState(topicPages[0]?.id || null);

  const pageObj = topicPages.find(p => p.id === selectedPageId);
  const pageSlug = pageObj?.file?.split('/').pop().replace('.json', '') || selectedPageId;
  const initialClarifiers = pageObj?._fullData?.clarifiers || [];

  const onSave = async (updatedClarifiers) => {
     if (!pageObj) return;
     const updatedPage = { ...pageObj._fullData, clarifiers: updatedClarifiers };
     await saveJSON(`${subjectId}/${topicFolder}/pages/${pageSlug}.json`, updatedPage);
     alert('Clarifiers saved!');
  };

  const [clarifiers, setClarifiers] = useState(initialClarifiers);
  const [selectedId, setSelectedId] = useState(null);

  React.useEffect(() => {
    setClarifiers(initialClarifiers);
  }, [selectedPageId]);

  const handleAdd = () => {
    const newId = generateClarifierId(pageSlug, clarifiers.length + 1);
    const newC = { id: newId, type: 'tip', title: 'New Tip', body: '' };
    setClarifiers([...clarifiers, newC]);
    setSelectedId(newId);
  };

  const handleChange = (id, newClarifier) => {
    setClarifiers(clarifiers.map(c => c.id === id ? newClarifier : c));
  };

  return (
    <div>
      <div className="p-4 border-b bg-gray-50 flex items-center">
        <label className="font-bold mr-4">Select Page:</label>
        <select className="border rounded p-2" value={selectedPageId || ''} onChange={(e) => { setSelectedPageId(e.target.value); setClarifiers(topicPages.find(p => p.id === e.target.value)?._fullData?.clarifiers || []); }}>
          {topicPages.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
        <button onClick={() => onSave(clarifiers)} className="ml-auto bg-blue-600 text-white px-4 py-2 rounded font-bold">💾 Save</button>
      </div>
      <div className="flex h-[calc(100vh-180px)] border rounded bg-white overflow-hidden">
      <div className="w-1/3 border-r pr-4 flex flex-col p-4">
        <button onClick={handleAdd} className="w-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold p-2 rounded mb-4">
          + Add Clarifier
        </button>
        <div className="flex-1 overflow-y-auto">
          {clarifiers.map((c) => (
            <div
              key={c.id}
              onClick={() => setSelectedId(c.id)}
              className={`p-3 mb-2 border rounded cursor-pointer ${c.id === selectedId ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
            >
              <div className="text-xs text-gray-500 font-bold uppercase">{c.type}</div>
              <div className="text-sm font-bold">{c.title || '(Untitled)'}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-1 p-4 overflow-y-auto flex flex-col">
        <div className="flex justify-end mb-4">
          <button onClick={() => onSave(clarifiers)} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
            💾 Save Clarifiers
          </button>
        </div>
        <ClarifierForm
          clarifier={clarifiers.find(c => c.id === selectedId)}
          onChange={handleChange}
        />
      </div>
    </div>
    </div>
  );
}
