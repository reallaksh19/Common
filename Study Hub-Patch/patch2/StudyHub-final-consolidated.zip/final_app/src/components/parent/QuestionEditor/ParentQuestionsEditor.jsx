import React, { useState } from 'react';
import { QuestionForm } from './QuestionForm.jsx';
import { generateQuestionId } from '../../../utils/idFactory.js';

export function ParentQuestionsEditor({ pageSlug, initialQuestions = [], pageBlocks = [], pageClarifiers = [], onSave }) {
  const [questions, setQuestions] = useState(initialQuestions);
  const [selectedId, setSelectedId] = useState(null);

  const handleAddQuestion = () => {
    const newId = generateQuestionId(pageSlug, questions.length + 1);
    const newQ = { id: newId, type: 'mcq', prompt: '' };
    setQuestions([...questions, newQ]);
    setSelectedId(newId);
  };

  const handleChange = (id, newQuestion) => {
    setQuestions(questions.map(q => q.id === id ? newQuestion : q));
  };

  const handleSave = () => {
    onSave(questions);
  };

  return (
    <div className="flex h-[calc(100vh-120px)] border rounded bg-white overflow-hidden">
      <div className="w-1/3 border-r pr-4 flex flex-col p-4">
        <button onClick={handleAddQuestion} className="w-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold p-2 rounded mb-4">
          + Add Question
        </button>
        <button onClick={handleSave} className="w-full bg-blue-600 text-white font-bold p-2 rounded mb-4">
          💾 Save
        </button>
        <div className="flex-1 overflow-y-auto">
          {questions.map((q, idx) => (
            <div
              key={q.id}
              onClick={() => setSelectedId(q.id)}
              className={`p-3 mb-2 border rounded cursor-pointer ${q.id === selectedId ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
            >
              <div className="text-xs text-gray-500 font-bold uppercase">{q.type}</div>
              <div className="text-sm truncate">{q.prompt || '(Empty prompt)'}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-1 p-4 overflow-y-auto flex flex-col">
        <div className="flex justify-end mb-4">
          <button onClick={handleSave} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
            💾 Save Questions
          </button>
        </div>
        <QuestionForm
          question={questions.find(q => q.id === selectedId)}
          pageBlocks={pageBlocks}
          pageClarifiers={pageClarifiers}
          onChange={handleChange}
        />
      </div>
    </div>
  );
}
