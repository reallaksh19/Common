import React, { useState, useEffect } from 'react';
import { ParentPageEditor } from './ParentPageEditor.jsx';
import { validatePage, validateTopic } from '../../content/contentPackSchema.js';
import { readJSON, saveJSON } from '../../services/parentApiService.js';
import { slugify } from '../../utils/slugify.js';

export function ParentTopicEditor({ subjectId, topicFolder }) {
  const [topicData, setTopicData] = useState({ id: topicFolder, subjectId, pages: [] });
  const [activePageSlug, setActivePageSlug] = useState(null);
  const [validationErrors, setValidationErrors] = useState([]);

  // Use to trigger re-renders dynamically on reorder/add
  const [key, setKey] = useState(0);

  const topicFilePath = `${subjectId}/${topicFolder}/topic.json`;

  useEffect(() => {
    async function load() {
      try {
        const fileData = await readJSON(topicFilePath);
        setTopicData(fileData);
        if (fileData.pages && fileData.pages.length > 0) {
          setActivePageSlug(fileData.pages[0].id);
        }
      } catch(err) {
        console.error("Failed to load topic", err);
      }
    }
    load();
  }, [topicFilePath]);

  useEffect(() => {
    const res = validateTopic(topicData);
    if (!res.success) {
      setValidationErrors([res.error]);
    } else {
      setValidationErrors([]);
    }
  }, [topicData]);

  const handleAddPage = async () => {
    const title = window.prompt("Enter new page title:");
    if (!title) return;

    const slug = slugify(title);
    const newPageMeta = {
      id: `${subjectId}-${topicFolder}-${slug}`,
      file: `pages/${slug}.json`,
      title,
      order: (topicData.pages?.length || 0) + 1,
      estimatedMinutes: 10
    };

    const newTopicData = { ...topicData, pages: [...(topicData.pages || []), newPageMeta] };

    // Save blank page file
    const blankPage = {
      id: newPageMeta.id,
      topicId: topicData.id,
      title: title,
      blocks: [], clarifiers: [], questions: []
    };

    try {
      await saveJSON(`${subjectId}/${topicFolder}/pages/${slug}.json`, blankPage);
      await saveJSON(topicFilePath, newTopicData);
      setTopicData(newTopicData);
      setActivePageSlug(newPageMeta.id);
    } catch(err) {
      alert("Failed to add page");
    }
  };

  const handlePageSelect = (pageId) => {
    setActivePageSlug(pageId);
    // Ideally update hash to trigger router correctly
    window.location.hash = `#/parent/subject/${subjectId}/topic/${topicFolder}/page/${pageId.split('-').pop()}`;
  };

  return (
    <div className="flex h-[calc(100vh-80px)]">
      {/* Left Tree */}
      <div className="w-1/4 border-r pr-4 flex flex-col p-4 bg-gray-50">
        <h2 className="font-bold text-xl mb-4">Pages</h2>
        <div className="space-y-2">
          {(topicData.pages || []).map(p => (
            <div
              key={p.id}
              className={`p-2 cursor-pointer border rounded ${p.id === activePageSlug ? 'bg-indigo-100 border-indigo-400 font-bold' : 'bg-white hover:border-indigo-200'}`}
              onClick={() => handlePageSelect(p.id)}
            >
              <div className="flex justify-between">
                <span>{p.title}</span>
                <span className="text-gray-400 text-xs">{p.estimatedMinutes}m</span>
              </div>
            </div>
          ))}
          <button onClick={handleAddPage} className="w-full mt-4 p-2 bg-white border border-dashed border-gray-400 rounded text-gray-600 hover:text-indigo-600 hover:border-indigo-400 transition-colors">
            + Add Page
          </button>
        </div>
      </div>

      {/* Center Workspace */}
      <div className="flex-1 p-4 overflow-y-auto bg-white">
        {activePageSlug ? (
          <ParentPageEditor subjectId={subjectId} topicFolder={topicFolder} pageSlug={activePageSlug.split('-').pop()} />
        ) : (
          <div className="text-center text-gray-500 mt-20">Select a page or create a new one</div>
        )}
      </div>

      {/* Right Meta Panel */}
      <div className="w-1/4 pl-4 border-l bg-gray-50 p-4">
        <div className="mb-4 pb-2 border-b">
          {validationErrors.length === 0 ? (
            <span className="text-green-600 font-bold flex items-center gap-2"><span className="text-xl">✅</span> Valid Topic Config</span>
          ) : (
            <span className="text-amber-600 font-bold">⚠️ {validationErrors.length} validation errors</span>
          )}
        </div>
        {validationErrors.map((err, i) => (
          <div key={i} className="text-red-500 text-sm mb-2 p-2 bg-red-50 border border-red-200 rounded">{err}</div>
        ))}

        <div className="mt-8 space-y-4 text-sm text-gray-600">
           <div><strong>Topic Title:</strong> {topicData.title}</div>
           <div><strong>Difficulty:</strong> {topicData.difficulty}</div>
           <div><strong>Estimated Time:</strong> {topicData.estimatedMinutes}m</div>
        </div>
      </div>
    </div>
  );
}
