import React, { useState, useEffect, useRef } from 'react';
import { checkBackendStatus, saveJSON, createDirectory } from '../../services/parentApiService.js';
import { exportPack } from '../../services/contentExportService.js';
import JSZip from 'jszip';
import { ContentPackSchema } from '../../content/contentPackSchema.js';
import { useData } from '../../contexts/DataContext.jsx';

export function ParentDashboard({ subjects = [], topics = [] }) {
  const [backendOk, setBackendOk] = useState(true);
  const fileInputRef = useRef(null);
  const [importErrors, setImportErrors] = useState([]);
  const [isImporting, setIsImporting] = useState(false);

  useEffect(() => {
    checkBackendStatus().then(ok => setBackendOk(ok));
  }, []);

  const handleExport = () => {
    exportPack(subjects, topics);
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsImporting(true);
    setImportErrors([]);

    try {
      const zip = await JSZip.loadAsync(file);
      const contentFile = zip.file('content-pack.json');

      if (!contentFile) {
        throw new Error('content-pack.json not found in zip');
      }

      const contentStr = await contentFile.async('string');
      const pack = JSON.parse(contentStr);

      const validation = ContentPackSchema.safeParse(pack);
      if (!validation.success) {
        setImportErrors(validation.error.errors.map(err => `${err.path.join('.')}: ${err.message}`));
        setIsImporting(false);
        return;
      }


      // Process and save files
      for (const topic of pack.topics) {
        // find subject by id ignoring case, or fallback to capitalized ID
        const subject = subjects.find(s => s.id.toLowerCase() === topic.subjectId.toLowerCase()) || { title: topic.subjectId.charAt(0).toUpperCase() + topic.subjectId.slice(1) };
        const subjectFolder = subject.title;
        // topic ID usually starts with subjectId- (e.g., physics-optics) -> we want optics
        const topicFolder = topic.id.includes('-') ? topic.id.split('-').slice(1).join('-') : topic.id;

        await createDirectory(`${subjectFolder}/${topicFolder}/pages`);
        await saveJSON(`${subjectFolder}/${topicFolder}/topic.json`, topic);
      }

      for (const [pageId, pageData] of Object.entries(pack.pages)) {
        // pageId: physics-optics-light-and-visibility -> physics / optics / light-and-visibility
        const parts = pageId.split('-');
        let subjectId = parts[0];
        let topicFolder = parts[1];
        let pageSlug = parts.slice(2).join('-');

        // Sometimes the id logic doesn't cleanly map to 3 parts. Let's use the parent topic data if available:
        // pageData.topicId (e.g. physics-optics)
        if (pageData.topicId) {
            const topicParts = pageData.topicId.split('-');
            subjectId = topicParts[0];
            topicFolder = topicParts.slice(1).join('-') || pageData.topicId;
        }

        const subject = subjects.find(s => s.id.toLowerCase() === subjectId.toLowerCase()) || { title: subjectId.charAt(0).toUpperCase() + subjectId.slice(1) };
        // if topicFolder wasn't fixed by topic logic:

        await saveJSON(`${subject.title}/${topicFolder}/pages/${pageSlug}.json`, pageData);
      }

      alert(`Import complete: ${pack.topics.length} topics, ${Object.keys(pack.pages).length} pages restored.`);
      // Ideally refresh DataContext here
      window.location.reload();
    } catch (err) {
      setImportErrors([err.message]);
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div>
      {!backendOk && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 flex items-center shadow-sm">
          <span className="text-2xl mr-3">🔌</span>
          <div>
            <p className="font-bold text-lg">Backend server not running</p>
            <p>Changes cannot be saved to disk. Start the server with <code className="bg-red-200 px-1 rounded">node server.js</code></p>
          </div>
        </div>
      )}

      {importErrors.length > 0 && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 shadow-sm">
          <strong className="font-bold">Import failed:</strong>
          <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
            {importErrors.map((err, i) => <li key={i} className="font-mono">{err}</li>)}
          </ul>
          <button onClick={() => setImportErrors([])} className="mt-3 text-sm underline font-bold hover:text-red-900">Dismiss</button>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Subjects Dashboard</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 font-bold shadow-sm transition-colors flex items-center">
          <span className="mr-2">+</span> Add Subject
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {subjects.map(sub => {
          const subTopics = topics.filter(t => t.subjectId === sub.id);
          const pageCount = subTopics.reduce((acc, t) => acc + (t.pages?.length || 0), 0);

          return (
            <div key={sub.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4 pb-4 border-b">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-xl shadow-sm mr-4" style={{ backgroundColor: sub.color || '#4f46e5' }}>
                  {/* Simplistic icon mapping based on typical names */}
                  {sub.title === 'Physics' ? '⚛️' : sub.title === 'Mathematics' ? '➗' : sub.title === 'Chemistry' ? '🧪' : '📚'}
                </div>
                <h3 className="text-xl font-bold text-gray-800">{sub.title}</h3>
              </div>
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span className="font-medium">Topics</span>
                <span className="bg-gray-100 px-2 py-0.5 rounded font-bold">{subTopics.length}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600 mb-6">
                <span className="font-medium">Pages</span>
                <span className="bg-gray-100 px-2 py-0.5 rounded font-bold">{pageCount}</span>
              </div>
              <a href={`#/parent/subject/${sub.id}`} className="block w-full text-center bg-indigo-50 text-indigo-700 font-bold py-2 rounded hover:bg-indigo-100 transition-colors">
                Manage content →
              </a>
            </div>
          );
        })}
      </div>

      <div className="flex gap-4 border-t pt-6 bg-white p-6 rounded-xl shadow-sm border mt-8">
        <div className="flex-1">
          <h3 className="font-bold text-lg mb-2">Content Operations</h3>
          <p className="text-gray-500 text-sm mb-4">Export your current topics and pages into a portable ZIP pack, or restore from an existing pack.</p>
          <div className="flex gap-4">
            <button onClick={handleExport} className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 flex items-center font-medium bg-white shadow-sm">
              <span className="mr-2 text-indigo-600 font-bold">⬇</span> Export Pack
            </button>
            <button disabled={isImporting} onClick={() => fileInputRef.current.click()} className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-50 flex items-center font-medium bg-white shadow-sm">
              <span className="mr-2 text-indigo-600 font-bold">⬆</span> {isImporting ? 'Importing...' : 'Import Pack'}
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept=".zip" onChange={handleImport} />
          </div>
        </div>
      </div>
    </div>
  );
}
