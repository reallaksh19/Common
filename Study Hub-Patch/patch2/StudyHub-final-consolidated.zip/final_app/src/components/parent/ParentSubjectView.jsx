import React from 'react';
import { slugify } from '../../utils/slugify.js';
import { createDirectory, saveJSON } from '../../services/parentApiService.js';

export function ParentSubjectView({ subject, topics }) {
  if (!subject) return <div>Subject not found</div>;

  const handleAddTopic = async () => {
    const title = window.prompt("Enter new topic title:");
    if (!title) return;

    const folder = slugify(title);
    const newTopic = {
      id: `${subject.id}-${folder}`,
      subjectId: subject.id,
      title,
      difficulty: 'medium',
      estimatedMinutes: 30,
      pages: []
    };

    try {
      const subjectFolder = subject.title;
      await createDirectory(`${subjectFolder}/${folder}/pages`);
      await createDirectory(`${subjectFolder}/${folder}/assets`);
      await saveJSON(`${subjectFolder}/${folder}/topic.json`, newTopic);
      window.location.hash = `#/parent/subject/${subject.id}/topic/${folder}`;
    } catch (err) {
      alert("Failed to create topic: Backend might be unavailable.");
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">{subject.title} Topics</h1>
        <button onClick={handleAddTopic} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          + Add Topic
        </button>
      </div>

      <div className="bg-white border rounded shadow-sm">
        {topics.map(topic => (
          <div key={topic.id} className="flex items-center justify-between p-4 border-b last:border-0 hover:bg-gray-50">
            <div>
              <div className="font-bold text-lg">{topic.title}</div>
              <div className="text-sm text-gray-500">
                {topic.pages?.length || 0} pages · {topic.difficulty || 'Medium'}
              </div>
            </div>
            <div className="flex gap-2">
              {/* Note: The folder is assumed from the id slug logic here for simplicity, in a real app it might be explicit or matched */}
              <a href={`#/parent/subject/${subject.id}/topic/${topic.id.replace(`${subject.id}-`, '')}`} className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded text-sm">
                Edit
              </a>
            </div>
          </div>
        ))}
        {topics.length === 0 && <div className="p-8 text-center text-gray-500">No topics yet.</div>}
      </div>
    </div>
  );
}
