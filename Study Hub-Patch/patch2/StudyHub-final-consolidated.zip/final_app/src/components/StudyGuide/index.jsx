import React, { useEffect, useRef } from 'react';
import { RightSidebar } from './RightSidebar.jsx';
import { BlockRenderer } from '../blocks/BlockRenderer.jsx';
import { QuizSection } from '../QuizSection/index.jsx';

export function StudyGuide({ subject, topic, page, pagesRead, onMarkRead, onPageChange }) {
  const lastBlockRef = useRef(null);

  useEffect(() => {
    if (!lastBlockRef.current || !page) return;

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        onMarkRead(page.id);
      }
    }, { threshold: 0.5 });

    observer.observe(lastBlockRef.current);
    return () => observer.disconnect();
  }, [page, onMarkRead]);

  if (!page) return <div>Page not found</div>;

  const clarifiers = page.clarifiers || [];
  const relatedPages = (page.relatedPageIds || []).map(id => {
    const p = (topic?.pages || []).find(p => p.id === id);
    return p ? { id: p.id, title: p.title } : null;
  }).filter(Boolean);

  const currentIndex = topic.pages.findIndex(p => p.id === page.id);
  const prevPage = currentIndex > 0 ? topic.pages[currentIndex - 1] : null;
  const nextPage = currentIndex < topic.pages.length - 1 ? topic.pages[currentIndex + 1] : null;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Left Rail Nav */}
      <div className="w-64 bg-gray-50 border-r p-4 overflow-y-auto">
        <h2 className="font-bold text-lg mb-4">{topic.title}</h2>
        <div className="space-y-2">
          {topic.pages.map((p, idx) => {
            const isRead = pagesRead.has(p.id);
            const isCurrent = p.id === page.id;
            return (
              <div
                key={p.id}
                onClick={() => onPageChange(p.id)}
                className={`p-2 rounded cursor-pointer text-sm ${isCurrent ? 'bg-blue-100 text-blue-800 font-bold' : 'hover:bg-gray-200'}`}
              >
                {isRead ? '✅' : (isCurrent ? '▶' : '○')} {p.title}
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-8 relative">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8 border-b pb-4">
            <h1 className="text-4xl font-bold mb-2">{page.title}</h1>
            <div className="text-gray-500 text-sm">~{page.estimatedMinutes || 5} min read</div>
          </div>

          <div className="blocks mb-12">
            {(page.blocks || []).map((block, idx) => {
              const isLast = idx === page.blocks.length - 1;
              return (
                <div key={block.id} ref={isLast ? lastBlockRef : null}>
                  <BlockRenderer block={block} />
                </div>
              );
            })}
          </div>

          {(page.questions && page.questions.length > 0) && (
            <QuizSection
              questions={page.questions}
              pageBlocks={page.blocks}
              clarifiers={page.clarifiers}
              onComplete={() => onMarkRead(page.id)}
            />
          )}

          <div className="mt-12 flex justify-between pt-4 border-t">
            {prevPage ? (
              <button onClick={() => onPageChange(prevPage.id)} className="text-blue-600 hover:underline">
                ← {prevPage.title}
              </button>
            ) : <span />}
            {nextPage ? (
              <button onClick={() => onPageChange(nextPage.id)} className="px-4 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">
                Next: {nextPage.title} →
              </button>
            ) : <span />}
          </div>
        </div>
      </div>

      {/* Right Sidebar */}
      <div className="w-80 bg-gray-50 border-l p-4 overflow-y-auto hidden lg:block">
        <RightSidebar
          clarifiers={clarifiers}
          relatedPages={relatedPages}
          pageBlocks={page.blocks}
          pageTitle={page.title}
          settings={{ geminiApiKey: localStorage.getItem('geminiApiKey') || '' }}
        />
      </div>
    </div>
  );
}
