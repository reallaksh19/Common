# Mathematics Class 9 — Proof of Irrationality of √2 and √3
**Topic ID:** `topic_06_mathematics_9`
**Concept Tags:** `irrational-proof`, `contradiction`, `coprime`, `algebraic-proof`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is a Mathematical Proof?
- **Page ID:** `page_1_what_is_proof`
- **Page Objective:** Understand the concept of a proof and the specific technique of Proof by Contradiction.
- **Main Lesson Text:** In science, you prove things by doing an experiment. In math, experiments aren't good enough! If I want to prove 'all even numbers are divisible by 2', I can't just check 2, 4, 6, and 8 and say 'it works!'. I have to use pure logic to prove it works for EVERY even number until infinity. That logical argument is called a **Proof**. In this chapter, we will use a specific trick called **Proof by Contradiction**.
- **Intuition-First Explanation:** Proof by contradiction is like a detective assuming a suspect is innocent. The detective takes that assumption, follows the logic, and finds an impossible situation (a contradiction!). Because the result is impossible, the initial assumption of innocence MUST be wrong. Therefore, the suspect is guilty.
- **Formal Definition / Result:** Proof by contradiction (reductio ad absurdum) establishes the truth of a proposition by showing that assuming the proposition is false leads to a logical contradiction.
- **Worked Examples:** Example: I want to prove there is no 'largest integer'. I assume there IS a largest integer called 'L'. But what is L + 1? It's bigger than L! This contradicts my assumption. Therefore, my assumption was wrong. There is no largest integer.
- **Kid Likely Doubt:** Why can't I just say √2 is irrational because its decimal goes on forever? Because how do you KNOW it goes on forever? Have you calculated it to a billion digits? Maybe it stops at a billion and one! A proof guarantees it without needing to calculate decimals.
- **"If you are confused" Helper:** Assume the opposite -> Do math -> Find an impossible error -> Conclude the opposite was wrong.
- **Common Mistakes:** Trying to memorize the steps without understanding the detective story behind it.
- **Mini Recap:** A proof by contradiction assumes the statement is false, and proves that doing so breaks mathematics.
- **Parent Explanation Tip:** Play a logic game. State an obvious truth ('It is raining outside'). Ask them to prove it by contradiction ('Assume it is NOT raining. But my shirt is getting wet. That's a contradiction. Therefore, it is raining.')
- **Suggested Resource Links:** [Khan Academy: Intro to Proof by Contradiction] - A great video explaining the logic behind the method.
- **Suggested Visual Asset Notes:** A comic strip showing a detective looking at two paths. One path says 'Assumption', which leads to a brick wall (Contradiction). The detective turns around to the other path.
- **Linked Questions / Quick Check:** Sample Quick Check: What is the first step in a proof by contradiction? (Assume the opposite of what you want to prove is true).

#### Page 2: The Secret Weapon: Coprime Integers
- **Page ID:** `page_2_coprime`
- **Page Objective:** Understand the definition of coprime integers, which is the core trap of our proof.
- **Main Lesson Text:** Before we prove √2 is irrational, we need one weapon: the concept of **Coprime Integers**. Two integers are coprime if they share NO common factors other than 1. Think of a fraction in its absolute simplest form. Is 4/6 in simplest form? No, both can be divided by 2. Is 2/3 in simplest form? Yes! 2 and 3 share no common factors. Therefore, 2 and 3 are coprime.
- **Intuition-First Explanation:** Coprime just means 'simplified as much as physically possible'. It means the top and bottom of the fraction have nothing in common.
- **Formal Definition / Result:** Two integers a and b are said to be coprime (or relatively prime) if their greatest common divisor (GCD) is 1.
- **Worked Examples:** Example 1: Are 8 and 15 coprime? Factors of 8 are 2, 4. Factors of 15 are 3, 5. They share nothing! Yes, they are coprime. 
Example 2: Are 6 and 9 coprime? No, both can be divided by 3.
- **Kid Likely Doubt:** Do coprime numbers have to be prime numbers? NO! 8 is not prime, and 15 is not prime. But *together*, they are CO-prime because they don't share any ingredients.
- **"If you are confused" Helper:** If you can reduce the fraction, the numbers are NOT coprime.
- **Common Mistakes:** Thinking 'coprime' means both numbers must be odd, or both numbers must be prime. It just means they share no factors.
- **Mini Recap:** Coprime integers share no common factors other than 1. Any rational fraction can be written as p/q where p and q are coprime.
- **Parent Explanation Tip:** Write down 10/15. Ask your child to make it coprime (reduce it to 2/3).
- **Suggested Resource Links:** [BYJU'S: Co-Prime Numbers] - Good quick reference.
- **Suggested Visual Asset Notes:** Two circles. Circle 1 has factors of 8. Circle 2 has factors of 15. The overlapping section in the middle is empty, labeled 'Coprime'.
- **Linked Questions / Quick Check:** Sample Quick Check: Are 10 and 21 coprime? (Yes, they share no factors).

#### Page 3: Proof of √2: The Trap is Set
- **Page ID:** `page_3_the_assumption`
- **Page Objective:** Begin the formal proof by stating the assumption and setting up the algebraic equation.
- **Main Lesson Text:** Let's prove √2 is irrational using our detective skills. 
**Step 1: The Assumption.** We assume the exact opposite. Let us assume that √2 IS a rational number. 
**Step 2: The Setup.** If √2 is rational, then by definition, we can write it as a fraction p/q. We also strictly state that p and q are in simplest form (they are **coprime**). 
So, √2 = p/q (where p and q share no common factors).
- **Intuition-First Explanation:** We are daring the math to work. We are saying, 'Okay, if you are a fraction, let me see your simplest form.'
- **Formal Definition / Result:** Assume to the contrary that √2 is rational. Then there exist coprime integers p and q (q ≠ 0) such that √2 = p/q.
- **Worked Examples:** Example: If √2 was actually something like 1.5, we would write it as 3/2, where 3 and 2 are coprime.
- **Kid Likely Doubt:** Why do we insist they are coprime? Because if they aren't, the proof won't work! We need a strict rule to break later to create our contradiction. The simplest form rule is the trap we are setting.
- **"If you are confused" Helper:** Step 1: √2 = p/q. Step 2: p and q are coprime.
- **Common Mistakes:** Forgetting to write 'where p and q are coprime' in an exam. You will lose marks because it is the linchpin of the entire proof.
- **Mini Recap:** We assume √2 is rational and equal to p/q, where p and q share no factors.
- **Parent Explanation Tip:** Have them write the starting sentence on a whiteboard: 'Let √2 = p/q, where p and q are coprime'. Tell them to memorize this exact phrasing.
- **Suggested Resource Links:** [NCERT Class 9 Math] - Refer to the official textbook proof language.
- **Suggested Visual Asset Notes:** An image of a bear trap. The bait inside is labeled 'p/q (coprime)'.
- **Linked Questions / Quick Check:** Sample Quick Check: What do we assume about p and q at the start of the proof? (That they are coprime).

#### Page 4: Proof of √2: The Algebra
- **Page ID:** `page_4_the_algebra`
- **Page Objective:** Perform the algebraic manipulation to show that p must be an even number.
- **Main Lesson Text:** Now we do the math. We have: √2 = p/q. 
We hate square roots, so let's square both sides! 
(√2)² = (p/q)² 
2 = p² / q² 
Now, let's rearrange it by multiplying both sides by q²: 
**2q² = p²** 
Look at this equation carefully. The left side is 2 multiplied by something. Any number multiplied by 2 is an **even number**. Therefore, the left side is even. This means the right side (p²) MUST also be an even number! 
If a square of a number (p²) is even, then the original number (p) must also be even. (Think about it: 4²=16 (even), 6²=36 (even). Odd numbers square to odd numbers: 3²=9). 
So, we have proved that **p is an even number**.
- **Intuition-First Explanation:** We are using basic algebra to force 'p' to reveal its true identity. By multiplying by 2, we expose that p has a secret factor of 2 hidden inside it.
- **Formal Definition / Result:** Since 2q² = p², 2 divides p². By Theorem 1.3 (if a prime p divides a², then p divides a), it follows that 2 divides p.
- **Worked Examples:** Example: If 2 * (something) = p², then p² must be even (like 16, 36, 64). Therefore p must be even (like 4, 6, 8).
- **Kid Likely Doubt:** Does squaring both sides change the truth of the equation? No, whatever you do to one side, you do to the other. The equality remains perfectly true.
- **"If you are confused" Helper:** If p² is a multiple of 2, then p is a multiple of 2.
- **Common Mistakes:** Writing 2q = p² instead of 2q² = p². You must square the q as well!
- **Mini Recap:** By squaring and rearranging, we prove that p² is even, which means p is even.
- **Parent Explanation Tip:** Ask them: 'If a number squared is even, can the number itself be odd?' Have them test 5² and 7² to prove to themselves it's impossible.
- **Suggested Resource Links:** [Khan Academy: Proof that root 2 is irrational] - Watch the algebra steps closely.
- **Suggested Visual Asset Notes:** A mathematical scale. On one side is '2q²', on the other is 'p²'. A glowing '2' highlights that both sides are heavy with 'evenness'.
- **Linked Questions / Quick Check:** Sample Quick Check: If 2q² = p², what do we know about p²? (It is an even number).

#### Page 5: Proof of √2: The Trap Snaps!
- **Page ID:** `page_5_the_contradiction`
- **Page Objective:** Substitute p back into the equation to show q is also even, triggering the logical contradiction.
- **Main Lesson Text:** We just proved p is an even number. This means p is a multiple of 2. We can write this as **p = 2c** (where c is some integer). 
Let's substitute p = 2c back into our earlier equation: 2q² = p² 
2q² = (2c)² 
2q² = 4c² 
Divide both sides by 2: 
**q² = 2c²** 
Wait a minute! Look at this new equation. The right side is 2 multiplied by something. That means the right side is even. Therefore, q² must be even! And if q² is even, then **q must be an even number**! 

**THE CONTRADICTION:** We just proved that p is even AND q is even. This means they both can be divided by 2. But in Step 1, we assumed p and q were COPRIME (sharing NO common factors)! 
Our math is flawless, which means our initial assumption MUST be wrong. √2 cannot be written as p/q. **Therefore, √2 is irrational.**
- **Intuition-First Explanation:** We caught the suspect in a lie! The suspect claimed p and q had nothing in common. We interrogated p, and it confessed to hiding a '2'. We interrogated q, and it confessed to hiding a '2'. Their alibi is destroyed!
- **Formal Definition / Result:** Therefore, p and q have at least 2 as a common factor. But this contradicts the fact that p and q are coprime. This contradiction has arisen because of our incorrect assumption.
- **Worked Examples:** Example of the contradiction: If p is 4 and q is 6, they both share a 2. They are not coprime.
- **Kid Likely Doubt:** Why did we write p = 2c? Because we needed to plug 'p is even' back into the math. '2c' is just the mathematical way of writing 'some even number'.
- **"If you are confused" Helper:** Prove p is even. Substitute. Prove q is even. CONTRADICTION!
- **Common Mistakes:** Forgetting to square the '2' when substituting p=2c. (2c)² becomes 4c², NOT 2c².
- **Mini Recap:** We prove q is also even. Since both share a factor of 2, they aren't coprime. The assumption is false.
- **Parent Explanation Tip:** Have your child explain the whole 'detective story' to you from start to finish without looking at the book.
- **Suggested Resource Links:** [NCERT Class 9 Math] - Read the final concluding paragraph of the proof carefully.
- **Suggested Visual Asset Notes:** The bear trap snapping shut. Inside, 'p' and 'q' are both holding a card that says 'Factor of 2'.
- **Linked Questions / Quick Check:** Sample Quick Check: What is the final contradiction? (p and q share a factor of 2, so they are not coprime).

#### Page 6: Applying the Logic: Proof of √3
- **Page ID:** `page_6_root_3`
- **Page Objective:** Apply the exact same proof structure to √3 to show mastery of the algorithm.
- **Main Lesson Text:** Once you know the √2 proof, you can prove ANY prime square root is irrational! Let's do √3.
1. Assume √3 is rational: √3 = p/q (where p, q are coprime).
2. Square both sides: 3 = p² / q² -> **3q² = p²**.
3. This means p² is a multiple of 3. Therefore, **p is a multiple of 3**.
4. We write p = 3c. Substitute it back: 3q² = (3c)². 
5. 3q² = 9c² -> Divide by 3 -> **q² = 3c²**.
6. This means q² is a multiple of 3. Therefore, **q is a multiple of 3**.
7. Contradiction! Both p and q share a factor of 3. They are not coprime. √3 is irrational.
- **Intuition-First Explanation:** It is a copy-paste formula. You just change the '2's to '3's, and the '4's to '9's. The logical trap works exactly the same way.
- **Formal Definition / Result:** By Theorem 1.3, if 3 divides p², then 3 divides p. Substituting p = 3c leads to 3 dividing q², causing a contradiction.
- **Worked Examples:** Example: For √5, you would end up with 5q² = 25c², which simplifies to q² = 5c².
- **Kid Likely Doubt:** Wait, does 'p² is a multiple of 3' mean p is a multiple of 3? Yes! If a prime number divides a square, it divides the root. (If 3 divides 81, it divides 9).
- **"If you are confused" Helper:** For √3: Square to get 3q²=p². Sub p=3c to get 3q²=9c². Divide to get q²=3c².
- **Common Mistakes:** When substituting p=3c, students often write (3c)² as 3c² instead of 9c². This ruins the division step!
- **Mini Recap:** The proof for √3 perfectly mirrors √2, just using multiples of 3 instead of 2.
- **Parent Explanation Tip:** Challenge them to prove √5 is irrational on a piece of paper right now using the same template.
- **Suggested Resource Links:** [BYJU'S: Prove Root 3 is Irrational] - Good written example to trace.
- **Suggested Visual Asset Notes:** A side-by-side comparison table showing the √2 proof next to the √3 proof, highlighting the numbers that changed.
- **Linked Questions / Quick Check:** Sample Quick Check: In the proof of √3, what do we substitute 'p' with? (p = 3c).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Proof Scaffolding: The Blueprint
- **Page ID:** `page_rev_1`
- **Revision Goal:** Provide a fill-in-the-blank mental structure for reproducing the proof in an exam.
- **Compact Summary:** 1. **ASSUME**: Let √x = p/q (p, q are _________).
2. **SQUARE**: x = p²/q²  ->  xq² = p².
3. **FIRST PROOF**: p² is a multiple of x, so __ is a multiple of x.
4. **SUBSTITUTE**: Let p = xc. Plug it in: xq² = (__c)² -> xq² = x²c².
5. **DIVIDE**: q² = xc².
6. **SECOND PROOF**: q² is a multiple of x, so __ is a multiple of x.
7. **CONTRADICT**: Both share a factor of __. Not coprime. Assumption false!
- **Trouble-Spot Reminder:** Students freeze up and forget step 4 (the substitution step). Remember: once you prove 'p', you must mathematically write down what 'p' is (p=xc) to infect 'q' with the same logic.
- **Exam-Useful Points:** This proof is historically one of the most common 3 or 4-mark questions in board exams. Memorize the blueprint.
- **Remediation Notes:** Write out the blueprint skeleton 5 times until muscle memory takes over.
- **One-Page Recap Style:** Fill-in-the-blank skeleton guide.
- **Parent Support Note:** Read the summary above, and ask your child to fill in the blank lines verbally.
- **Linked Revision Questions:** Revision Quick Check: What is the word for 'sharing no common factors'? (Coprime).
- **Linked Exam Drill Refs:** Exam Drill Ref: Fill-in-the-blanks Proof 6.1

#### Revision Page 2: Assertion & Reason Traps
- **Page ID:** `page_rev_2`
- **Revision Goal:** Prepare for tricky logic questions regarding prime theorems.
- **Compact Summary:** The entire proof relies on a hidden rule (Theorem 1.3): *Let p be a prime number. If p divides a², then p divides a, where a is a positive integer.*
Exams will test if you actually understand this rule.
Example: 'If 2 divides 36 (which is 6²), then 2 MUST divide 6.' (True). 
Example: 'If 4 divides 36 (6²), then 4 MUST divide 6.' (False! 4 doesn't divide 6). 
The rule ONLY works perfectly for PRIME numbers (like 2, 3, 5, 7) dividing squares.
- **Trouble-Spot Reminder:** Students memorize the proof without realizing why 'if p² is even, p is even' actually works. It works because 2 is prime.
- **Exam-Useful Points:** Watch out for Assertion-Reason questions that use composite numbers (like 4 or 6) to test this theorem. The theorem only guarantees it works for PRIMES.
- **Remediation Notes:** Test it yourself. 9 divides 36 (6²), but 9 does not divide 6.
- **One-Page Recap Style:** Theorem warning box.
- **Parent Support Note:** Ask them: 'Does 25 divide 100?' (Yes). '100 is 10 squared. So does 25 divide 10?' (No). This shows why the rule only works for prime numbers!
- **Linked Revision Questions:** Revision Quick Check: Assertion: If 5 divides x², then 5 divides x. (True, because 5 is prime).
- **Linked Exam Drill Refs:** Exam Drill Ref: Assertion-Reason Theorem Drill 6.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To visually represent the concept of 'Coprime'.
  - **What Should Appear:** Two overlapping circles (Venn Diagram). Circle A is 'Factors of p'. Circle B is 'Factors of q'. The overlapping middle section contains ONLY the number '1'.
  - **Labels Required:** Factors of p, Factors of q, Common Factor: 1.
  - **Misconception to Fix:** Prevents students from thinking coprime means the numbers themselves must be prime.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** A visual flow of the proof's logic.
  - **What Should Appear:** A flow chart. Top box: 'Assume √2 = p/q (Coprime)'. Arrow down: 'Prove p has factor 2'. Arrow down: 'Prove q has factor 2'. Arrow points back up to the top box with a big red X over it.
  - **Labels Required:** Assumption, Step 1, Step 2, Contradiction.
  - **Misconception to Fix:** Helps students see the macro-structure of the proof instead of getting lost in algebra.
  - **Location:** Asset 2, Page 1

---

### D. Resource Links

- **Link:** [NCERT Class 10 Math Textbook Chapter 1]
  - **Why it is useful:** Provides the definitive wording for Theorem 1.3 and the proof that examiners look for.
  - **Best for:** basics

- **Link:** [Khan Academy: Proof that square root of 2 is irrational]
  - **Why it is useful:** A fantastic video that walks through the algebra very slowly, explaining the logic of substitution.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** We prove √2 is irrational by assuming it IS rational (p/q, coprime). We use algebra to prove p is a multiple of 2, then substitute that to prove q is a multiple of 2. Since both share a 2, they aren't coprime. The assumption is broken, proving √2 is irrational.
- **Parent Helper Note per difficult subtopic:** This is a pure logic puzzle. Treat it like a game of Clue. We assume the butler did it, but his footprints don't match the mud (the contradiction). The hardest part for kids is the middle substitution step (p = 2c). Help them memorize that bridge.
- **Concept Rescue Note:** Exam Rescue: If you get lost in the algebra, just remember the goal: PROVE P IS EVEN. Then PROVE Q IS EVEN. If you write those two sentences down, you might still get partial marks!
