# Physics Class 10 — Rectilinear Propagation of Light
**Topic ID:** `topic_08_physics_10`
**Concept Tags:** `rectilinear-propagation`, `ray-model`, `shadows`, `pinhole-camera`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is Rectilinear Propagation?
- **Page ID:** `page_1_meaning`
- **Page Objective:** Understand the meaning of rectilinear propagation and the ray model of light.
- **Main Lesson Text:** Have you ever noticed how a laser beam cuts a perfectly straight line through fog? Or how sunlight shining through a small gap in the clouds forms a straight, solid beam? This is because light travels in straight lines. In physics, we call this the **Rectilinear Propagation of Light**. Because it travels in a straight line, we can draw a 'Ray of Light' as a simple straight line with an arrow pointing in the direction the light is moving. A bundle of these rays is called a beam.
- **Intuition-First Explanation:** Light is like a very fast, very tiny bullet. If nothing is in its way, it shoots perfectly straight. It doesn't curve around corners like water flowing down a river.
- **Formal Definition / Result:** The property of light travelling in a straight line in a homogeneous medium is called rectilinear propagation of light.
- **Worked Examples:** Example: Turning on a flashlight in a dusty room reveals a straight cone of light, not a curved or bending one.
- **Kid Likely Doubt:** If light travels in a straight line, why does a lightbulb light up the whole room? Because the lightbulb shoots out trillions of straight rays in ALL directions at once! Each individual ray is straight.
- **"If you are confused" Helper:** Rectilinear = Rect (Straight) + Line.
- **Common Mistakes:** Confusing a 'ray' with a 'beam'. A ray is a single straight line. A beam is a collection of rays.
- **Mini Recap:** Light travels in straight lines, which we represent using straight arrows called rays.
- **Parent Explanation Tip:** Use a laser pointer or a flashlight in a dark room. Put your hand in front of it to show that the light stops dead; it doesn't bend around your hand.
- **Suggested Resource Links:** [Khan Academy: Ray Model of Light] - Great intro to drawing rays.
- **Suggested Visual Asset Notes:** An image of a flashlight emitting a diverging 'beam' made up of several straight 'rays' with arrows.
- **Linked Questions / Quick Check:** Sample Quick Check: What do we call a bundle of light rays? (A beam).

#### Page 2: Evidence 1: Shadows
- **Page ID:** `page_2_shadows`
- **Page Objective:** Understand how shadow formation proves that light travels in straight lines.
- **Main Lesson Text:** The most obvious proof that light travels in straight lines is shadows. When an opaque object (an object that light cannot pass through, like your body) is placed in front of a light source, a dark patch is formed behind it. This dark patch is the shadow. If light could bend or curve, it would just flow around your body and hit the ground behind you, meaning there would be no shadow! The fact that the shadow perfectly outlines your shape proves that the light rays hit you and stopped dead.
- **Intuition-First Explanation:** A shadow is basically a 'hole' in the light. It's the exact shape of whatever blocked the straight-shooting light rays.
- **Formal Definition / Result:** A shadow is the dark region formed behind an opaque object when it blocks the path of light, verifying its rectilinear propagation.
- **Worked Examples:** Example: Walking under a streetlamp at night. The shadow perfectly mimics your silhouette.
- **Kid Likely Doubt:** Why do shadows get blurry at the edges sometimes? That happens when the light source is very large (like the sun or a big bulb). Light rays from the top of the bulb hit slightly different spots than light rays from the bottom of the bulb, creating a fuzzy edge called a penumbra. But every individual ray is still perfectly straight!
- **"If you are confused" Helper:** No straight lines = No shadows.
- **Common Mistakes:** Thinking shadows are 'cast' onto the ground. Shadows are just the ABSENCE of light.
- **Mini Recap:** Shadows exist because light cannot bend around opaque objects.
- **Parent Explanation Tip:** Make shadow puppets on the wall. Ask them why the shadow looks exactly like the hand shape (because the light hits the hand and stops in a straight line).
- **Suggested Resource Links:** [BYJU'S: Formation of Shadows] - Visualizes umbra and penumbra.
- **Suggested Visual Asset Notes:** A diagram of a lightbulb, an apple, and a shadow on a wall. Straight lines from the bulb hit the apple and stop, while lines passing the apple hit the wall.
- **Linked Questions / Quick Check:** Sample Quick Check: Does a transparent object (like clear glass) form a dark shadow? (No, light passes through it).

#### Page 3: Evidence 2: Eclipses
- **Page ID:** `page_3_eclipses`
- **Page Objective:** Apply the concept of shadows on a cosmic scale.
- **Main Lesson Text:** Eclipses are just massive, planet-sized shadows! 
A **Solar Eclipse** happens when the Moon passes exactly between the Sun and the Earth. The Moon is an opaque object. Because light travels in straight lines, the Moon blocks the Sun's rays from hitting a specific spot on Earth, casting a huge shadow on us. 
A **Lunar Eclipse** happens when the Earth passes between the Sun and the Moon. The Earth blocks the light, casting a massive shadow onto the Moon. If light could bend, the sun's light would just bend around the Earth and illuminate the Moon anyway!
- **Intuition-First Explanation:** An eclipse is just the Earth or the Moon playing 'shadow puppets' in space.
- **Formal Definition / Result:** Solar and Lunar eclipses are astronomical phenomena resulting from the shadow formation caused by the rectilinear propagation of sunlight.
- **Worked Examples:** Example: During a total solar eclipse, the area in the deepest, darkest part of the shadow (the umbra) experiences temporary darkness during the day.
- **Kid Likely Doubt:** Why don't we have eclipses every single month? Because the Moon's orbit is slightly tilted! The Moon, Earth, and Sun have to line up in a perfectly straight 3D line for the shadow to hit.
- **"If you are confused" Helper:** Solar Eclipse: Sun -> Moon -> Earth. 
Lunar Eclipse: Sun -> Earth -> Moon.
- **Common Mistakes:** Mixing up the order of the planets/moons for the two eclipses.
- **Mini Recap:** Eclipses are giant shadows in space, proving sunlight travels in straight lines.
- **Parent Explanation Tip:** Use a flashlight, a tennis ball (Earth), and a ping-pong ball (Moon) to simulate an eclipse on the living room wall.
- **Suggested Resource Links:** [NASA: Eclipses] - Excellent diagrams of orbital shadows.
- **Suggested Visual Asset Notes:** A diagram showing the Sun, Earth, and Moon aligned for a Solar Eclipse, with straight lines drawn from the top and bottom of the Sun past the Moon.
- **Linked Questions / Quick Check:** Sample Quick Check: In a Lunar eclipse, what object is casting the shadow? (The Earth).

#### Page 4: Evidence 3: The Pinhole Camera
- **Page ID:** `page_4_pinhole_camera`
- **Page Objective:** Understand how a pinhole camera forms an inverted image using straight light rays.
- **Main Lesson Text:** A pinhole camera is the simplest camera in the world. It is just a dark box with a tiny hole (a pinhole) on one side, and a screen (like tracing paper) on the opposite side. 
If you point the pinhole at a tree, light from the TOP of the tree travels in a straight line, goes through the tiny hole, and hits the BOTTOM of the screen inside the box. 
Light from the BOTTOM of the tree travels in a straight line, goes UP through the hole, and hits the TOP of the screen. 
The result? A perfectly inverted (upside-down) image of the tree on the screen! This is absolute proof that light rays travel straight and cross each other at the hole.
- **Intuition-First Explanation:** Imagine two cars driving perfectly straight toward a narrow one-lane bridge from opposite angles. They cross paths at the bridge and end up on opposite sides of the road.
- **Formal Definition / Result:** A pinhole camera forms a real, inverted image on a screen because light rays from the object undergo rectilinear propagation and cross at the pinhole.
- **Worked Examples:** Example: Looking at a candle flame through a pinhole camera will show an upside-down flame on the tracing paper screen.
- **Kid Likely Doubt:** What happens if I make the pinhole bigger? If the hole is too big, multiple light rays from the top of the tree will hit different spots on the screen, making the image super blurry. The hole MUST be tiny!
- **"If you are confused" Helper:** Straight lines cross at the pinhole -> Top goes to bottom, bottom goes to top -> Upside down image.
- **Common Mistakes:** Thinking the image is virtual. It is a REAL image because the actual light rays physically hit the tracing paper screen.
- **Mini Recap:** A pinhole camera forms an inverted, real image due to straight light rays crossing at the hole.
- **Parent Explanation Tip:** You can make a pinhole camera at home using a shoebox, aluminum foil (for the pinhole), and wax paper (for the screen). It's a great weekend project.
- **Suggested Resource Links:** [Science Buddies: Pinhole Camera] - Diagram and explanation.
- **Suggested Visual Asset Notes:** A diagram of a tree, a box with a hole, and straight lines connecting the top of the tree to the bottom of the back wall of the box.
- **Linked Questions / Quick Check:** Sample Quick Check: Is the image in a pinhole camera erect or inverted? (Inverted).

#### Page 5: Is It Always True? (The Wave Nature)
- **Page ID:** `page_5_approximation`
- **Page Objective:** Acknowledge that rectilinear propagation is an approximation for everyday macroscopic objects.
- **Main Lesson Text:** We've learned that light travels in perfectly straight lines. But physics is full of surprises! Rectilinear propagation is actually an approximation. 
In reality, light behaves like both a particle AND a wave. If light passes through an opening that is microscopically tiny (roughly the same size as the wavelength of light), the light wave actually BENDS and spreads out around the edges of the opening! This bending of light is called **Diffraction**. 
However, because the wavelength of visible light is so incredibly small (less than a millionth of a meter), we never see this bending in our daily lives with normal objects like doors or mirrors.
- **Intuition-First Explanation:** Think of water waves hitting a large harbor wall—they hit and stop. But if water waves hit a tiny gap in a barrier, they ripple outwards in circles. Light does the same thing, but only at a microscopic level.
- **Formal Definition / Result:** Rectilinear propagation is valid when the size of the obstacles or openings is much larger than the wavelength of light. When the obstacle size is comparable to the wavelength, diffraction occurs.
- **Worked Examples:** Example 1: Light hitting a door (macroscopic) = straight lines, sharp shadow. 
Example 2: Light hitting a microscopic slit = spreads out, bends.
- **Kid Likely Doubt:** So was everything I just learned a lie? No! It's like saying 'the Earth is flat' when you are building a house. For building a house, treating the ground as flat works perfectly. For everyday mirrors and shadows, treating light as straight rays works perfectly.
- **"If you are confused" Helper:** Big objects = Straight Lines. Microscopic objects = Bending waves.
- **Common Mistakes:** Assuming that because diffraction exists, ray diagrams are useless. Ray diagrams are the standard for all school-level optics.
- **Mini Recap:** Light travels in straight lines for normal objects, but acts as a bending wave (diffraction) at the microscopic level.
- **Parent Explanation Tip:** If they ask about this, tell them they will learn about Diffraction in Class 12. For Class 10, light is a straight ray!
- **Suggested Resource Links:** [Britannica: Diffraction of Light] - For advanced reading.
- **Suggested Visual Asset Notes:** A split visual: Light rays hitting a large wall (straight bounce) vs Light waves hitting a tiny slit (spreading out in semi-circles).
- **Linked Questions / Quick Check:** Sample Quick Check: What is the phenomenon called when light bends around a microscopic obstacle? (Diffraction).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Evidence Checklist
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of the three main proofs of rectilinear propagation.
- **Compact Summary:** 1. **Shadows**: Opaque objects block light. Because light can't curve around the object, the area behind it stays dark.
2. **Eclipses**: Massive shadows in space. Solar (Moon blocks Sun). Lunar (Earth blocks Sun).
3. **Pinhole Camera**: Light from the top of an object travels straight through a hole to the bottom of the screen, creating an inverted image.
- **Trouble-Spot Reminder:** Students forget to mention that the object must be OPAQUE to form a shadow. A glass window won't form a dark shadow because light passes through it.
- **Exam-Useful Points:** Be prepared for a 2-mark question asking: 'State two natural phenomena that prove the rectilinear propagation of light.' (Answer: Formation of shadows and eclipses).
- **Remediation Notes:** Draw the straight lines yourself. Draw a circle (Sun) and a box (obstacle). Try to draw a line from the Sun to the space directly behind the box. You can't do it without bending the line!
- **One-Page Recap Style:** Bulleted checklist with short proofs.
- **Parent Support Note:** Ask them to define the three pieces of evidence. If they struggle with the pinhole camera, remind them 'Top goes to bottom, bottom goes to top.'
- **Linked Revision Questions:** Revision Quick Check: What property of light causes a pinhole camera to work? (Rectilinear propagation).
- **Linked Exam Drill Refs:** Exam Drill Ref: Evidence Reasoning 8.1

#### Revision Page 2: Definitions & Ray Terminology
- **Page ID:** `page_rev_2`
- **Revision Goal:** Ensure accurate vocabulary is used in exam answers.
- **Compact Summary:** **Ray of Light**: A straight line with an arrowhead showing the path and direction of light.
**Beam of Light**: A bundle of rays.
**Parallel Beam**: Rays travel parallel to each other (like a laser).
**Converging Beam**: Rays come together to meet at one point (like a magnifying glass focusing sunlight).
**Diverging Beam**: Rays spread out from a single source (like a standard lightbulb or flashlight).
- **Trouble-Spot Reminder:** Mixing up Converging (coming together) and Diverging (spreading apart).
- **Exam-Useful Points:** MCQs often ask you to identify a diagram of a converging vs diverging beam. Look at the arrowheads!
- **Remediation Notes:** Converge means 'come together' (like a conversation). Diverge means 'divide and spread out'.
- **One-Page Recap Style:** Vocabulary matching list.
- **Parent Support Note:** Hold up your two hands. Move them together (Converge). Move them apart (Diverge).
- **Linked Revision Questions:** Revision Quick Check: A flashlight produces what kind of beam? (Diverging beam).
- **Linked Exam Drill Refs:** Exam Drill Ref: Vocabulary Matching 8.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To visually prove that light cannot bend around objects.
  - **What Should Appear:** A diagram showing a light source, an opaque square block, and a screen. Straight lines are drawn from the light source. The ones hitting the block stop. The ones missing the block hit the screen.
  - **Labels Required:** Light Source, Opaque Object, Shadow, Straight Light Rays.
  - **Misconception to Fix:** Shows that shadows are not 'cast' but are areas where light is physically blocked.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** To explain the inversion of the image clearly.
  - **What Should Appear:** A Pinhole Camera ray diagram. A tree on the left. A box with a hole in the middle. Straight lines connecting the top of the tree to the bottom of the inside of the box, and vice versa.
  - **Labels Required:** Object, Pinhole, Inverted Image, Light Ray.
  - **Misconception to Fix:** Prevents students from thinking the box has lenses or mirrors doing the flipping. It's just straight lines crossing.
  - **Location:** Asset 1, Page 4

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10 (Light)]
  - **Why it is useful:** Provides the official syllabus terminology for rays and beams.
  - **Best for:** basics

- **Link:** [Khan Academy: Pinhole Camera Simulation]
  - **Why it is useful:** Helps visualize how the size of the hole affects the sharpness of the image.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Light travels in straight lines. We prove this because opaque objects block it to form shadows, planets block it to form eclipses, and straight lines crossing through a pinhole create upside-down images.
- **Parent Helper Note per difficult subtopic:** The pinhole camera is the trickiest concept here. The key is the 'straight line crossing'. If you draw an 'X' on a piece of paper, the top-left line ends up on the bottom-right. That's exactly what light does through a pinhole.
- **Concept Rescue Note:** Exam Rescue: If asked to prove rectilinear propagation, DO NOT just say 'because lasers are straight'. Use the three specific textbook examples: Shadows, Eclipses, or Pinhole Cameras.
