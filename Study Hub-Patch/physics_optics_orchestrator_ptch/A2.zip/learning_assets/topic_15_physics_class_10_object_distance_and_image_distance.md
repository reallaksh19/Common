# Physics Class 10 — Object Distance and Image Distance
**Topic ID:** `topic_15_physics_10`
**Concept Tags:** `object-distance`, `image-distance`, `plane-mirror`, `virtual-image`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: The Golden Rule of Mirror Distances
- **Page ID:** `page_1_the_golden_rule`
- **Page Objective:** Understand the exact 1-to-1 relationship between object distance and image distance in a plane mirror.
- **Main Lesson Text:** When you stand in front of a mirror, the distance from your nose to the glass is called the **Object Distance**. The distance from the glass to where your reflection appears to be standing *behind* the mirror is the **Image Distance**. The golden rule of plane mirrors is that these two distances are ALWAYS perfectly equal. If you step 2 meters away from the mirror, your reflection steps 2 meters deep into the mirror.
- **Intuition-First Explanation:** The mirror acts like a perfect halfway point. It folds the world exactly in half.
- **Formal Definition / Result:** For a plane mirror, the image distance (v) is equal in magnitude to the object distance (u). |u| = |v|.
- **Worked Examples:** Example: A chess piece is placed 10 cm in front of a mirror. Its virtual image forms exactly 10 cm behind the mirror.
- **Kid Likely Doubt:** Is the image distance a negative number? In advanced physics (sign convention), distances measured behind the mirror are often considered positive, while distances in front are negative. But for Class 10 basic properties, we just say the physical lengths are equal.
- **"If you are confused" Helper:** Object Distance = Image Distance.
- **Common Mistakes:** Assuming the image forms ON the surface of the mirror. It does not. It forms BEHIND it.
- **Mini Recap:** The image is as far behind the mirror as the object is in front of it.
- **Parent Explanation Tip:** Put a ruler perpendicular to a mirror. Point out that the 10cm mark on the real ruler perfectly touches the 10cm mark on the reflected ruler.
- **Suggested Resource Links:** [Khan Academy: Object and Image Distance] - Visual explanation of the symmetry.
- **Suggested Visual Asset Notes:** A side-profile diagram of a person looking at a mirror. A dimension line from the person to the mirror says 'd'. A dimension line from the mirror to the virtual person says 'd'.
- **Linked Questions / Quick Check:** Sample Quick Check: An apple is 5 cm from a mirror. How far behind the mirror is the image? (5 cm).

#### Page 2: How to Measure Distances Correctly
- **Page ID:** `page_2_measuring_mistakes`
- **Page Objective:** Identify the correct reference point (the mirror surface) for all distance measurements.
- **Main Lesson Text:** In physics, you must always know where your measuring tape starts. For plane mirrors, the starting line is ALWAYS the surface of the mirror itself. You measure perpendicularly (straight out at 90 degrees) from the glass to the object. A common mistake is measuring from the observer's eye. If you are standing 5 meters away, looking at an apple that is 1 meter away from the mirror, the object distance for the apple is 1 meter, NOT 4 meters!
- **Intuition-First Explanation:** The mirror is the anchor point. Everything is measured outward from the glass.
- **Formal Definition / Result:** Object distance (u) is measured along the principal axis from the pole (or surface) of the mirror to the object.
- **Worked Examples:** Example: You are 10m from a mirror. A ball is halfway between you and the mirror. The object distance of the ball is 5m.
- **Kid Likely Doubt:** What if the object is tilted? Then different parts of the object have different object distances! The top of a leaning stick might be 2cm away, while the bottom is 4cm away. The image will perfectly copy this tilt.
- **"If you are confused" Helper:** Always put the '0' mark of your measuring tape on the mirror glass.
- **Common Mistakes:** Measuring the diagonal distance from an observer's eye to the image, rather than the perpendicular distance from the mirror.
- **Mini Recap:** All distances are measured perpendicularly from the surface of the mirror.
- **Parent Explanation Tip:** Draw a 'bird's eye view' map of a room with a mirror, a chair, and a table. Ask your child to draw the line representing the object distance of the chair.
- **Suggested Resource Links:** [BYJU'S: Image Formation by Plane Mirror] - Good diagrams showing perpendicular measurement.
- **Suggested Visual Asset Notes:** A diagram highlighting the correct perpendicular measuring line in green, and a faulty diagonal measuring line from an eye in red.
- **Linked Questions / Quick Check:** Sample Quick Check: Where must you start measuring to find the object distance? (From the surface of the mirror).

#### Page 3: Proving the Golden Rule
- **Page ID:** `page_3_the_proof`
- **Page Objective:** Use geometric ray tracing to prove why object distance equals image distance.
- **Main Lesson Text:** Why must the distances be equal? We can prove it using the Laws of Reflection! 
1. Take a point object 'O' in front of a mirror. 
2. Draw a ray hitting the mirror straight on (i=0). It bounces straight back. 
3. Draw a second ray hitting the mirror at an angle. It bounces off with ∠i = ∠r. 
4. Extend both reflected rays backwards behind the mirror until they cross at point 'I' (the Image). 
5. The geometry of those intersecting lines creates two perfectly identical, congruent right-angled triangles—one in front of the mirror, one behind it. 
Because the triangles are exactly the same size, the base of the front triangle (Object Distance) MUST equal the base of the back triangle (Image Distance).
- **Intuition-First Explanation:** The light bounces off at such a perfectly mirrored angle that if you trace it backward, it forms a perfect clone of the geometry.
- **Formal Definition / Result:** By extending the reflected rays backward, we form triangles ΔOMA and ΔIMA (where M is the point on the mirror). Through ASA congruency, we prove OM = IM.
- **Worked Examples:** Example: If you change the angle of the second ray, the triangles change shape, but they STILL remain congruent, proving the rule works for any viewing angle.
- **Kid Likely Doubt:** Do I have to memorize the triangle proof? For Class 10, usually no. But drawing the diagram accurately is essential. If your object distance is 3cm, your image point MUST be drawn 3cm behind the line.
- **"If you are confused" Helper:** Congruent Triangles = Equal Distances.
- **Common Mistakes:** Drawing a ray diagram where the image is randomly placed. The diagram must physically show the distances being equal.
- **Mini Recap:** Ray tracing creates congruent triangles that mathematically prove Object Distance = Image Distance.
- **Parent Explanation Tip:** Have them draw a mirror line, an object dot 4cm away, and an image dot 4cm behind. Then ask them to draw the rays connecting them. The equal distances force the angles to be correct naturally!
- **Suggested Resource Links:** [NCERT Class 10 Science Chapter 10] - Follow the standard diagram.
- **Suggested Visual Asset Notes:** A ray diagram highlighting the two congruent right-angled triangles formed by the incident and extended virtual rays.
- **Linked Questions / Quick Check:** Sample Quick Check: What geometric principle proves that the distances are equal? (Congruency of triangles).

#### Page 4: Applications and Total Distance Math
- **Page ID:** `page_4_total_distance`
- **Page Objective:** Solve word problems calculating total distances and relative movement.
- **Main Lesson Text:** Physics exams love word problems! The most common trick is asking for the TOTAL distance between the real object and the virtual image. 
If an object is 3m from the mirror, its image is 3m behind the mirror. 
Total Distance = Object Distance + Image Distance. 
Total Distance = 3m + 3m = 6m. 
Another trick: Movement! If you walk 1 meter TOWARDS the mirror, your object distance decreases by 1 meter. Because the rule holds true, your image ALSO walks 1 meter towards the mirror. The total distance between you and your reflection shrinks by 2 meters!
- **Intuition-First Explanation:** You and your reflection are walking towards each other at the exact same speed. When you touch the glass, you touch hands.
- **Formal Definition / Result:** The total distance between an object and its image in a plane mirror is 2u, where u is the object distance.
- **Worked Examples:** Example: A car is 10m from a large mirror. It drives 2m closer. What is the new distance between the car and its image? New object distance = 8m. New image distance = 8m. Total = 16m.
- **Kid Likely Doubt:** If I run at 5 km/h toward the mirror, how fast is my image running at me? Your image is running at the mirror at 5 km/h. But relative to YOU, it is approaching at 10 km/h! (Because you are both closing the gap).
- **"If you are confused" Helper:** Total Distance = Double the Object Distance.
- **Common Mistakes:** The question asks for 'distance from object to image', and the student only writes down the image distance.
- **Mini Recap:** To find the total distance between object and image, add the object distance to the image distance (or just double the object distance).
- **Parent Explanation Tip:** Play a game. Stand 4 steps from a mirror. Ask 'How many steps between us?' (8). Take 1 step forward. Ask again. (6).
- **Suggested Resource Links:** [Physics Classroom: Image Characteristics] - Excellent movement examples.
- **Suggested Visual Asset Notes:** A diagram showing a person 3m from a mirror, with a dimension line spanning all the way across to the image labeled 'Total Distance = 6m'.
- **Linked Questions / Quick Check:** Sample Quick Check: An object is 7m from a mirror. What is the total distance to its image? (14m).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Distance Math Drill Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast, error-free calculation of object/image relative distances.
- **Compact Summary:** **The Core Rule:** Object Distance (u) = Image Distance (v).
**Total Distance:** Distance from Object to Image = 2u.
**Movement:** If the object moves 'x' meters closer, the total distance decreases by '2x' meters.
- **Trouble-Spot Reminder:** Not reading the question carefully. Did it ask for the distance 'from the mirror' (u) or 'from the object' (2u)? This is the easiest way to lose marks.
- **Exam-Useful Points:** These will almost certainly appear as 1-mark numericals or MCQs in Section A.
- **Remediation Notes:** Always draw a quick sketch. Draw a vertical line for the mirror, put a dot for the object, a dot for the image, and write the numbers in.
- **One-Page Recap Style:** Three-point formula summary and warning box.
- **Parent Support Note:** Read questions to them and ask them to just point to whether the answer is 'u' or '2u' without doing the math first.
- **Linked Revision Questions:** Revision Quick Check: Object is 12cm from mirror. Distance from mirror to image is? (12cm).
- **Linked Exam Drill Refs:** Exam Drill Ref: Distance Word Problems 15.1

#### Revision Page 2: The 'Behind the Mirror' Confusion
- **Page ID:** `page_rev_2`
- **Revision Goal:** Remediation for students who struggle with the concept of a virtual distance.
- **Compact Summary:** Some students struggle with the idea of measuring distance 'into' a solid wall. 
Think of it like looking out a window instead of a mirror. 
If you stand 2 feet away from a window, and someone identical to you is standing 2 feet away on the outside, the distance between you is 4 feet. 
A plane mirror creates a perfect 'window' illusion. The physics math treats the space behind the mirror exactly as if it were real, open space.
- **Trouble-Spot Reminder:** Students write '0' for image distance because the image is 'on the glass'. Remember, the image is NEVER on the glass in a plane mirror.
- **Exam-Useful Points:** Reasoning questions may ask 'Why does a small room with a full-wall mirror feel twice as big?' Answer: Because the virtual images are formed at an equal distance behind the mirror, doubling the perceived depth of the room.
- **Remediation Notes:** Go to a mirror and touch the glass. Your reflection's finger touches yours. Distance = 0. Step back. The reflection steps back. The depth is real to your eyes.
- **One-Page Recap Style:** Analogy breakdown (Mirror vs Window).
- **Parent Support Note:** Discuss the 'small room looking bigger' concept next time you see a mirrored wall in a restaurant or elevator.
- **Linked Revision Questions:** Revision Quick Check: Is the image formed on the surface of the glass? (No, it is formed behind it).
- **Linked Exam Drill Refs:** Exam Drill Ref: Conceptual Reasoning 15.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To serve as the definitive reference for total distance calculations.
  - **What Should Appear:** A diagram of a ruler spanning across a mirror. The 10cm mark is at the object, the 20cm mark is at the mirror, and the 30cm mark is at the image. A bracket shows 'Object Distance = 10' and 'Image Distance = 10'. A huge bracket shows 'Total = 20'.
  - **Labels Required:** Object, Mirror, Image, u=10, v=10, Total=20.
  - **Misconception to Fix:** Prevents students from confusing 'u' with '2u' in word problems.
  - **Location:** Asset 1, Page 4

- **Teaching Purpose:** To visually prove the congruent triangle geometry.
  - **What Should Appear:** A clean ray diagram focusing ONLY on the two triangles formed by the light rays. The triangles are shaded in different colors to show they are identical mirrors of each other.
  - **Labels Required:** Congruent Triangle 1, Congruent Triangle 2, Equal Base Lengths.
  - **Misconception to Fix:** Proves the equal distance rule is a mathematical necessity, not just a guess.
  - **Location:** Asset 1, Page 3

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the official syllabus statement on image characteristics.
  - **Best for:** basics

- **Link:** [BYJU'S: Image Formation by Plane Mirror]
  - **Why it is useful:** Good interactive quizzes for distance word problems.
  - **Best for:** revision

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** In a plane mirror, the object distance (from object to mirror) is exactly equal to the image distance (from mirror to virtual image). To find the total distance between you and your reflection, simply double your distance to the mirror.
- **Parent Helper Note per difficult subtopic:** The trickiest questions ask about movement. Remember, if you move closer by 1 step, your image also moves closer by 1 step. The total gap between you shrinks by TWO steps.
- **Concept Rescue Note:** Exam Rescue: If a word problem confuses you, draw a quick line. Put a mark for Object, a mark for Mirror, and a mark for Image. Fill in the numbers you know. The math will become obvious.
