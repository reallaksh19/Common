# Mathematics Class 9 — Decimal Expansion of Rational Numbers
**Topic ID:** `topic_03_mathematics_9`
**Concept Tags:** `rational-numbers`, `decimal-expansion`, `terminating-decimals`, `repeating-decimals`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: Converting Fractions to Decimals
- **Page ID:** `page_1_converting`
- **Page Objective:** Understand how to convert any rational number in p/q form into a decimal.
- **Main Lesson Text:** Every fraction p/q is just a division problem waiting to be solved. To convert a fraction to a decimal, you simply take the top number (the numerator, p) and divide it by the bottom number (the denominator, q) using long division.
- **Intuition-First Explanation:** A fraction is just an instruction. 3/4 literally means 'take 3, and divide it by 4'.
- **Formal Definition / Result:** The decimal expansion of a rational number p/q is found by dividing p by q.
- **Worked Examples:** Example: Convert 5/8 to a decimal. You divide 5.000 by 8. 
8 goes into 50 six times (48), remainder 2. 
8 goes into 20 two times (16), remainder 4. 
8 goes into 40 five times (40), remainder 0. 
The answer is 0.625.
- **Kid Likely Doubt:** What if the top number is smaller than the bottom number? You just add a decimal point and some zeros to the top number, like turning 5 into 5.00, and keep dividing.
- **"If you are confused" Helper:** Top goes IN the division box, bottom goes OUT.
- **Common Mistakes:** Dividing the bottom by the top (doing 8 ÷ 5 instead of 5 ÷ 8).
- **Mini Recap:** Fractions can always be turned into decimals via long division.
- **Parent Explanation Tip:** Have your child solve 1/4 using long division on paper. Ensure they don't reverse the numbers.
- **Suggested Resource Links:** [Khan Academy: Fractions to Decimals] - Good basic review of long division.
- **Suggested Visual Asset Notes:** A step-by-step long division visual for 3 ÷ 8 = 0.375.
- **Linked Questions / Quick Check:** Sample Quick Check: What is 1/2 as a decimal? (0.5).

#### Page 2: Terminating Decimals
- **Page ID:** `page_2_terminating`
- **Page Objective:** Understand what terminating decimals are and why they stop.
- **Main Lesson Text:** When you do long division, sometimes the remainder eventually hits exactly zero. When this happens, the division is finished, and your decimal stops. We call this a **Terminating Decimal**. Examples include 0.5 (from 1/2) or 0.125 (from 1/8).
- **Intuition-First Explanation:** Terminating means 'ending' (like a bus terminal is the end of the line). The fraction divides perfectly without leaving an endless mess.
- **Formal Definition / Result:** A rational number p/q has a terminating decimal expansion if the long division yields a remainder of 0 after a finite number of steps.
- **Worked Examples:** Example: 3/4. 3 ÷ 4 = 0.75. The remainder becomes 0. It terminates.
- **Kid Likely Doubt:** Are whole numbers terminating decimals? Yes! The number 5 is just 5.0. It stops immediately.
- **"If you are confused" Helper:** Remainder zero = Terminating = Rational.
- **Common Mistakes:** Thinking 0.333 is terminating because the student got tired of dividing and just stopped writing it. It actually never terminates.
- **Mini Recap:** A decimal terminates when the long division leaves no remainder.
- **Parent Explanation Tip:** Ask them to identify terminating decimals on a grocery receipt (like $4.50).
- **Suggested Resource Links:** [BYJU'S: Terminating Decimals] - Quick review.
- **Suggested Visual Asset Notes:** A long division drawing showing the remainder hitting a big red '0' at the bottom.
- **Linked Questions / Quick Check:** Sample Quick Check: Is 0.892 terminating? (Yes).

#### Page 3: Non-Terminating Recurring Decimals
- **Page ID:** `page_3_recurring`
- **Page Objective:** Understand why some divisions loop forever and how to write them.
- **Main Lesson Text:** Sometimes, the remainder in your long division NEVER becomes zero. Instead, a specific remainder pops up again and again. When the remainder loops, the digits in your answer loop too! We call this a **Non-Terminating Recurring Decimal** (or repeating decimal). Example: 1/3 = 0.3333...
- **Intuition-First Explanation:** It's like a stutter. The division process gets caught in an infinite loop.
- **Formal Definition / Result:** If the remainder never becomes zero but repeats a sequence of values, the decimal expansion is non-terminating and recurring. It is a rational number.
- **Worked Examples:** Example: 1/11. 1 ÷ 11 = 0.09090909... The block '09' repeats infinitely. We write this as 0.̅0̅9.
- **Kid Likely Doubt:** Is it possible for the pattern to be super long? Yes! 1/7 = 0.142857142857... The pattern is 6 digits long before it repeats!
- **"If you are confused" Helper:** To save time, we put a 'bar' over the digits that repeat. 0.333... becomes 0.3̄.
- **Common Mistakes:** Putting the bar over the wrong numbers. In 0.16666..., only the 6 repeats. It should be 0.16̄, NOT 0.1̄6̄.
- **Mini Recap:** Decimals that never end but repeat a block of digits are rational.
- **Parent Explanation Tip:** Show them 1 ÷ 7 on a calculator. See if they can spot where the pattern starts repeating.
- **Suggested Resource Links:** [NCERT Math Class 9] - Review the bar notation rules.
- **Suggested Visual Asset Notes:** Long division of 1 ÷ 3 showing the remainder '1' appearing in an infinite loop.
- **Linked Questions / Quick Check:** Sample Quick Check: How do you write 0.454545... with a bar? (0.̅4̅5).

#### Page 4: The Secret Denominator Rule
- **Page ID:** `page_4_the_secret_rule`
- **Page Objective:** Learn how to predict if a fraction will terminate WITHOUT dividing.
- **Main Lesson Text:** Want a magic trick? You can look at a fraction and instantly know if it will terminate or repeat without doing any long division! First, make sure the fraction is completely simplified. Then, look ONLY at the denominator (the bottom number) and break it into its prime factors.
- **Intuition-First Explanation:** Our math system is based on the number 10. The prime factors of 10 are 2 and 5. Therefore, only fractions built out of 2s and 5s will fit perfectly into a Base-10 decimal.
- **Formal Definition / Result:** Let x = p/q be a rational number, where p and q are coprime. If the prime factorization of q is of the form 2^n * 5^m (where n, m are non-negative integers), then x has a terminating decimal expansion.
- **Worked Examples:** Example 1: 7/8. Denominator is 8. Factors of 8 = 2*2*2. It only contains 2s! It WILL terminate.
Example 2: 4/15. Denominator is 15. Factors of 15 = 3*5. It has a 3 in it! It WILL NOT terminate (it will recur).
- **Kid Likely Doubt:** What if the denominator is 10? Factors of 10 are 2*5. Since it only has 2s and 5s, it terminates!
- **"If you are confused" Helper:** If the bottom number's family tree has ANY number other than 2 or 5 (like 3, 7, 11), it will repeat forever.
- **Common Mistakes:** Forgetting to simplify the fraction first! For example, 6/15 looks like it won't terminate (15 = 3*5). But 6/15 simplifies to 2/5. The denominator is 5, so it actually DOES terminate!
- **Mini Recap:** Prime factors of denominator = 2 and/or 5 only -> Terminates. Anything else -> Recurs.
- **Parent Explanation Tip:** Give them a list of denominators (4, 10, 20, 33) and ask them to rapidly guess if they terminate just by finding the prime factors.
- **Suggested Resource Links:** [CK-12: Terminating and Repeating Decimals] - Good practice drills.
- **Suggested Visual Asset Notes:** A factor tree. If the tree branches only into 2s and 5s, it gets a green checkmark.
- **Linked Questions / Quick Check:** Sample Quick Check: Will 3/20 terminate? (Yes, 20 = 2*2*5).

#### Page 5: Converting Decimals Back to Fractions (Terminating)
- **Page ID:** `page_5_reverse_terminating`
- **Page Objective:** Learn how to turn a terminating decimal back into a p/q fraction.
- **Main Lesson Text:** This is the easy part. To turn a terminating decimal back into a fraction, you just count how many numbers are after the decimal point. That tells you how many zeros go in your denominator (10, 100, 1000). Then, simplify the fraction.
- **Intuition-First Explanation:** Read the decimal out loud! 0.5 is 'five tenths'. Write that down: 5/10. Then simplify to 1/2.
- **Formal Definition / Result:** A terminating decimal with n decimal places can be expressed as a fraction with a denominator of 10^n.
- **Worked Examples:** Example 1: 0.25 has two decimal places. Write it as 25/100. Divide top and bottom by 25 to simplify to 1/4.
Example 2: 1.004 has three decimal places. Write it as 1004/1000. Simplify to 251/250.
- **Kid Likely Doubt:** What if there is a number before the decimal, like 3.14? Just keep it on top: 314/100. Then simplify.
- **"If you are confused" Helper:** 1 place = over 10. 2 places = over 100. 3 places = over 1000.
- **Common Mistakes:** Forgetting to simplify the fraction to its lowest terms. 75/100 is correct, but exams require 3/4.
- **Mini Recap:** Count the decimal spots, put the number over 10/100/1000, and simplify.
- **Parent Explanation Tip:** Ask them to convert money amounts into fractions. $1.50 is 150/100, which is 3/2.
- **Suggested Resource Links:** [Khan Academy: Decimals as Fractions] - Good practice for simplification.
- **Suggested Visual Asset Notes:** An image showing the decimal point shifting to the right, while zeros are added to the denominator below it.
- **Linked Questions / Quick Check:** Sample Quick Check: What is 0.8 as a fraction? (8/10, simplified to 4/5).

#### Page 6: Converting Decimals Back to Fractions (Repeating)
- **Page ID:** `page_6_reverse_repeating`
- **Page Objective:** Learn the algebraic trick to turn a recurring decimal back into a p/q fraction.
- **Main Lesson Text:** How do you turn an infinite repeating decimal like 0.333... into a fraction? You can't just put it over 100 because it never stops! We use an algebra trick to 'chop off' the infinite part.
- **Intuition-First Explanation:** If we have an infinite tail of 3s, and we subtract another infinite tail of 3s from it, the infinities cancel each other out, leaving us with a solid number.
- **Formal Definition / Result:** Let x = the recurring decimal. Multiply x by 10^n (where n is the number of repeating digits). Subtract the original x equation to eliminate the recurring decimal part, then solve for x.
- **Worked Examples:** Example: Convert 0.333... to a fraction.
Let x = 0.333...
Since 1 digit repeats, multiply both sides by 10: 10x = 3.333...
Subtract the first equation: (10x - x) = 3.333... - 0.333...
9x = 3
x = 3/9, which simplifies to 1/3.
- **Kid Likely Doubt:** How did 3.333... minus 0.333... become exactly 3? Because the infinite tails are exactly identical. Infinity minus the exact same infinity equals zero!
- **"If you are confused" Helper:** If 1 digit repeats, multiply by 10. If 2 digits repeat (0.4545...), multiply by 100.
- **Common Mistakes:** Multiplying by 10 when TWO digits repeat. You must shift the decimal past the entire repeating block.
- **Mini Recap:** Use algebra to subtract the infinite repeating tail from itself to find the fraction.
- **Parent Explanation Tip:** Have them write the two equations (10x = 3.333... and x = 0.333...) stacked on top of each other like a normal subtraction problem so they can literally cross out the infinite tails.
- **Suggested Resource Links:** [BYJU'S: Converting Recurring Decimals] - Good step-by-step math solver.
- **Suggested Visual Asset Notes:** A stacked subtraction visual showing the infinite '.333...' parts perfectly aligning and being crossed out with a red line.
- **Linked Questions / Quick Check:** Sample Quick Check: To convert 0.727272..., what do you multiply x by? (100).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The Denominator Trick Summary
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of how to predict terminating vs repeating decimals.
- **Compact Summary:** 1. SIMPLIFY the fraction fully.
2. Find the Prime Factors of the denominator (bottom number).
3. If factors are ONLY 2s, ONLY 5s, or a mix of ONLY 2s and 5s -> TERMINATING.
4. If ANY other prime number (3, 7, 11, etc.) is in the factors -> NON-TERMINATING RECURRING.
- **Trouble-Spot Reminder:** Students forget step 1! 3/15 looks like it repeats because 15 = 3*5. But 3/15 simplifies to 1/5. Since the bottom is 5, it terminates!
- **Exam-Useful Points:** Exams will intentionally give you unsimplified fractions like 6/15 or 14/35 to trap you.
- **Remediation Notes:** Always divide the top and bottom by their greatest common divisor before looking at the bottom number.
- **One-Page Recap Style:** A 4-step bulleted checklist.
- **Parent Support Note:** Ask them 'What is the secret trap for this rule?' (Answer: Forgetting to simplify first).
- **Linked Revision Questions:** Revision Quick Check: Will 9/30 terminate? (Yes, simplifies to 3/10. 10 = 2*5).
- **Linked Exam Drill Refs:** Exam Drill Ref: Rule Check 3.1

#### Revision Page 2: The Algebra Conversion Cheat Sheet
- **Page ID:** `page_rev_2`
- **Revision Goal:** Step-by-step master guide for converting repeating decimals to p/q.
- **Compact Summary:** Step 1: Set x = [your repeating decimal].
Step 2: Count repeating digits. (1 digit = multiply by 10. 2 digits = multiply by 100).
Step 3: Write new equation: 10x = [shifted decimal].
Step 4: Stack them and subtract.
Step 5: Solve for x and SIMPLIFY the fraction.
- **Trouble-Spot Reminder:** Mixed repeating decimals like 0.1222... (where the 1 doesn't repeat). You have to multiply by 10 FIRST to get the non-repeating part out of the way (10x = 1.222...). Then treat it normally.
- **Exam-Useful Points:** This is a standard 3-mark derivation question in NCERT exams. Write out every single step clearly.
- **Remediation Notes:** If your subtraction doesn't result in a clean whole number on the right side, you multiplied by the wrong power of 10.
- **One-Page Recap Style:** Numbered procedure list.
- **Parent Support Note:** Watch them do one practice problem completely. Make sure they clearly write '10x - x = 9x'.
- **Linked Revision Questions:** Revision Quick Check: If x = 0.888..., what is 10x - x? (9x = 8).
- **Linked Exam Drill Refs:** Exam Drill Ref: Conversion Practice 3.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To show the relationship between denominator prime factors and decimal types.
  - **What Should Appear:** A split chart. Top: 'Denominator Prime Factors'. Left branch: 'Only 2s and 5s' -> points to 'Terminating Decimal'. Right branch: 'Any other primes' -> points to 'Repeating Decimal'.
  - **Labels Required:** Prime Factors, 2 & 5, Terminating, Repeating.
  - **Misconception to Fix:** Prevents guessing by giving a visual algorithm.
  - **Location:** Asset 1, Page 4

- **Teaching Purpose:** To visually explain the subtraction trick for repeating decimals.
  - **What Should Appear:** A mathematical subtraction problem stacked vertically. 10x = 3.3333... MINUS x = 0.3333... 
  - **Labels Required:** A bold red slash crossing out the infinite '.3333...' on both lines.
  - **Misconception to Fix:** Visually proves how infinity minus infinity can equal zero.
  - **Location:** Asset 1, Page 6

---

### D. Resource Links

- **Link:** [NCERT Class 9 Math Textbook Chapter 1]
  - **Why it is useful:** Provides the official syllabus proofs for decimal conversion.
  - **Best for:** basics

- **Link:** [Khan Academy: Repeating Decimals to Fractions]
  - **Why it is useful:** Excellent interactive quizzes for the algebra trick.
  - **Best for:** revision

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Rational numbers turn into decimals that either end perfectly or repeat a pattern forever. You can predict which one by looking for 2s and 5s in the simplified denominator.
- **Parent Helper Note per difficult subtopic:** The hardest part of this chapter is the algebra trick (10x - x). Have your child practice doing it with 0.777... and 0.4545... until they can do it without looking at the book.
- **Concept Rescue Note:** Exam Rescue: If you completely forget the prime factor rule (2s and 5s) during the exam, just do the long division! It takes longer, but long division will always give you the right answer.
