# Mathematics Class 9 — Number System
**Topic ID:** `topic_01_mathematics_9`
**Concept Tags:** `number-system`, `rational-numbers`, `irrational-numbers`, `real-numbers`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: Why Do We Need Different Kinds of Numbers?
- **Page ID:** `page_1_intro`
- **Page Objective:** Build an intuitive understanding of how human counting evolved into distinct number systems.
- **Main Lesson Text:** Imagine you are a shepherd 5,000 years ago. To count your sheep, you use your fingers: 1, 2, 3... These are the **Natural Numbers**. What if the wolves eat all your sheep? You have none left. You need a number for 'nothing'. Enter **Zero**. If you combine all natural numbers with zero, you get the **Whole Numbers**.
- **Intuition-First Explanation:** We didn't invent all numbers at once. Early humans invented them piece by piece to solve specific daily problems—counting sheep, then owing sheep (debt), then splitting a loaf of bread.
- **Formal Definition / Result:** Natural Numbers (N) = {1, 2, 3, 4...}
Whole Numbers (W) = {0, 1, 2, 3...}
- **Worked Examples:** Example 1: Is 0 a natural number? No, counting on your fingers naturally starts at 1.
Example 2: Is 500 a whole number? Yes.
- **Kid Likely Doubt:** Why isn't zero a natural number? Because naturally, if you ask a toddler to start counting their toys, they never start by saying 'Zero, one, two...'
- **"If you are confused" Helper:** Natural = Counting on your fingers. Whole = Starts with a Hole (Zero).
- **Common Mistakes:** Assuming the set of natural numbers includes zero in exams.
- **Mini Recap:** Numbers grew as human needs grew: The first step was N (Natural), which expanded into W (Whole) by adding zero.
- **Parent Explanation Tip:** Ask your child to count the apples in a bowl. Then remove the apples and ask them how many are left. This physically shows the gap between Natural and Whole numbers.
- **Suggested Resource Links:** [Khan Academy: Intro to Number Systems] - Excellent video visualizing sets of numbers.
- **Suggested Visual Asset Notes:** A timeline visual. Start with a shepherd counting sheep (N), then show an empty grassy field (W).
- **Linked Questions / Quick Check:** Sample Quick Check: Is every whole number also a natural number? (False, 0 is not).

#### Page 2: Integers and Rational Numbers
- **Page ID:** `page_2_integers_rational`
- **Page Objective:** Understand how negative numbers represent debt, and how fractions allow us to measure parts of a whole.
- **Main Lesson Text:** Imagine you borrow 5 sheep from a friend. You owe sheep! To represent debt, we invented negative numbers: -1, -2, -3... If you take Whole numbers and add these negatives, you get **Integers (Z)**. But what if you want to share 1 apple between 2 people? You need a part of a whole: 1/2. To measure parts, we invented fractions: numbers written as p/q. These are **Rational Numbers (Q)**.
- **Intuition-First Explanation:** A rational number is just any number you can write as a neat, perfect fraction where the bottom number isn't zero.
- **Formal Definition / Result:** Integers (Z) = {..., -3, -2, -1, 0, 1, 2, 3...}
Rational Numbers (Q) = Any number that can be written in the form p/q, where p and q are integers and q ≠ 0.
- **Worked Examples:** Example 1: Is -5 a rational number? Yes, because any integer can be written over 1: -5 = -5/1. Since -5 and 1 are integers, it fits the p/q rule.
- **Kid Likely Doubt:** Wait, is an integer like 7 a fraction? Yes! Just write it as 7/1.
- **"If you are confused" Helper:** If you can write the number as a clean fraction, it's Rational. (Rational comes from the word 'Ratio').
- **Common Mistakes:** Thinking integers and rational numbers are entirely separate sets. All integers ARE rational numbers.
- **Mini Recap:** W + Negatives = Integers (Z). Z + Fractions = Rational Numbers (Q).
- **Parent Explanation Tip:** Slice a pizza to visually show fractions (p/q). Then explain that an entire, uncut pizza can still be written as '1/1'.
- **Suggested Resource Links:** [BYJU'S: What are Rational Numbers?] - Helpful animations for fractions.
- **Suggested Visual Asset Notes:** A nesting doll or Venn diagram showing N inside W inside Z inside Q.
- **Linked Questions / Quick Check:** Sample Quick Check: Can a rational number have a denominator of 0? (No, division by zero is undefined).

#### Page 3: The Rebels: Irrational Numbers
- **Page ID:** `page_3_irrational`
- **Page Objective:** Introduce numbers that break the fraction rule and cannot be written as p/q.
- **Main Lesson Text:** Are there numbers that CANNOT be written as a neat fraction p/q? Yes! Imagine drawing a square where every side is exactly 1 unit long. What is the length of the diagonal? The Pythagorean theorem tells us it is exactly √2. If you try to write √2 as a decimal, you get 1.41421356... The numbers go on forever without ever settling into a repeating pattern. Because it never ends and never repeats, it is impossible to write it as a simple fraction. Numbers like √2, √3, and π are called **Irrational Numbers**.
- **Intuition-First Explanation:** An irrational number is like a messy string of yarn that goes on forever and never loops the exact same way twice.
- **Formal Definition / Result:** Irrational Numbers = Real numbers that cannot be expressed as a ratio of integers (p/q). Their decimal expansions are non-terminating and non-recurring.
- **Worked Examples:** Example: √3, √5, π (Pi).
- **Kid Likely Doubt:** Wait, I thought π was exactly 22/7? No, 22/7 is just a very close, easy approximation we use in school geometry. Real π never ends and never repeats.
- **"If you are confused" Helper:** If a square root doesn't solve neatly to an integer (like √4=2), it's almost certainly irrational.
- **Common Mistakes:** Thinking ALL square roots are irrational. (√9 is just 3, which is an integer, making it rational!). Always simplify the root first.
- **Mini Recap:** If a decimal never ends AND never repeats, it's an irrational number.
- **Parent Explanation Tip:** Show them π on a calculator or phone. Show them that 1/3 (0.333...) repeats neatly, but π just keeps spitting out random, unpredictable numbers.
- **Suggested Resource Links:** [NCERT Chapter 1: Number Systems] - Official syllabus definitions.
- **Suggested Visual Asset Notes:** A 1x1 square showing the diagonal length of √2.
- **Linked Questions / Quick Check:** Sample Quick Check: Is √16 rational or irrational? (Rational, because √16 = 4).

#### Page 4: Putting It Together: The Real Number Line
- **Page ID:** `page_4_real_numbers`
- **Page Objective:** Understand that Rational and Irrational numbers combine to form the continuous Real Number line.
- **Main Lesson Text:** If you take all the neatly packed fractions (Rational Numbers) and the infinite messy decimals (Irrational Numbers) and pour them into one big bucket, you get the **Real Numbers (R)**. The Number Line represents ALL Real Numbers. Every single point on that line corresponds to a unique real number, whether it's rational or irrational.
- **Intuition-First Explanation:** The number line isn't just a ruler with tick marks at the integers. It is infinitely dense. There are no gaps. Every pinpoint on the line is a Real Number.
- **Formal Definition / Result:** Real Numbers (R) = The set containing all rational numbers and all irrational numbers.
- **Worked Examples:** Example: On the number line, 0.5 (Rational) lives exactly halfway between 0 and 1. √2 (Irrational) lives right around 1.414.
- **Kid Likely Doubt:** If irrational numbers go on forever in decimals, how can they fit on a normal ruler? While we can't write their decimal exactly, their physical length is exact (like the diagonal of that 1x1 square)!
- **"If you are confused" Helper:** Rational + Irrational = Real.
- **Common Mistakes:** Believing that there are 'gaps' in the number line where no numbers exist.
- **Mini Recap:** Every point on the number line represents a unique real number.
- **Parent Explanation Tip:** Draw a line on paper. Ask them to point to 1.5. Then ask them to estimate where 1.41 (√2) would be. It shows that irrationals have an exact physical 'address' on the line.
- **Suggested Resource Links:** [CK-12: The Real Number Line] - Great interactive diagrams.
- **Suggested Visual Asset Notes:** A horizontal number line showing integers with big dots, 1/2 with a smaller dot, and √2 marked precisely with a star.
- **Linked Questions / Quick Check:** Sample Quick Check: True or False: Every point on the number line represents a rational number. (False, it could represent an irrational number).

#### Page 5: Demystifying Decimals: Which is Which?
- **Page ID:** `page_5_decimals`
- **Page Objective:** Translate repeating and non-repeating decimals into their respective number set categories.
- **Main Lesson Text:** Let's look at decimals carefully to settle the confusion once and for all. 
1. **Terminating Decimals:** Decimals that stop. Example: 0.25. This is just 25/100 or 1/4. Since it's a fraction, it is **RATIONAL**. 
2. **Non-Terminating, Recurring Decimals:** Decimals that go on forever, BUT they stutter (repeat a clear pattern). Example: 0.33333... This is exactly 1/3. Since it's a fraction, it is **RATIONAL**. 
3. **Non-Terminating, Non-Recurring Decimals:** Decimals that go on forever and NEVER repeat a pattern. Example: 1.1010010001... or π. Since they can never be written as a fraction, they are **IRRATIONAL**.
- **Intuition-First Explanation:** If a decimal has a predictable end or a predictable repeating loop, it's well-behaved (Rational). If it's pure chaos forever, it's Irrational.
- **Formal Definition / Result:** Rational numbers have decimal expansions that are either terminating or non-terminating recurring. Irrational numbers have non-terminating non-recurring decimal expansions.
- **Worked Examples:** Example 1: 0.142857142857... repeats the block '142857'. Therefore, it is Rational.
Example 2: 0.121121112... has a growing pattern, but no fixed repeating block. Therefore, it is Irrational.
- **Kid Likely Doubt:** If 0.999... goes on forever, isn't it irrational? No, it repeats the digit 9 endlessly. Because it repeats, it is Rational! (In fact, mathematically, 0.999... exactly equals 1).
- **"If you are confused" Helper:** Look for the bar! If a decimal can be written with a bar over it (like 0.3̄), it is Rational.
- **Common Mistakes:** Many students think 'if it goes on forever, it MUST be irrational.' WRONG! Repeating decimals are rational.
- **Mini Recap:** Terminating or Repeating = Rational. Non-Terminating AND Non-Repeating = Irrational.
- **Parent Explanation Tip:** Show them 1 ÷ 3 on a calculator. It fills the screen with 3s. It repeats forever, but it clearly came from the fraction 1/3. This proves repeating decimals are rational fractions!
- **Suggested Resource Links:** [Britannica School: Rational and Irrational Numbers] - Good reference for decimal expansions.
- **Suggested Visual Asset Notes:** A flowchart categorizing decimals. Top box: 'Does the decimal stop?' Yes -> Rational. No -> 'Does it repeat a pattern?' Yes -> Rational. No -> Irrational.
- **Linked Questions / Quick Check:** Sample Quick Check: Is 1.23232323... rational or irrational? (Rational, because it repeats).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The Number Set Cheat Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of all number set definitions and boundaries.
- **Compact Summary:** N: 1, 2, 3... (Counting)
W: 0, 1, 2, 3... (Counting + Zero)
Z: ...-2, -1, 0, 1, 2... (Negatives + Zero + Positives)
Q: Any p/q. (Fractions, terminating decimals, repeating decimals)
Irrational: Cannot be p/q. (Non-terminating NON-repeating decimals, √2, π)
Real (R): Rational + Irrational.
- **Trouble-Spot Reminder:** Confusing Whole numbers (starts at 0) with Natural numbers (starts at 1). In True/False questions, remember 0 is the ONLY difference.
- **Exam-Useful Points:** Be prepared to classify a list of numbers into these buckets in 1-mark or 2-mark exam questions.
- **Remediation Notes:** If you freeze up, draw the nesting Venn diagram on your scratch paper immediately.
- **One-Page Recap Style:** Venn diagram quick-reference bullet points.
- **Parent Support Note:** Quiz them verbally while walking: 'Is -5 a whole number?' (No, it's an integer). 'Is 0.5 an integer?' (No, it's rational).
- **Linked Revision Questions:** Revision Quick Check: True or False: Every integer is a whole number. (False, negatives are not whole).
- **Linked Exam Drill Refs:** Exam Drill Ref: Classification Table 1.1

#### Revision Page 2: Rational vs Irrational: The Final Showdown
- **Page ID:** `page_rev_2`
- **Revision Goal:** Quickly identify decimal and root types to avoid exam traps.
- **Compact Summary:** Decimal Form:
- Terminates (0.25) = Rational
- Repeats (0.333...) = Rational
- Never ends AND never repeats (π, 1.414...) = Irrational

Root Form:
- Perfect Squares (√4, √9, √25) = Rational (They equal 2, 3, 5)
- Non-Perfect Squares (√2, √3, √7) = Irrational.
- **Trouble-Spot Reminder:** Seeing '...' and instantly assuming it's irrational. 0.777... is rational! You must check if it repeats.
- **Exam-Useful Points:** Exams will try to trick you with roots of perfect squares (like √16). Always simplify the root first before answering.
- **Remediation Notes:** If an exam question asks if 0.444... is rational, try converting it to a fraction on scrap paper (it's 4/9) to prove it to yourself.
- **One-Page Recap Style:** Decision tree checklist for identifying rationality.
- **Parent Support Note:** Remind them that 'Rational' literally contains the word 'Ratio'. If they can picture it as a ratio (fraction), it's rational.
- **Linked Revision Questions:** Revision Quick Check: Is √81 rational? (Yes, it simplifies to 9).
- **Linked Exam Drill Refs:** Exam Drill Ref: Decimal Trap Drill 1.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** Spatial organization of the number sets to show subsets.
  - **What Should Appear:** Number System Venn Diagram: Nested circles/boxes.
  - **Labels Required:** N (inner), W, Z, Q (outer). A separate box nearby for Irrational. Both wrapped in a giant 'Real Numbers' box.
  - **Misconception to Fix:** Fixes the misconception that integers and rational numbers are separate entirely. It visually proves every integer is inside the rational box.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** Categorizing decimals rapidly for exams.
  - **What Should Appear:** Decision Tree Flowchart.
  - **Labels Required:** Top box: 'Does the decimal stop?' Branches to 'Yes' (Rational) and 'No'. 'No' branches to 'Does it repeat?' -> Yes (Rational), No (Irrational).
  - **Misconception to Fix:** Fixes the false assumption that all infinite decimals are irrational.
  - **Location:** Asset 1, Page 5

---

### D. Resource Links

- **Link:** [NCERT Official Book Class 9 Math Chapter 1]
  - **Why it is useful:** Provides the exact authoritative definitions required for the final exams.
  - **Best for:** basics

- **Link:** [Khan Academy: Rational and Irrational Numbers]
  - **Why it is useful:** Provides a deep, self-paced video explanation visualizing the difference between the sets.
  - **Best for:** deeper understanding

- **Link:** [BYJU'S: Number System Revision]
  - **Why it is useful:** High-quality, short animations that are perfect for quick exam prep.
  - **Best for:** revision

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** The Number System expands based on rules. Natural numbers count. Whole numbers add zero. Integers add negatives for debt. Rational numbers add fractions for sharing. Irrational numbers cover the messy geometric gaps (like √2) that fractions can't reach. Together, they make the Real Number Line.
- **Parent Helper Note per difficult subtopic:** Don't focus on memorizing the letters (N, Z, Q) first. Focus on the physical story: counting fingers (N), empty bowls (W), owing money (Z), slicing pizza (Q). The letters will follow naturally once the story makes sense.
- **Concept Rescue Note:** Emergency Exam Rescue: If a question asks to classify a number, ask yourself two things: 1. Can I simplify this root? (√25 -> 5). 2. Does this decimal repeat? If yes to either, it is RATIONAL.
