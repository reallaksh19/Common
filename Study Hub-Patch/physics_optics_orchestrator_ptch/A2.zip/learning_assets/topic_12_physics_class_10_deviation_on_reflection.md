# Physics Class 10 — Deviation on Reflection
**Topic ID:** `topic_12_physics_10`
**Concept Tags:** `deviation`, `reflection-math`, `grazing-incidence`, `optics`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What Does Deviation Mean?
- **Page ID:** `page_1_meaning_of_deviation`
- **Page Objective:** Understand the concept of a light ray being forced off its original straight path.
- **Main Lesson Text:** If a mirror wasn't there, a light ray would just keep traveling perfectly straight forward forever. But when it hits a mirror, its path is bent or 'deviated'. The **Angle of Deviation (δ)** is the angle between the original, intended straight path of the light ray and the new, reflected path it is forced to take.
- **Intuition-First Explanation:** Imagine driving a car straight down a road, but the road suddenly takes a sharp turn to the left. The angle between where you WERE pointing and where you are NOW pointing is your deviation.
- **Formal Definition / Result:** The angle of deviation is the angle formed between the direction of the incident ray extended forward and the reflected ray.
- **Worked Examples:** Example: If light hits a mirror straight on (i = 0°), it bounces straight back. It did a complete U-turn! The deviation is a full 180°.
- **Kid Likely Doubt:** Is deviation the same as reflection? No! Reflection is the bouncing action. Deviation is the *measurement of how much* the light got knocked off its original straight course.
- **"If you are confused" Helper:** Deviation = Original Path vs New Path.
- **Common Mistakes:** Confusing the Angle of Deviation with the Angle of Reflection. They are two different slices of the geometry.
- **Mini Recap:** Deviation measures how much the light bent away from its original forward direction.
- **Parent Explanation Tip:** Draw a dotted line straight through the mirror (original path). Draw the solid reflected line. Ask your child to point to the angle between them.
- **Suggested Resource Links:** [Physics Classroom: Reflection and Deviation] - Good visual intro.
- **Suggested Visual Asset Notes:** A diagram showing the incident ray continuing through the mirror as a dotted line, and the reflected ray bouncing off. The angle between the dotted line and reflected ray is marked δ.
- **Linked Questions / Quick Check:** Sample Quick Check: Does deviation measure the angle between the normal and the reflected ray? (No, that's the angle of reflection).

#### Page 2: Calculating the Angle of Deviation
- **Page ID:** `page_2_the_formula`
- **Page Objective:** Derive and use the formula for calculating deviation.
- **Main Lesson Text:** Let's figure out the math. A perfectly straight line is 180 degrees. The total 'straight path' geometry here consists of three chunks: the angle of incidence (i), the angle of reflection (r), and the angle of deviation (δ). 
Since they all sit on the straight 180° line, we know that: **i + r + δ = 180°**.
But wait! The First Law of Reflection tells us that i = r. 
So we can replace 'r' with another 'i': **i + i + δ = 180°**.
Which simplifies to: **2i + δ = 180°**. 
Therefore, the formula for the Angle of Deviation is: **δ = 180° - 2i**.
- **Intuition-First Explanation:** The whole pizza is 180 degrees. The incidence and reflection angles eat two identical slices. The deviation is whatever is left over.
- **Formal Definition / Result:** For a single reflection at a plane mirror, the angle of deviation δ = 180° - 2i, where i is the angle of incidence.
- **Worked Examples:** Example: If a ray hits at an angle of incidence of 30°. δ = 180 - 2(30) = 180 - 60 = 120°.
- **Kid Likely Doubt:** Why is the straight line 180? Because we are extending the incident ray straight *through* the mirror. A straight line in geometry is always an angle of 180 degrees.
- **"If you are confused" Helper:** δ = 180 - 2i.
- **Common Mistakes:** Using the angle given in the question blindly. If the question gives the angle to the MIRROR (e.g., 20°), you must find 'i' first (90-20=70°) before using the deviation formula!
- **Mini Recap:** The deviation formula is derived from the fact that i, r, and δ lie on a straight 180-degree line.
- **Parent Explanation Tip:** Have them write the formula on a flashcard. It is a very common numerical question in exams.
- **Suggested Resource Links:** [BYJU'S: Angle of Deviation] - Formula derivation.
- **Suggested Visual Asset Notes:** A step-by-step math derivation box showing the substitution of r with i.
- **Linked Questions / Quick Check:** Sample Quick Check: If i = 45°, what is the deviation? (180 - 90 = 90°).

#### Page 3: Extreme Cases: Grazing and Normal Incidence
- **Page ID:** `page_3_grazing_and_normal`
- **Page Objective:** Understand how deviation behaves at the extreme limits (0 degrees and 90 degrees).
- **Main Lesson Text:** Let's test our new formula at the extremes! 
**Normal Incidence (Hitting straight on):** The light hits the mirror perfectly straight down the normal. So, i = 0°. 
Deviation = 180° - 2(0) = 180°. 
The light bounced straight back where it came from. Maximum deviation! 
**Grazing Incidence (Hitting flat):** The light barely skims the flat surface of the mirror. It is 90° away from the normal. So, i = 90°. 
Deviation = 180° - 2(90) = 180° - 180° = 0°. 
The light barely touched the mirror and kept going straight. Zero deviation! 
This tells us a rule: As the angle of incidence *increases*, the deviation *decreases*.
- **Intuition-First Explanation:** If you throw a ball straight at a wall, it hits hard and comes straight back (huge change in direction). If you throw it skimming along the wall, it barely changes direction at all.
- **Formal Definition / Result:** Deviation is maximum (180°) at normal incidence (i=0) and minimum (0°) at grazing incidence (i=90).
- **Worked Examples:** Example: i = 10° -> δ = 160°. i = 80° -> δ = 20°.
- **Kid Likely Doubt:** Is grazing incidence even really reflection? Technically, yes! Even though the angle barely changes, the light photon did interact with the mirror's electromagnetic field.
- **"If you are confused" Helper:** Straight on = U-Turn (180). Skimming = No turn (0).
- **Common Mistakes:** Confusing the extremes. Thinking that an angle of incidence of 0 means 0 deviation. (It's the opposite!)
- **Mini Recap:** Deviation is inversely related to the angle of incidence.
- **Parent Explanation Tip:** Roll a ball at a wall to physically demonstrate these two extremes. It makes the math physically 'click'.
- **Suggested Resource Links:** [NCERT Exemplar] - Good conceptual questions on grazing incidence.
- **Suggested Visual Asset Notes:** A line graph showing Angle of Incidence (x-axis) vs Deviation (y-axis). It's a straight line sloping downwards.
- **Linked Questions / Quick Check:** Sample Quick Check: At what angle of incidence is deviation maximum? (0°).

#### Page 4: Why Does Deviation Matter?
- **Page ID:** `page_4_applications`
- **Page Objective:** Connect the math of deviation to real-world optics and engineering.
- **Main Lesson Text:** Why do physicists care so much about calculating deviation? Because we use mirrors to steer light! 
Inside a periscope (used in submarines), we need to bend light exactly 90 degrees twice to get it down the tube into the sailor's eye. 
To get a 90° deviation, what must the angle of incidence be? 
90 = 180 - 2i 
2i = 90 
i = 45°. 
This means engineers must install the mirrors in a periscope exactly at a 45° angle to the incoming light! By understanding deviation, we can aim lasers, build telescopes, and steer light through fiber optic cables.
- **Intuition-First Explanation:** Deviation is the steering wheel for light. If you want the light to go left, you calculate the deviation needed and tilt the mirror.
- **Formal Definition / Result:** Optical instruments utilize specific angles of deviation to direct light paths through complex geometries.
- **Worked Examples:** Example: In a kaleidoscope, multiple mirrors are set at specific angles to create multiple calculated deviations, resulting in repeating patterns.
- **Kid Likely Doubt:** Why not just use a curved tube? Because light only travels in straight lines! (Rectilinear propagation). You MUST use mirrors to bounce it around corners.
- **"If you are confused" Helper:** Deviation = Steering Light.
- **Common Mistakes:** Thinking deviation is just a math puzzle. It is the core of optical engineering.
- **Mini Recap:** Calculating deviation allows us to design instruments like periscopes that bend light around corners.
- **Parent Explanation Tip:** If you have two small mirrors, let your child try to build a makeshift periscope using a cardboard tube. They will quickly realize the angles matter!
- **Suggested Resource Links:** [YouTube: How a Periscope Works] - Great practical application of the formula.
- **Suggested Visual Asset Notes:** A diagram of a periscope showing light hitting two mirrors. The 90-degree deviation at each mirror is highlighted.
- **Linked Questions / Quick Check:** Sample Quick Check: If you want to deviate a laser by 100°, what must 'i' be? (40°).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Deviation Formula Mastery
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast, error-free calculation of deviation.
- **Compact Summary:** 1. **The Formula:** δ = 180° - 2i
2. **The Mirror Trap:** If they give you the angle with the mirror (let's say 20°), DO NOT plug 20 into the formula! First find i. (i = 90 - 20 = 70°). Then plug it in: δ = 180 - 2(70) = 40°.
3. **The Reverse Question:** If they give you the deviation (δ = 120°) and ask for i. 
120 = 180 - 2i -> 2i = 60 -> i = 30°.
- **Trouble-Spot Reminder:** Falling for the 'Mirror Trap' is the number one way students lose marks on deviation questions. Always find 'i' first.
- **Exam-Useful Points:** This will likely be a 2-mark numerical calculation in Section B.
- **Remediation Notes:** Write 'Find i first!' at the top of your exam paper when you see a mirror question.
- **One-Page Recap Style:** Three-step calculation guide.
- **Parent Support Note:** Give them reverse questions. 'The deviation is 140. What is i?' (20). It tests their algebra skills.
- **Linked Revision Questions:** Revision Quick Check: Angle to mirror is 10°. What is the deviation? (i=80, so dev=20°).
- **Linked Exam Drill Refs:** Exam Drill Ref: Deviation Math Drills 12.1

#### Revision Page 2: Graphing Deviation
- **Page ID:** `page_rev_2`
- **Revision Goal:** Understand the relationship between incidence and deviation graphically.
- **Compact Summary:** If you plot Angle of Incidence (x-axis) against Angle of Deviation (y-axis):
- When x = 0 (Normal incidence), y = 180 (Max deviation).
- When x = 90 (Grazing incidence), y = 0 (Min deviation).
- The graph is a straight line sloping downwards.
- The relationship is inversely proportional (as one goes up, the other goes down).
- **Trouble-Spot Reminder:** Students sometimes draw a curve instead of a straight line. Because the formula is linear (δ = 180 - 2i), the graph MUST be a straight line.
- **Exam-Useful Points:** Graph questions often appear in MCQs. Pick the graph with the straight line going down.
- **Remediation Notes:** Plug in 3 numbers (0, 45, 90) into the formula and plot them on scratch paper to prove it's a straight line.
- **One-Page Recap Style:** Bullet points mapping to a mental graph.
- **Parent Support Note:** Have them draw the graph on a piece of paper and label the x and y intercepts.
- **Linked Revision Questions:** Revision Quick Check: As the angle of incidence increases, does deviation increase or decrease? (Decrease).
- **Linked Exam Drill Refs:** Exam Drill Ref: Graph Identification 12.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To visually define the angle of deviation.
  - **What Should Appear:** A ray diagram. The incident ray hits the mirror and reflects. The incident ray is ALSO extended straight *through* the mirror as a dotted line. The angle between the dotted line and the reflected ray is marked δ.
  - **Labels Required:** Mirror, Incident Ray, Reflected Ray, Original Path (dotted), Angle δ.
  - **Misconception to Fix:** Prevents students from confusing deviation with the angle of reflection.
  - **Location:** Asset 1, Page 1

- **Teaching Purpose:** To show the inverse relationship graphically.
  - **What Should Appear:** A standard line graph. X-axis is 'Angle of Incidence (0 to 90)'. Y-axis is 'Deviation (0 to 180)'. A straight line connects (0, 180) to (90, 0).
  - **Labels Required:** y-intercept (0, 180), x-intercept (90, 0).
  - **Misconception to Fix:** Clarifies that the relationship is perfectly linear, not curved.
  - **Location:** Asset 2, Page 2

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the foundational laws required to derive the formula.
  - **Best for:** basics

- **Link:** [BYJU'S: Angle of Deviation]
  - **Why it is useful:** Excellent step-by-step mathematical derivation.
  - **Best for:** remediation

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Deviation measures how much a mirror knocked a light ray off its straight-line path. The formula is δ = 180° - 2i. Hitting a mirror straight-on causes a 180° U-turn. Skimming a mirror causes almost 0° deviation.
- **Parent Helper Note per difficult subtopic:** When doing these calculations, watch out for the mirror trap. Always ensure your child is plugging the Angle of Incidence (from the normal) into the formula, not the angle from the mirror floor.
- **Concept Rescue Note:** Exam Rescue: If you forget the formula δ = 180 - 2i, just draw the diagram! A straight line is 180. The 'V' shape of the bounce takes up 'i' and 'r'. Since i=r, the leftovers must be 180 - i - i.
