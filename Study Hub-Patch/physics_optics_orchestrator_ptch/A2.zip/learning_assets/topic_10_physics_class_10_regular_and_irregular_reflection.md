# Physics Class 10 — Regular and Irregular Reflection
**Topic ID:** `topic_10_physics_10`
**Concept Tags:** `regular-reflection`, `irregular-reflection`, `specular`, `diffuse`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: Smooth vs Rough Surfaces
- **Page ID:** `page_1_smooth_vs_rough`
- **Page Objective:** Understand that physical smoothness dictates how light bounces.
- **Main Lesson Text:** Why can you see your face in a mirror, but not in a piece of white paper? The answer lies in the surface. A mirror is incredibly smooth, even at a microscopic level. A piece of paper feels smooth to your finger, but under a microscope, it looks like a bumpy mountain range! The physical smoothness of the surface entirely changes how the light rays bounce off it.
- **Intuition-First Explanation:** Imagine throwing a handful of bouncy balls at a flat concrete floor. They all bounce up together. Now imagine throwing them at a rocky, bumpy garden. They bounce in random directions everywhere!
- **Formal Definition / Result:** Surfaces are classified optically based on their roughness relative to the wavelength of incident light. Smooth surfaces cause specular reflection; rough surfaces cause diffuse reflection.
- **Worked Examples:** Example 1: A still lake acts as a smooth surface. 
Example 2: A brick wall acts as a rough surface.
- **Kid Likely Doubt:** But my phone screen is smooth, why can't I always see my face in it? Because when the screen is ON, it emits its own light which overpowers the weak reflection. Turn it off, and it acts like a mirror!
- **"If you are confused" Helper:** Smooth = Mirror. Rough = Everything else.
- **Common Mistakes:** Assuming paper is 'smooth' in a physics context just because it feels smooth to human touch.
- **Mini Recap:** The microscopic bumps on a surface determine how light behaves when it hits it.
- **Parent Explanation Tip:** Ask them to look at a polished metal spoon (smooth) vs a wooden spoon (rough). They both reflect light, but very differently.
- **Suggested Resource Links:** [Khan Academy: Specular and Diffuse Reflection] - Great visual overview.
- **Suggested Visual Asset Notes:** A magnifying glass graphic zooming in on a piece of paper to reveal bumpy mountains.
- **Linked Questions / Quick Check:** Sample Quick Check: Is an unpolished piece of wood a smooth or rough surface in optics? (Rough).

#### Page 2: Regular (Specular) Reflection
- **Page ID:** `page_2_regular`
- **Page Objective:** Define regular reflection and understand that it forms images.
- **Main Lesson Text:** When a beam of parallel light rays hits a perfectly smooth surface (like a mirror), all the rays bounce off perfectly parallel to each other. This organized bouncing is called **Regular Reflection** (or Specular Reflection). Because the light rays stay neatly organized, they preserve the shape of the object they came from. This organized light travels into your eye, allowing your brain to form a clear, sharp image.
- **Intuition-First Explanation:** Regular reflection is a disciplined army marching in formation. They hit the wall and turn around together, staying in perfect rows.
- **Formal Definition / Result:** Regular reflection occurs when parallel rays of light fall on a smooth surface and are reflected back as parallel rays in a definite direction.
- **Worked Examples:** Example: Looking into a flat, highly polished silver platter and seeing a perfect reflection of your face.
- **Kid Likely Doubt:** Why is it called 'Specular'? It comes from the Latin word 'speculum', which means mirror!
- **"If you are confused" Helper:** Regular = Organized = Forms an Image.
- **Common Mistakes:** Thinking that regular reflection scatters light. It does exactly the opposite; it keeps light bundled together.
- **Mini Recap:** Regular reflection happens on smooth surfaces, keeps parallel rays parallel, and forms images.
- **Parent Explanation Tip:** Stand in front of a mirror with them. Explain that the ONLY reason they see an image is because the light rays stayed perfectly parallel while bouncing off the glass.
- **Suggested Resource Links:** [NCERT Science Class 10] - Check the diagram for regular reflection.
- **Suggested Visual Asset Notes:** A diagram of 3 parallel incoming rays hitting a flat line (mirror) and bouncing off as 3 perfectly parallel outgoing rays.
- **Linked Questions / Quick Check:** Sample Quick Check: Does regular reflection form an image? (Yes).

#### Page 3: Irregular (Diffuse) Reflection
- **Page ID:** `page_3_irregular`
- **Page Objective:** Define irregular reflection and understand why it scatters light without forming an image.
- **Main Lesson Text:** When a beam of parallel light rays hits a rough, bumpy surface (like paper, a wall, or clothing), the bumps cause the rays to bounce off in entirely different, random directions. This is called **Irregular Reflection** (or Diffuse Reflection). Because the light rays are scattered chaotically, the 'shape' of the light is destroyed. Irregular reflection does NOT form an image.
- **Intuition-First Explanation:** Irregular reflection is like a bucket of water hitting a jagged rock. It splashes everywhere.
- **Formal Definition / Result:** Irregular reflection occurs when parallel rays of light fall on a rough surface and are reflected in various different directions.
- **Worked Examples:** Example: Shining a flashlight at a piece of cardboard. You don't see an image of the flashlight in the cardboard, but the cardboard lights up.
- **Kid Likely Doubt:** If it doesn't form an image, is it useless? NO! Irregular reflection is the most important thing in the world! It scatters light everywhere so we can see objects from any angle.
- **"If you are confused" Helper:** Irregular = Scattered = No Image.
- **Common Mistakes:** Thinking irregular reflection means the light is absorbed. The light still bounces, it just bounces randomly.
- **Mini Recap:** Irregular reflection happens on rough surfaces, scatters parallel rays, and forms no image.
- **Parent Explanation Tip:** Point out that if walls had regular reflection (mirrors), a single lightbulb would blind you, and the room would be a confusing hall of mirrors. Rough walls scatter the light softly to illuminate the whole room.
- **Suggested Resource Links:** [BYJU'S: Diffuse Reflection] - Good explanation of why we need diffuse reflection.
- **Suggested Visual Asset Notes:** A diagram of 3 parallel incoming rays hitting a bumpy line. The 3 outgoing rays bounce in completely different, crisscrossing directions.
- **Linked Questions / Quick Check:** Sample Quick Check: Do parallel incident rays remain parallel after irregular reflection? (No).

#### Page 4: Do the Laws of Reflection Fail?
- **Page ID:** `page_4_the_laws`
- **Page Objective:** Repair the massive misconception that irregular reflection breaks the laws of physics.
- **Main Lesson Text:** Here is the biggest trap in Class 10 Physics: Many students look at the scattered rays of irregular reflection and say, 'Ah, the laws of reflection failed here!' THIS IS COMPLETELY FALSE. The Laws of Reflection NEVER fail. They apply perfectly to every single microscopic bump on the rough surface.
- **Intuition-First Explanation:** Physics laws don't just 'turn off' because a surface is bumpy. Every single ray follows the rules perfectly on its own tiny piece of the mountain.
- **Formal Definition / Result:** In irregular reflection, the laws of reflection are obeyed at each point of incidence. The scattering occurs because the normal at different points on the rough surface points in different directions.
- **Worked Examples:** Example: Ray A hits the left side of a microscopic bump, so its Normal points left. It reflects left. Ray B hits the right side of the bump, so its Normal points right. It reflects right.
- **Kid Likely Doubt:** But they don't bounce off parallel! Because the 'Normals' aren't parallel! The Angle of Incidence ALWAYS equals the Angle of Reflection (i=r) for EVERY individual ray.
- **"If you are confused" Helper:** The surface is crooked, not the physics.
- **Common Mistakes:** Writing in an exam that 'irregular reflection occurs because the laws of reflection are not followed.' You will lose all marks for this.
- **Mini Recap:** The laws of reflection are perfectly obeyed during irregular reflection; the rays scatter because the microscopic surface angles differ.
- **Parent Explanation Tip:** Draw a jagged, zig-zag mountain line on paper. Have them draw a 'Normal' (90 degrees) for the left slope, and a 'Normal' for the right slope. They will instantly see why the light scatters.
- **Suggested Resource Links:** [Physics Classroom: Diffuse Reflection] - Shows the normals on a bumpy surface clearly.
- **Suggested Visual Asset Notes:** A close up of a bumpy surface. Two parallel incoming rays hit different bumps. Dotted 'Normal' lines are drawn on both bumps pointing in different directions, showing i=r is true for both.
- **Linked Questions / Quick Check:** Sample Quick Check: Is ∠i = ∠r during irregular reflection? (Yes, for every individual ray).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Compare and Contrast: Regular vs Irregular
- **Page ID:** `page_rev_1`
- **Revision Goal:** Provide a quick comparison chart for exams.
- **Compact Summary:** **Regular Reflection:**
- Surface: Smooth, polished (mirrors, still water).
- Incident Rays: Parallel.
- Reflected Rays: Remain parallel.
- Result: Forms a clear image.
- Laws of Reflection: Obeyed.

**Irregular (Diffuse) Reflection:**
- Surface: Rough, unpolished (paper, wood, walls).
- Incident Rays: Parallel.
- Reflected Rays: Scattered in different directions.
- Result: Forms NO image. Allows us to see the object.
- Laws of Reflection: Obeyed.
- **Trouble-Spot Reminder:** Students often write 'Laws of reflection NOT obeyed' for irregular reflection. They ARE obeyed. This is a common trap.
- **Exam-Useful Points:** Be ready to draw both diagrams side by side. Ensure the incoming rays are parallel in BOTH diagrams.
- **Remediation Notes:** Practice drawing the bumpy surface diagram. Make sure to draw tiny dotted 'Normal' lines to prove you understand why the rays scatter.
- **One-Page Recap Style:** T-Chart comparing the two types of reflection.
- **Parent Support Note:** Cover up one side of the summary and ask them to define the characteristics of Regular Reflection from memory.
- **Linked Revision Questions:** Revision Quick Check: Which type of reflection allows us to read a book? (Irregular/Diffuse reflection).
- **Linked Exam Drill Refs:** Exam Drill Ref: Comparison Matrix 10.1

#### Revision Page 2: Application in Daily Life
- **Page ID:** `page_rev_2`
- **Revision Goal:** Connect the concepts to real-world exam application questions.
- **Compact Summary:** Exams love application questions. 
**Why do we use matte (rough) paint on walls?** Matte paint causes irregular reflection. It scatters the light evenly around the room without causing a harsh glare or a blinding reflection of the lightbulb.
**Why is it hard to drive at night when the road is wet?** A dry asphalt road is rough (irregular reflection), scattering headlights so you can see the road. A wet road fills in the bumps with water, making it a smooth surface (regular reflection). The headlights reflect forward into the eyes of oncoming drivers instead of scattering back to you!
- **Trouble-Spot Reminder:** Connecting the physics terms (specular/diffuse) to the real-world examples (wet roads/matte paint).
- **Exam-Useful Points:** The wet road question is a classic 2-mark reasoning question.
- **Remediation Notes:** When reading an application question, ask yourself: 'Is the surface becoming smoother or rougher?'
- **One-Page Recap Style:** Real-world Q&A format.
- **Parent Support Note:** Discuss the wet road example while driving in the rain. Connecting physics to an actual experience makes it unforgettable.
- **Linked Revision Questions:** Revision Quick Check: Does gloss (shiny) paint cause regular or irregular reflection? (Regular reflection).
- **Linked Exam Drill Refs:** Exam Drill Ref: Real-World Reasoning 10.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To definitively contrast the two types of reflection.
  - **What Should Appear:** A split diagram. Left: Regular reflection (smooth line, parallel incoming/outgoing rays). Right: Irregular reflection (bumpy line, parallel incoming, scattered outgoing rays).
  - **Labels Required:** Regular Reflection, Smooth Surface, Irregular Reflection, Rough Surface, Parallel Incident Rays, Scattered Reflected Rays.
  - **Misconception to Fix:** Shows that the INCOMING rays are parallel in both scenarios. Only the outgoing rays change.
  - **Location:** Asset 1, Page 3

- **Teaching Purpose:** To kill the misconception that the laws of reflection fail on rough surfaces.
  - **What Should Appear:** A zoomed-in cross-section of a bumpy surface. Show two parallel rays hitting two differently angled slopes of the bumps. Draw the 'Normal' for both slopes to prove that Angle i = Angle r for both rays.
  - **Labels Required:** Surface normal 1, Surface normal 2, ∠i = ∠r.
  - **Misconception to Fix:** Proves the laws of physics don't break just because a surface is bumpy.
  - **Location:** Asset 1, Page 4

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the official syllabus definitions and standard diagrams for exams.
  - **Best for:** basics

- **Link:** [YouTube: Physics of Wet Roads at Night]
  - **Why it is useful:** Excellent real-world video explaining the shift from diffuse to specular reflection.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Smooth surfaces cause regular reflection (parallel in, parallel out) and form images. Rough surfaces cause irregular reflection (parallel in, scattered out) and form no images, but illuminate the room. BOTH obey the laws of reflection perfectly.
- **Parent Helper Note per difficult subtopic:** The biggest trap here is the 'Laws fail' myth. Drill this into your child: The laws of physics never fail. The surface is just crooked.
- **Concept Rescue Note:** Exam Rescue: If asked to draw irregular reflection, DO NOT draw the incoming rays scattered. Incoming rays are ALWAYS drawn parallel to each other. Only the outgoing rays get messy.
