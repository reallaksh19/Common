# Physics Class 10 — Rotation of Plane Mirror / Turn of Reflected Ray
**Topic ID:** `topic_13_physics_10`
**Concept Tags:** `mirror-rotation`, `optical-lever`, `reflected-ray-turn`, `the-normal`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What Happens When a Mirror Rotates?
- **Page ID:** `page_1_the_phenomenon`
- **Page Objective:** Understand the physical phenomenon of rotating a mirror while keeping the light source fixed.
- **Main Lesson Text:** Imagine you are holding a laser pointer perfectly still, shining it at a mirror. The laser bounces off the mirror and hits the wall. Now, without moving your laser hand, you slowly tilt the mirror. What happens to the dot on the wall? It moves! But it doesn't just move a little bit; it swings across the wall much faster than you are turning the mirror. This is a famous optical effect: turning a mirror amplifies the movement of the reflected ray.
- **Intuition-First Explanation:** Think of a lighthouse. The heavy bulb inside rotates slowly, but the beam of light sweeps across the horizon incredibly fast.
- **Formal Definition / Result:** When a plane mirror is rotated by an angle θ about an axis in its plane, keeping the incident ray fixed, the reflected ray rotates by an angle of 2θ.
- **Worked Examples:** Example: If you tilt a hand-held mirror by 10 degrees, the reflected sunlight will swing across the room by 20 degrees.
- **Kid Likely Doubt:** Why does it move faster? Shouldn't it just move the exact same amount as the mirror? No! Because tilting the mirror changes TWO things at once: the 'floor' the light hits, AND the angle the light hits the floor at. These two changes stack together.
- **"If you are confused" Helper:** Mirror turns by θ -> Light turns by 2θ.
- **Common Mistakes:** Assuming the reflected ray turns by the same angle as the mirror.
- **Mini Recap:** Rotating a mirror while keeping the light source still causes the reflected beam to swing at double the angle.
- **Parent Explanation Tip:** Give them a small mirror and a flashlight. Have them hold the flashlight still and slightly twist the mirror. Ask them to watch how fast the light sweeps across the ceiling.
- **Suggested Resource Links:** [Khan Academy: Rotating Mirrors] - Good visual demonstration.
- **Suggested Visual Asset Notes:** A drawing of a laser pointer hitting a mirror. A ghosted outline shows the mirror tilted slightly, and a massive arrow shows the reflected beam swinging wildly.
- **Linked Questions / Quick Check:** Sample Quick Check: If a mirror rotates 15°, how much does the reflected ray rotate? (30°).

#### Page 2: Deriving the 'Twice the Angle' Theorem
- **Page ID:** `page_2_the_derivation`
- **Page Objective:** Understand the geometric proof behind the 2θ rule.
- **Main Lesson Text:** Let's prove it! 
1. Let the original angle of incidence be 'x'. So the angle of reflection is also 'x'. The total angle between incoming and outgoing light is 2x.
2. Now, rotate the mirror by an angle θ. 
3. Because the mirror tilted by θ, the imaginary Normal line (which is glued at 90° to the mirror) ALSO tilts by θ.
4. Since the laser didn't move, but the Normal tilted AWAY from it by θ, the new angle of incidence is now (x + θ). 
5. By the First Law of Reflection, the new angle of reflection MUST also be (x + θ). 
6. The new total angle between incoming and outgoing light is (x + θ) + (x + θ) = 2x + 2θ. 
7. The old total angle was 2x. The new total angle is 2x + 2θ. The difference is exactly **2θ**!
- **Intuition-First Explanation:** The normal line is the referee. When the mirror tilts, the referee moves. The incoming light now has a bigger angle to reach the referee. The outgoing light must travel that same bigger angle away. The extra distance is doubled!
- **Formal Definition / Result:** Let ∠i be the initial incidence. Rotation by θ shifts the normal by θ. New incidence = ∠i + θ. New reflection = ∠i + θ. Total shift of reflected ray = (∠i + θ) + (∠i + θ) - 2∠i = 2θ.
- **Worked Examples:** Example: Original angle was 30 (total 60). Mirror tilts 10°. Normal moves 10°. New angle is 40 (total 80). 80 - 60 = 20° shift. Exactly double the 10° tilt!
- **Kid Likely Doubt:** Is the normal physically attached to the mirror? Yes! Think of the normal as a flagpole permanently glued at 90 degrees to the glass. If the glass tilts, the pole tilts.
- **"If you are confused" Helper:** Normal tilts by θ -> Incidence grows by θ -> Reflection grows by θ -> Total growth = 2θ.
- **Common Mistakes:** Forgetting that the angle of incidence AND the angle of reflection both increase. Students often only add θ once.
- **Mini Recap:** Because the normal shifts, the change is applied to both the incoming and outgoing angles, resulting in a 2θ shift.
- **Parent Explanation Tip:** Draw the diagram with them step-by-step. Do not show them the finished diagram; it looks like a mess of lines. Draw the first mirror, then the tilted mirror over it.
- **Suggested Resource Links:** [BYJU'S: Rotation of Plane Mirror] - Excellent step-by-step derivation.
- **Suggested Visual Asset Notes:** A heavily labeled geometric proof diagram showing the old normal (N1), the new normal (N2), and the angle θ between them.
- **Linked Questions / Quick Check:** Sample Quick Check: When a mirror rotates by θ, how much does the Normal line rotate? (θ).

#### Page 3: Why is this Useful? (The Optical Lever)
- **Page ID:** `page_3_applications`
- **Page Objective:** Connect the 2θ theorem to real-world scientific instruments.
- **Main Lesson Text:** Why do physicists care about this 2θ trick? Because it acts as an **Optical Lever**. It amplifies tiny, unseeable movements into massive, easily readable movements. 
Imagine a tiny wire in a scientific machine that twists by just 0.5 degrees. You can't see that with your naked eye! 
But if you glue a tiny mirror to that wire and shine a laser at it, the reflected laser beam on the far wall will swing by 1.0 degree. If the wall is far enough away, that 1 degree swing might move the laser dot by 10 centimeters! You just amplified a microscopic twist into a 10 cm movement.
- **Intuition-First Explanation:** It's a magnifying glass for movement. A small tilt in the mirror creates a huge swing on the wall.
- **Formal Definition / Result:** The optical lever uses the 2θ magnification principle of mirror rotation to measure minute angular displacements in instruments like the mirror galvanometer.
- **Worked Examples:** Example: Galvanometers (which measure tiny electric currents) use a mirror attached to a coil. When current flows, the coil twists slightly, and the optical lever makes the reading visible on a scale.
- **Kid Likely Doubt:** Does the distance to the wall matter? Yes! The further away the wall is, the longer the 'lever' is, and the further the laser dot will travel. This is simple geometry (arc length = radius * angle).
- **"If you are confused" Helper:** Small Mirror Tilt = Big Laser Swing.
- **Common Mistakes:** Thinking the optical lever magnifies images like a telescope. It doesn't magnify pictures; it magnifies angular movement.
- **Mini Recap:** The 2θ rule is used in instruments to amplify microscopic rotations into visible measurements.
- **Parent Explanation Tip:** If you have a laser pointer, stand far away from a wall. Wiggle your wrist just a tiny bit. The dot on the wall will fly around wildly. This is the lever principle!
- **Suggested Resource Links:** [Physics Classroom: Optical Lever] - Shows how galvanometers work.
- **Suggested Visual Asset Notes:** A diagram of a galvanometer: A tiny mirror attached to a wire, with a laser bouncing off it onto a giant curved ruler on the wall.
- **Linked Questions / Quick Check:** Sample Quick Check: What instrument uses the 2θ rule to measure tiny electric currents? (A mirror galvanometer).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The 2θ Theorem Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of the theorem and its mathematical variables.
- **Compact Summary:** **The Rule:** Mirror turns by θ -> Reflected ray turns by 2θ.
**Condition:** The incident ray (laser pointer) MUST be held completely still.
**The Cause:** The Normal line is fixed at 90° to the mirror. When the mirror tilts, the Normal tilts by θ. This adds θ to the angle of incidence AND θ to the angle of reflection, causing a total change of 2θ.
- **Trouble-Spot Reminder:** Trick questions! If an exam says 'A mirror is tilted by 10° AND the incident ray is tilted by 10° in the opposite direction...', the rule changes! The basic 2θ rule only works if the incident ray is FIXED.
- **Exam-Useful Points:** This is a very common 1-mark numerical question or a 3-mark derivation question.
- **Remediation Notes:** If you forget if it's θ/2 or 2θ, think of the lighthouse. The beam swings FASTER than the bulb turns. So it must be multiplied (2θ), not divided.
- **One-Page Recap Style:** Bold rule block with warning labels.
- **Parent Support Note:** Ask them the rule. Then ask them 'What is the one condition required for the rule to work?' (The light source must be fixed/still).
- **Linked Revision Questions:** Revision Quick Check: Mirror rotates 25°. Reflected ray rotates by? (50°).
- **Linked Exam Drill Refs:** Exam Drill Ref: 2-Theta Calculations 13.1

#### Revision Page 2: Optical Lever Summary
- **Page ID:** `page_rev_2`
- **Revision Goal:** Recall the application of the theorem for reasoning questions.
- **Compact Summary:** **Concept:** The Optical Lever.
**Function:** Amplifies very small angular rotations into large, easily measurable linear displacements on a scale.
**How it works:** A small mirror is attached to the rotating object. A fixed light beam hits the mirror. Because of the 2θ rule, a tiny rotation of the object causes a large swing of the reflected beam on a distant scale.
**Use Case:** Mirror Galvanometers (measuring tiny electrical currents).
- **Trouble-Spot Reminder:** Students forget the name 'Optical Lever'. They can describe it, but lose marks for not using the correct scientific terminology.
- **Exam-Useful Points:** Expect a 2-mark question: 'State the principle of the optical lever and give one application.'
- **Remediation Notes:** Write 'OPTICAL LEVER = GALVANOMETER = 2θ' on a sticky note.
- **One-Page Recap Style:** Vocabulary and definition block.
- **Parent Support Note:** Test their vocabulary. Ask them 'What do we call the setup that uses a mirror to amplify movement?'
- **Linked Revision Questions:** Revision Quick Check: Does an optical lever magnify images or angular movement? (Angular movement).
- **Linked Exam Drill Refs:** Exam Drill Ref: Applications of Reflection 13.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To visually untangle the complex derivation diagram.
  - **What Should Appear:** A clean, color-coded derivation diagram. Mirror 1 and Normal 1 in blue. Mirror 2 and Normal 2 in red. The fixed incident ray in black. The two reflected rays in green.
  - **Labels Required:** M1, M2, N1, N2, θ, 2θ, Incident Ray, Reflected Rays.
  - **Misconception to Fix:** Prevents students from getting lost in a maze of pencil lines by color-coding the 'before' and 'after' states.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** To show how distance amplifies the 2θ effect.
  - **What Should Appear:** A diagram of the optical lever. A tiny mirror tilting by θ. The reflected beam hits a wall close by (small movement), and a wall far away (huge movement).
  - **Labels Required:** Mirror, θ, 2θ, Short Distance, Long Distance.
  - **Misconception to Fix:** Proves that the physical movement of the dot on the wall depends on BOTH the angle and the distance to the wall.
  - **Location:** Asset 1, Page 3

---

### D. Resource Links

- **Link:** [NCERT Exemplar Class 10 Science]
  - **Why it is useful:** Contains excellent high-level questions testing the 2θ derivation.
  - **Best for:** revision

- **Link:** [YouTube: Mirror Galvanometer Demonstration]
  - **Why it is useful:** Seeing the physical machine makes the 'optical lever' concept instantly understandable.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** If you hold a laser still and tilt a mirror by an angle θ, the reflected beam swings by exactly 2θ. This happens because the Normal tilts with the mirror, doubling the effect on the light. This '2θ trick' is used in Optical Levers to measure tiny movements.
- **Parent Helper Note per difficult subtopic:** The math derivation for this is visually confusing. If your child is struggling, have them draw it on two separate pieces of paper (Before and After), and then overlay them using a window or a light box.
- **Concept Rescue Note:** Exam Rescue: If you can't remember the algebraic proof in the exam, write down the core logic steps: 1. Normal tilts by θ. 2. Incidence increases by θ. 3. Reflection increases by θ. 4. Total change is 2θ. You will still get most of the marks!
