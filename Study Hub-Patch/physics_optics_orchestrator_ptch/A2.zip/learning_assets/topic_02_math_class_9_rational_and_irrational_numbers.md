# Mathematics Class 9 — Rational and Irrational Numbers
**Topic ID:** `topic_02_mathematics_9`
**Concept Tags:** `rational-numbers`, `irrational-numbers`, `p-q-form`, `decimal-expansion`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What Makes a Number Rational?
- **Page ID:** `page_1_rational`
- **Page Objective:** Understand the precise definition of a rational number and the p/q form.
- **Main Lesson Text:** A rational number is any number that can be expressed as a ratio of two integers, p/q, where the denominator q is not zero. Think of it as a number that can be 'rationed' or divided exactly. If you can write it as a simple fraction, it belongs to the rational club.
- **Intuition-First Explanation:** If you have 3 pizzas and want to share them among 4 friends, each friend gets 3/4 of a pizza. The number 3/4 represents a very real, very exact quantity.
- **Formal Definition / Result:** A number 'r' is called a rational number if it can be written in the form p/q, where p and q are integers and q ≠ 0.
- **Worked Examples:** Example 1: Is 7 a rational number? Yes, because 7 can be written as 7/1.
Example 2: Is -2/3 a rational number? Yes, -2 and 3 are both integers.
- **Kid Likely Doubt:** Why can't q be zero? Because dividing by zero is impossible! If you have 3 pizzas and 0 friends to share them with, asking 'how much does each friend get' doesn't make sense.
- **"If you are confused" Helper:** Rational = Ratio. If you can write it as a ratio (fraction) of two solid integers, it's rational.
- **Common Mistakes:** Forgetting that negative fractions (like -5/2) are completely rational.
- **Mini Recap:** A rational number is any integer over another non-zero integer.
- **Parent Explanation Tip:** Show them a recipe that calls for '1/2 cup of sugar' and explain that rational numbers are the numbers we use for measuring parts in real life.
- **Suggested Resource Links:** [Khan Academy: Intro to Rational Numbers] - Good for visualizing the p/q form.
- **Suggested Visual Asset Notes:** An illustration of 3 pizzas being split into 4 pieces each, showing the fraction 3/4 clearly.
- **Linked Questions / Quick Check:** Sample Quick Check: Can the numerator 'p' be zero? (Yes, 0/5 = 0, which is rational).

#### Page 2: Decimals: Terminating vs Repeating
- **Page ID:** `page_2_terminating_repeating`
- **Page Objective:** Connect fraction forms to their decimal expansions.
- **Main Lesson Text:** When you turn a rational fraction into a decimal by dividing the top by the bottom, one of two things will happen. 1. The division stops perfectly. Example: 1/4 = 0.25. This is a **Terminating Decimal**. 2. The division never stops, but a pattern of numbers loops forever. Example: 1/3 = 0.3333... This is a **Non-Terminating Recurring (Repeating) Decimal**.
- **Intuition-First Explanation:** If a fraction is well-behaved, its decimal will either come to a clean stop or fall into a predictable, repeating rhythm.
- **Formal Definition / Result:** The decimal expansion of a rational number is either terminating or non-terminating recurring. Conversely, a number whose decimal expansion is terminating or non-terminating recurring is rational.
- **Worked Examples:** Example 1: 5/8 = 0.625 (Terminating, Rational).
Example 2: 2/11 = 0.181818... (Non-terminating recurring, Rational).
- **Kid Likely Doubt:** If 0.333... goes on forever, how is it an exact number? While we can't write the end of the decimal, the fraction 1/3 is perfectly exact. The 'infinity' is just a quirk of how base-10 math handles dividing by 3.
- **"If you are confused" Helper:** If it stops, or if it stutters, it's Rational.
- **Common Mistakes:** Believing that ANY decimal that goes on forever must be irrational. Recurring decimals are rational!
- **Mini Recap:** Rational numbers create decimals that either terminate or repeat.
- **Parent Explanation Tip:** Give them a calculator. Have them type 1 ÷ 4 (stops) and then 1 ÷ 3 (repeats). This proves both come from simple fractions.
- **Suggested Resource Links:** [NCERT: Decimal Expansions] - Standard syllabus examples.
- **Suggested Visual Asset Notes:** A chart showing a fraction splitting into two paths: 'Stops (0.5)' and 'Loops (0.333...)'. Both paths rejoin at the word 'RATIONAL'.
- **Linked Questions / Quick Check:** Sample Quick Check: Is 0.142857142857... rational? (Yes, it repeats the block 142857).

#### Page 3: What Makes a Number Irrational?
- **Page ID:** `page_3_irrational`
- **Page Objective:** Understand the definition of irrational numbers and their chaotic decimal expansions.
- **Main Lesson Text:** Are there numbers that absolutely refuse to be written as a fraction? Yes! These are the **Irrational Numbers**. No matter how hard you try, you cannot find two integers p and q that divide to equal them. The most famous examples are the square roots of non-perfect squares (like √2, √3, √5) and the number π (Pi).
- **Intuition-First Explanation:** An irrational number is like a messy ball of yarn that never loops the exact same way twice. It is mathematically unpredictable.
- **Formal Definition / Result:** A number 's' is called irrational if it cannot be written in the form p/q, where p and q are integers and q ≠ 0. Its decimal expansion is non-terminating and non-recurring.
- **Worked Examples:** Example 1: √2 = 1.41421356... (The digits never stop and never form a repeating block).
Example 2: π = 3.14159265... (No repeating pattern).
- **Kid Likely Doubt:** But my teacher says π is 22/7! No, 22/7 is just a fraction that is VERY CLOSE to π. We use it to make math easier. Real π is irrational.
- **"If you are confused" Helper:** Irrational = Irregular. It never stops, and it never repeats a pattern.
- **Common Mistakes:** Thinking that all square roots are irrational. √9 is just 3, which is an integer. Always check if the number is a perfect square first!
- **Mini Recap:** Irrational numbers cannot be written as p/q. Their decimals are non-terminating AND non-recurring.
- **Parent Explanation Tip:** Show them that if you type √2 into a calculator, it gives a string of random numbers. Ask them to try to find a repeating pattern. When they can't, explain that's what makes it irrational.
- **Suggested Resource Links:** [BYJU'S: Irrational Numbers Explained] - Good visual examples of non-perfect squares.
- **Suggested Visual Asset Notes:** A side-by-side comparison: A neat brick wall (Rational) vs a chaotic, randomly splattered paint canvas (Irrational).
- **Linked Questions / Quick Check:** Sample Quick Check: Is √25 irrational? (No, √25 = 5, which is rational).

#### Page 4: How Do I Identify Them Quickly?
- **Page ID:** `page_4_identification`
- **Page Objective:** Build a mental checklist for identifying numbers as rational or irrational under exam pressure.
- **Main Lesson Text:** In exams, you will be given a list of numbers and asked to sort them. Here is your ultimate checklist:
Step 1: Is it a fraction of integers? (Like 5/7). Yes -> Rational.
Step 2: Is it a decimal? Does it stop (0.45) or repeat (0.777...)? Yes -> Rational. 
Step 3: Does the decimal look totally random and never-ending (0.1010010001...)? Yes -> Irrational.
Step 4: Is it a square root? If it's a perfect square (√16), simplify it to 4 -> Rational. If it's not a perfect square (√7) -> Irrational.
- **Intuition-First Explanation:** Don't guess! Run every number through the 'filter machine'. The machine simplifies roots first, then checks for fractions, then checks decimal patterns.
- **Formal Definition / Result:** The union of the set of rational numbers and the set of irrational numbers forms the set of real numbers.
- **Worked Examples:** Example: Sort √36, 0.123123..., and √10. 
√36 = 6 (Rational).
0.123123... repeats (Rational).
√10 is not a perfect square (Irrational).
- **Kid Likely Doubt:** What about 0.1010010001... ? It looks like a pattern! Yes, it's a growing pattern, but it's not a REPEATING block of the exact same digits. So it is Irrational.
- **"If you are confused" Helper:** Always simplify first! Never judge a square root by its cover.
- **Common Mistakes:** Failing to simplify fractions or roots before deciding. E.g., thinking √4 / √9 is irrational when it's actually 2/3.
- **Mini Recap:** Simplify roots, check fraction forms, and analyze decimal patterns.
- **Parent Explanation Tip:** Write five mixed numbers on a whiteboard and walk through the 4-step checklist together out loud.
- **Suggested Resource Links:** [NCERT Exemplar Questions] - Good practice for these identification drills.
- **Suggested Visual Asset Notes:** A flowchart/decision tree. 'Is it a root?' -> 'Can you simplify it?' etc.
- **Linked Questions / Quick Check:** Sample Quick Check: Is 3.14159 (without dots) rational? (Yes, it terminates).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Rationality Checklist
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of the tests for rationality.
- **Compact Summary:** 1. p/q form (q≠0) = Rational
2. Terminating Decimal = Rational
3. Repeating Decimal = Rational
4. Perfect Square Roots (√4, √25) = Rational
5. Non-Repeating, Non-Terminating = Irrational
6. Non-Perfect Roots (√2, √3) = Irrational
7. π = Irrational.
- **Trouble-Spot Reminder:** Be careful with numbers like 22/7 and 3.14. These are RATIONAL approximations of π. But the symbol π itself is IRRATIONAL.
- **Exam-Useful Points:** Expect true/false questions asking if 'Every real number is an irrational number.' (False, it could be rational).
- **Remediation Notes:** If you are stuck on a root, try to find a number that multiplies by itself to make the inside number. If you can't, it's irrational.
- **One-Page Recap Style:** T-Chart comparing Rational and Irrational traits.
- **Parent Support Note:** Do a rapid-fire drill: '√100?' (Rational). '0.333...?' (Rational). 'π?' (Irrational).
- **Linked Revision Questions:** Revision Quick Check: Is 0 a rational number? (Yes, 0/1).
- **Linked Exam Drill Refs:** Exam Drill Ref: Classification Matrix 2.1

#### Revision Page 2: Bridge: Understanding Repeating Decimals
- **Page ID:** `page_rev_2`
- **Revision Goal:** Remediation for students confused by infinite repeating decimals being rational.
- **Compact Summary:** Remember the trick: Let x = 0.999...
Multiply by 10: 10x = 9.999...
Subtract the first from the second: 10x - x = 9.999... - 0.999...
9x = 9
x = 1. 
This proves that infinite repeating decimals can be translated perfectly back into fractions (or integers)!
- **Trouble-Spot Reminder:** Students feel uncomfortable with infinity. They think an infinite decimal can't equal a solid fraction.
- **Exam-Useful Points:** Converting repeating decimals to p/q form is a guaranteed 2 or 3-mark question.
- **Remediation Notes:** Practice multiplying by 10 (if 1 digit repeats) or 100 (if 2 digits repeat) to shift the decimal point.
- **One-Page Recap Style:** Step-by-step algebraic proof box.
- **Parent Support Note:** Walk through the x = 0.333... proof with them step by step on a piece of paper.
- **Linked Revision Questions:** Revision Quick Check: If you have 0.454545..., what do you multiply 'x' by? (By 100, since two digits repeat).
- **Linked Exam Drill Refs:** Exam Drill Ref: p/q Conversion Drill 2.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To show how rational and irrational numbers are mutually exclusive.
  - **What Should Appear:** A large box titled 'Real Numbers'. Inside, two completely separate, non-touching circles: 'Rational' and 'Irrational'.
  - **Labels Required:** Rational (Fractions, Repeating Decimals), Irrational (Roots of primes, π).
  - **Misconception to Fix:** Fixes the idea that a number can be both.
  - **Location:** Asset 1, Page 1

- **Teaching Purpose:** A quick visual tool for exams.
  - **What Should Appear:** Rationality Decision Tree.
  - **Labels Required:** Does it have a root? Does it have a decimal? Does it repeat?
  - **Misconception to Fix:** Fixes guessing. Replaces it with an algorithmic check.
  - **Location:** Asset 2, Page 1

---

### D. Resource Links

- **Link:** [NCERT Official Textbook Class 9 Math Chapter 1]
  - **Why it is useful:** Provides the official syllabus definitions.
  - **Best for:** basics

- **Link:** [Khan Academy: Converting Repeating Decimals to Fractions]
  - **Why it is useful:** Provides excellent step-by-step video tutorials for the hardest part of this subtopic.
  - **Best for:** remediation

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Rational numbers are neat fractions (terminating or repeating decimals). Irrational numbers are messy, unpredictable decimals (like non-perfect square roots and π).
- **Parent Helper Note per difficult subtopic:** When your child gets stuck on an exam question, tell them to simplify the number first. Solve the root, or look closely at the decimal dots.
- **Concept Rescue Note:** Don't fear the dots (...)! If the numbers before the dots repeat a pattern, write it as a fraction. It's rational.
