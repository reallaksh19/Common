# Physics Class 10 — Image Formation in a Plane Mirror
**Topic ID:** `topic_14_physics_10`
**Concept Tags:** `virtual-image`, `plane-mirror`, `lateral-inversion`, `ray-diagrams`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is a Virtual Image?
- **Page ID:** `page_1_virtual_image`
- **Page Objective:** Understand how the brain creates an image behind a solid mirror.
- **Main Lesson Text:** When you look in a mirror, it looks like there is a perfect clone of your room hiding *behind* the glass. But if you walk behind the mirror, there's just a blank wall! How does the image get there? The mirror reflects light from your face into your eyes. Your brain assumes that light ALWAYS travels in perfectly straight lines. So, your brain takes those bouncing light rays and traces them straight backward, *through* the mirror, to a point where they seem to originate. That point is where you 'see' your reflection. Because the light rays don't actually exist behind the mirror, we call this a **Virtual Image**.
- **Intuition-First Explanation:** Your brain is being tricked by the bounce. It thinks the light came from deep inside the wall.
- **Formal Definition / Result:** A virtual image is formed when light rays diverge after reflection, and appear to meet when extended backwards. It cannot be obtained on a screen.
- **Worked Examples:** Example: Looking at yourself in a bathroom mirror produces a virtual image. You cannot project that image onto a piece of paper.
- **Kid Likely Doubt:** If the image isn't real, how can I take a picture of it with my phone? Because the light bouncing off the mirror goes into your phone's camera lens exactly the same way it goes into your eye! The camera lens focuses the light to form a real image inside the phone.
- **"If you are confused" Helper:** Virtual = Fake. The light isn't actually there.
- **Common Mistakes:** Thinking plane mirrors can form real images. Plane mirrors ONLY form virtual images.
- **Mini Recap:** Plane mirrors form virtual images because the brain traces bouncing light rays backward behind the glass.
- **Parent Explanation Tip:** Place an object in front of a mirror. Ask your child to reach behind the mirror and try to 'touch' the reflection. It reinforces that the image has no physical reality.
- **Suggested Resource Links:** [Khan Academy: Virtual Images] - Great video explaining how the brain traces rays.
- **Suggested Visual Asset Notes:** A ray diagram showing light bouncing off a mirror into an eye. Dotted lines trace the rays backward through the mirror to form a ghosted image.
- **Linked Questions / Quick Check:** Sample Quick Check: Can a virtual image be captured on a movie screen? (No).

#### Page 2: Size and Orientation: Same and Erect
- **Page ID:** `page_2_same_size_erect`
- **Page Objective:** Identify two core properties of images in plane mirrors.
- **Main Lesson Text:** When you look in a standard flat mirror (a plane mirror), you don't look huge like a giant, or tiny like an ant. The image is exactly the **Same Size** as the object. Also, you don't look upside down! Your head is at the top, and your feet are at the bottom. In physics, we call an upright image an **Erect Image**. 
So far, we have three properties of a plane mirror image: Virtual, Erect, and Same Size.
- **Intuition-First Explanation:** A flat mirror doesn't squish or stretch the light. It bounces it perfectly, so the picture stays perfect.
- **Formal Definition / Result:** The image formed by a plane mirror is always erect and of the same size as the object.
- **Worked Examples:** Example: If a 15 cm pencil is placed in front of a plane mirror, the virtual image behind the mirror will also be exactly 15 cm long.
- **Kid Likely Doubt:** But what if I use a funhouse mirror? Funhouse mirrors are curved (concave or convex). They bend the light inwards or outwards, which changes the size. Only flat (plane) mirrors keep the size exactly the same.
- **"If you are confused" Helper:** Plane Mirror = Perfect Clone (Same size, right-side up).
- **Common Mistakes:** Mixing up 'erect' with 'real'. Erect just means right-side up.
- **Mini Recap:** Images in plane mirrors are always upright (erect) and identical in size.
- **Parent Explanation Tip:** Have them stand in front of a full-length mirror. Put a piece of tape on the glass at their eye level, and another at their waist. Have them step back. The tape marks still perfectly match their height on the glass!
- **Suggested Resource Links:** [NCERT Class 10 Science Chapter 10] - Read the summary of image properties.
- **Suggested Visual Asset Notes:** A side-by-side comparison of an apple and its reflection. Both have rulers next to them showing they are exactly 10cm tall.
- **Linked Questions / Quick Check:** Sample Quick Check: Is the image in a plane mirror inverted upside-down? (No, it is erect).

#### Page 3: The Mirror Flip: Lateral Inversion
- **Page ID:** `page_3_lateral_inversion`
- **Page Objective:** Understand why mirrors swap left and right, but not top and bottom.
- **Main Lesson Text:** If you raise your right hand in front of a mirror, your reflection raises its left hand! If you wear a shirt with words on it, the words are backwards. This left-to-right swapping is called **Lateral Inversion**. 
But wait, why does the mirror swap left and right, but not top and bottom? The secret is: The mirror isn't actually swapping left and right at all! It is swapping FRONT and BACK. 
Imagine holding a mask of your face. To look at the mask in the mirror, you have to turn it around to face the glass. That front-to-back turning is what causes the left-to-right flip in the reflection.
- **Intuition-First Explanation:** Imagine stamping an ink pad on a piece of paper. The stamped image is backwards! A mirror is just an optical stamp of the front of your body.
- **Formal Definition / Result:** The phenomenon due to which the right side of an object appears as the left side of the image in a plane mirror is called lateral inversion.
- **Worked Examples:** Example: The word 'RED' held to a mirror will look like 'ЯƎꓷ'.
- **Kid Likely Doubt:** Is there a mirror that doesn't flip things? Yes! A 'True Mirror' or 'Non-Reversing Mirror' uses two mirrors joined at a 90-degree angle. You look at the seam in the middle, and it flips the image back to normal!
- **"If you are confused" Helper:** Lateral = Sideways. Inversion = Flipped.
- **Common Mistakes:** Thinking the mirror actively decides to flip left and right. It just reflects exactly what is in front of it.
- **Mini Recap:** Plane mirrors cause lateral inversion, swapping the apparent left and right sides of the object.
- **Parent Explanation Tip:** Write the alphabet on a clear piece of plastic or tracing paper. Hold it in front of the mirror. It looks backwards. Now, turn the plastic around so you are looking at it from behind. It looks the same as the mirror! This proves it's a front-to-back flip.
- **Suggested Resource Links:** [BYJU'S: Lateral Inversion] - Good visual examples of the alphabet.
- **Suggested Visual Asset Notes:** An image of an Ambulance with the hood lettering written backwards, and a rearview mirror showing it corrected.
- **Linked Questions / Quick Check:** Sample Quick Check: What is the phenomenon of left-right reversal called? (Lateral Inversion).

#### Page 4: Drawing the Image Formation Diagram
- **Page ID:** `page_4_drawing_the_diagram`
- **Page Objective:** Learn how to physically draw the ray diagram that proves the image properties.
- **Main Lesson Text:** To prove all these properties, we must draw the Ray Diagram. 
1. Draw a mirror line (with slashes on the back). 
2. Draw an object (like an arrow 'AB') in front of the mirror. 
3. Take a point 'A' on the object. Draw two incident rays from 'A' hitting the mirror at different angles. 
4. Draw the Normals and the Reflected Rays (using ∠i = ∠r). 
5. The reflected rays spread apart (diverge). They will never meet! 
6. Extend those reflected rays BACKWARDS behind the mirror using dotted lines. 
7. Where those dotted lines cross is where the Virtual Image of point 'A' is formed! Repeat for point 'B'.
- **Intuition-First Explanation:** You are reverse-engineering what the brain does. The brain traces the bouncing rays straight back. Where they cross is where the brain paints the picture.
- **Formal Definition / Result:** To locate the virtual image in a plane mirror, at least two incident rays from a point on the object are required. Their corresponding reflected rays are produced backward to intersect at the image point.
- **Worked Examples:** Example: The dotted lines will cross exactly the same distance behind the mirror as the object is in front of it.
- **Kid Likely Doubt:** Why do I need TWO rays? One ray just gives you a line. Two rays crossing gives you a specific point in space. You need a point to draw the image!
- **"If you are confused" Helper:** Solid lines = Real Light. Dotted lines = Fake (Virtual) Light.
- **Common Mistakes:** Drawing the extended backward lines as solid lines. You MUST use dotted or dashed lines behind the mirror to show it is a virtual image. You will lose marks if they are solid.
- **Mini Recap:** Draw two rays, reflect them, and trace them backward with dotted lines until they cross to find the image.
- **Parent Explanation Tip:** This diagram is extremely hard for students to draw neatly. Provide them a ruler and ask them to draw it slowly. If the image doesn't end up perfectly straight, they measured an angle wrong.
- **Suggested Resource Links:** [YouTube: Image Formation by Plane Mirror] - Essential to watch someone draw this step-by-step.
- **Suggested Visual Asset Notes:** A step-by-step drawing showing the object, the two incident rays, the two reflected rays, and the dotted lines meeting behind the mirror.
- **Linked Questions / Quick Check:** Sample Quick Check: How many rays must you draw from a single point to locate its image? (At least two).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The Four Properties of Plane Mirror Images
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of the core properties for classification questions.
- **Compact Summary:** Memorize these four properties. An image formed by a plane mirror is ALWAYS:
1. **Virtual**: Cannot be caught on a screen (light rays don't actually meet).
2. **Erect**: Right-side up.
3. **Same Size**: Image size = Object size.
4. **Laterally Inverted**: Left becomes right, right becomes left.
- **Trouble-Spot Reminder:** Students sometimes mix up 'Virtual' and 'Erect'. Virtual refers to the light rays. Erect refers to the orientation (upside down or not).
- **Exam-Useful Points:** A classic 2-mark question: 'State four characteristics of the image formed by a plane mirror.' Write these exact four words.
- **Remediation Notes:** If you forget, just close your eyes and picture looking in your bathroom mirror. Are you upside down? No (Erect). Are you huge? No (Same Size). Is the light behind the wall? Yes (Virtual).
- **One-Page Recap Style:** Bulleted memorization list.
- **Parent Support Note:** Ask them to list the four properties. If they miss one, give them a hint based on the bathroom mirror.
- **Linked Revision Questions:** Revision Quick Check: Is the image in a plane mirror real or virtual? (Virtual).
- **Linked Exam Drill Refs:** Exam Drill Ref: Properties Listing 14.1

#### Revision Page 2: Diagram Checklist
- **Page ID:** `page_rev_2`
- **Revision Goal:** Ensure students don't lose silly marks on the drawing question.
- **Compact Summary:** **Plane Mirror Drawing Checklist:**
[ ] Did you draw the slashes on the back of the mirror?
[ ] Do your incident rays have arrowheads pointing AT the mirror?
[ ] Do your reflected rays have arrowheads pointing AWAY?
[ ] Did you draw the Normals (dotted) at the points of incidence?
[ ] Are the lines behind the mirror DOTTED/DASHED?
[ ] Does the image look exactly the same size as the object?
- **Trouble-Spot Reminder:** Drawing solid lines behind the mirror. This implies light actually went through the solid glass and into the wall, which is physically impossible and gets zero marks.
- **Exam-Useful Points:** Diagrams are graded on accuracy and notation. The arrowheads and dotted lines are just as important as the angles.
- **Remediation Notes:** Practice drawing the diagram once a day for three days leading up to the exam.
- **One-Page Recap Style:** Checkbox evaluation list.
- **Parent Support Note:** Act as the examiner. Take their practice diagram and grade it using the 6-point checklist.
- **Linked Revision Questions:** Revision Quick Check: Why must the lines behind the mirror be dotted? (To show they are virtual/imaginary rays).
- **Linked Exam Drill Refs:** Exam Drill Ref: Diagram Evaluation 14.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To clearly show the front-to-back swap that causes lateral inversion.
  - **What Should Appear:** An illustration of a person holding a transparent sheet with the letter 'F' on it in front of a mirror. Shows the view from the person's eyes, and the view in the mirror.
  - **Labels Required:** Object, Laterally Inverted Image.
  - **Misconception to Fix:** Fixes the idea that the mirror is 'flipping' the image left-to-right on purpose.
  - **Location:** Asset 1, Page 3

- **Teaching Purpose:** To serve as the master reference for the exam drawing.
  - **What Should Appear:** A textbook-perfect ray diagram of an extended object (an arrow) forming an image in a plane mirror.
  - **Labels Required:** Object AB, Virtual Image A'B', Real Light Rays (Solid), Virtual Light Rays (Dotted).
  - **Misconception to Fix:** Prevents students from forgetting the dotted lines or the arrowheads.
  - **Location:** Asset 1, Page 4

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the official syllabus diagram and property list.
  - **Best for:** basics

- **Link:** [Physics Classroom: Image Characteristics for Plane Mirrors]
  - **Why it is useful:** Excellent interactive animations showing the ray tracing process.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Plane mirrors create images that are Virtual (behind the glass), Erect (right-side up), the Same Size as the object, and Laterally Inverted (left-right flipped). We prove this by drawing ray diagrams where reflected rays are traced backward with dotted lines.
- **Parent Helper Note per difficult subtopic:** The word 'Virtual' is hard for kids. Remind them of 'Virtual Reality' goggles. It looks like you are inside a video game, but you aren't actually there. The mirror is the original Virtual Reality!
- **Concept Rescue Note:** Exam Rescue: If asked for image properties, just think V-E-S-L. Virtual, Erect, Same Size, Lateral Inversion.
