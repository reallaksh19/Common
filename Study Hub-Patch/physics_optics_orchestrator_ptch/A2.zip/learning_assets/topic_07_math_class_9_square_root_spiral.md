# Mathematics Class 9 — Square Root Spiral
**Topic ID:** `topic_07_mathematics_9`
**Concept Tags:** `square-root-spiral`, `geometry-construction`, `pythagoras`, `irrational-numbers`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is the Square Root Spiral?
- **Page ID:** `page_1_what_is_spiral`
- **Page Objective:** Understand the geometric concept of the Spiral of Theodorus and its connection to square roots.
- **Main Lesson Text:** The Square Root Spiral (also known as the Spiral of Theodorus) is a beautiful geometric drawing that creates a continuous spiral out of right-angled triangles. It visually maps out the sequence of square roots of natural numbers: √1, √2, √3, √4, √5, and so on, in a perfect, expanding seashell-like pattern. It is proof that irrational numbers are not random; they follow strict geometric rules.
- **Intuition-First Explanation:** Imagine building a spiral staircase. But instead of the stairs going UP, they spin outwards in a circle on a flat piece of paper. Each new 'step' is the next square root.
- **Formal Definition / Result:** The Spiral of Theodorus is composed of contiguous right triangles. The first triangle has legs of length 1. For each subsequent triangle, the hypotenuse of the previous triangle serves as one leg, and the other leg has a length of 1.
- **Worked Examples:** Triangle 1 hypotenuse = √2. Triangle 2 hypotenuse = √3. Triangle 3 hypotenuse = √4 (which is 2).
- **Kid Likely Doubt:** Is the spiral infinite? In theory, yes! You can keep adding triangles forever, and the spiral will just keep overlapping itself, growing larger and larger.
- **"If you are confused" Helper:** Every new triangle uses the 'roof' of the old triangle as its floor.
- **Common Mistakes:** Thinking the height of the triangles gets bigger. The height is ALWAYS exactly 1 unit.
- **Mini Recap:** The spiral is a chain of right triangles where each hypotenuse represents the next square root.
- **Parent Explanation Tip:** Show them a picture of a Nautilus shell. Explain that nature uses math spirals just like this to grow optimally.
- **Suggested Resource Links:** [Khan Academy: Spiral of Theodorus] - A great visual intro.
- **Suggested Visual Asset Notes:** An image of a Nautilus shell next to a mathematical drawing of the Square Root Spiral to show the real-world connection.
- **Linked Questions / Quick Check:** Sample Quick Check: What is the height of every single triangle in the spiral? (1 unit).

#### Page 2: Building the Spiral: Step 1 (√2)
- **Page ID:** `page_2_construction_step_1`
- **Page Objective:** Master the initial construction step that anchors the entire spiral.
- **Main Lesson Text:** Let's build the spiral! 
Step 1: On a blank piece of paper, mark a center point 'O'. 
Step 2: Draw a horizontal line segment starting from O, exactly 1 unit long. Let's call the end point A (so OA = 1 unit). 
Step 3: At point A, use your protractor to draw a line straight up (perpendicular, exactly 90 degrees) that is also exactly 1 unit long. Let's call the top point B (so AB = 1 unit). 
Step 4: Connect O to B. You have made a right-angled triangle! By Pythagoras, the hypotenuse OB is √2.
- **Intuition-First Explanation:** This is the 'seed' of the spiral. If you plant the seed wrong, the whole tree will grow crooked.
- **Formal Definition / Result:** Draw OA = 1. Construct AB ⊥ OA such that AB = 1. Join OB. By Pythagoras, OB = √(1²+1²) = √2.
- **Worked Examples:** Example: If you choose 1 unit = 2 cm to make the drawing bigger, then OA is 2 cm, and AB is 2 cm.
- **Kid Likely Doubt:** Can I use any length for '1 unit'? Yes! You can say 1 inch = 1 unit, or 3 cm = 1 unit. As long as you use that EXACT SAME length for every '1' in the drawing, the math works perfectly.
- **"If you are confused" Helper:** Base 1, Height 1, Angle 90. Connect the dots.
- **Common Mistakes:** Using a ruler to draw the 90-degree angle instead of a protractor or compass. If the angle isn't perfect, the spiral is ruined.
- **Mini Recap:** The first triangle has a base of 1 and a height of 1, creating a hypotenuse of √2.
- **Parent Explanation Tip:** Watch them draw the very first 90-degree angle. If they 'eyeball' it, stop them and hand them a protractor.
- **Suggested Resource Links:** [BYJU'S: Construction of Square Root Spiral] - Good written steps.
- **Suggested Visual Asset Notes:** A simple 1x1 right-angled triangle with the hypotenuse labeled √2.
- **Linked Questions / Quick Check:** Sample Quick Check: What angle must be between the base OA and the height AB? (90 degrees).

#### Page 3: Building the Spiral: Step 2 (√3)
- **Page ID:** `page_3_construction_step_2`
- **Page Objective:** Learn how to use the previous hypotenuse as the base for the next triangle.
- **Main Lesson Text:** Now we grow the spiral. 
Step 1: Look at the slanted line you just drew (OB, which is √2). This line is the BASE of your new triangle. 
Step 2: Put your protractor on line OB. Draw a new line straight out from point B at a perfect 90-degree angle to OB. Make this new line exactly 1 unit long. Call the end point C (so BC = 1 unit). 
Step 3: Connect O to C. 
Why is OC exactly √3? By Pythagoras: Base² + Height² = Hypotenuse². 
(√2)² + (1)² = 2 + 1 = 3. So the new hypotenuse is √3!
- **Intuition-First Explanation:** You turn your paper slightly, treat the slanted roof as the new flat floor, and build another 1-unit high wall.
- **Formal Definition / Result:** Construct BC ⊥ OB such that BC = 1. Join OC. OC = √((√2)² + 1²) = √3.
- **Worked Examples:** Example: Your first line was horizontal. This new 1-unit line (BC) will be tilted diagonally.
- **Kid Likely Doubt:** Why does the new line have to be 1 unit long? Why not 2? Because we want the square roots in order (√2, √3, √4). If you made it 2 units long, the hypotenuse would jump to √6! (2+4=6).
- **"If you are confused" Helper:** The height is ALWAYS 1. The base is ALWAYS the previous hypotenuse.
- **Common Mistakes:** Drawing the new 1-unit line perfectly vertical relative to the bottom of the paper, instead of 90 degrees relative to the slanted line OB.
- **Mini Recap:** Use the √2 hypotenuse as a base, add a 1-unit perpendicular, and connect to the center to get √3.
- **Parent Explanation Tip:** Physically rotate the paper for your child so the line OB is horizontal to their eyes. It makes drawing the 90-degree angle much easier.
- **Suggested Resource Links:** [NCERT Class 9 Textbook Chapter 1] - See the spiral diagram.
- **Suggested Visual Asset Notes:** A diagram showing the second triangle built on top of the first. A dotted line shows the 90-degree angle between OB and BC.
- **Linked Questions / Quick Check:** Sample Quick Check: To get a hypotenuse of √3, what must your base and height be? (Base √2, Height 1).

#### Page 4: Continuing the Pattern
- **Page ID:** `page_4_continuing_the_pattern`
- **Page Objective:** Understand how to extend the spiral infinitely and what it represents.
- **Main Lesson Text:** To continue the spiral to √4, √5, √6, you just repeat the exact same process! 
Take the new hypotenuse (OC = √3). Draw a 90-degree line from point C that is 1 unit long. Call it D. Connect O to D. The new line OD is √4 (which is exactly 2 units long!). 
As you do this, the triangles fan out in a circle around the center point O. 
If you draw up to √17, the spiral will make one complete 360-degree rotation and start overlapping the very first triangle you drew!
- **Intuition-First Explanation:** It's a loop of instructions: New 90-degree angle -> Draw 1 unit -> Connect to center -> Repeat.
- **Formal Definition / Result:** For the n-th triangle, the base is √(n), the perpendicular is 1, and the resulting hypotenuse is √(n+1).
- **Worked Examples:** Example: Triangle 4 uses √4 as a base and 1 as height to create √5.
- **Kid Likely Doubt:** When do I stop? Usually, teachers will ask you to draw it up to √5 or √6 in an exam. Drawing it to √17 takes a long time!
- **"If you are confused" Helper:** Center point O is the anchor. ALL triangles connect back to O.
- **Common Mistakes:** Letting the '1 unit' measurement drift. By the 5th triangle, students get sloppy and draw it 1.2 units long. This distorts the whole spiral.
- **Mini Recap:** Repeat the process: use the last hypotenuse as the base, draw a 1-unit perpendicular, connect to the center.
- **Parent Explanation Tip:** Check their work! Use a ruler to measure the outer edge of every triangle. If they aren't all exactly identical in length (the 1 unit), the drawing is wrong.
- **Suggested Resource Links:** [YouTube: How to draw Square Root Spiral] - Crucial to watch this being done by hand.
- **Suggested Visual Asset Notes:** A fully completed square root spiral up to √7, with each hypotenuse labeled.
- **Linked Questions / Quick Check:** Sample Quick Check: Will the spiral ever close completely into a perfect circle? (No, it spirals outwards infinitely).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Spiral Construction Cheat Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of the drawing steps for exams.
- **Compact Summary:** Step 1: Horizontal base OA = 1 unit.
Step 2: Perpendicular AB = 1 unit. Join OB (Hypotenuse = √2).
Step 3: New perpendicular BC = 1 unit on OB. Join OC (Hypotenuse = √3).
Step 4: New perpendicular CD = 1 unit on OC. Join OD (Hypotenuse = √4).
Step 5: Repeat until desired root is reached.
*CRITICAL: Every new line on the outside edge must be EXACTLY 90 degrees to the slanted line, and EXACTLY 1 unit long.*
- **Trouble-Spot Reminder:** Students lose marks because their drawing gets sloppy. Use a sharp pencil. Use a real protractor for EVERY 90-degree angle. Do not guess.
- **Exam-Useful Points:** This is usually a 3 to 5 mark practical geometry question. Neatness and clear labeling (√2, √3, √4) are graded.
- **Remediation Notes:** If your spiral starts looking squished or flat, you messed up a 90-degree angle. Erase and redo the last step.
- **One-Page Recap Style:** 5-step numbered checklist with a warning box.
- **Parent Support Note:** If they have to do this for homework, advise them to use 1 inch (or 2 cm) as their '1 unit' so the drawing is big enough to be neat.
- **Linked Revision Questions:** Revision Quick Check: What is the length of the outer edge of the 10th triangle in the spiral? (1 unit).
- **Linked Exam Drill Refs:** Exam Drill Ref: Geometry Drawing Practice 7.1

#### Revision Page 2: The Math Behind the Spiral
- **Page ID:** `page_rev_2`
- **Revision Goal:** Ensure students understand the algebraic proof of why the spiral works, not just how to draw it.
- **Compact Summary:** The spiral works because of a cascading Pythagoras theorem:
Triangle 1: (1)² + (1)² = 2  ->  Hypotenuse = √2
Triangle 2: (√2)² + (1)² = 2 + 1 = 3  ->  Hypotenuse = √3
Triangle 3: (√3)² + (1)² = 3 + 1 = 4  ->  Hypotenuse = √4
Triangle n: (√n)² + (1)² = n + 1  ->  Hypotenuse = √(n+1)
Because the height is always 1, the squared sum always increases by exactly 1.
- **Trouble-Spot Reminder:** Students can draw it but can't explain WHY it works if asked in a 'reasoning' question.
- **Exam-Useful Points:** An examiner might ask you to prove algebraically why the 4th triangle's hypotenuse is √5.
- **Remediation Notes:** Write out the Pythagoras equation for any triangle they ask about. It proves you understand the concept.
- **One-Page Recap Style:** Cascading equation block.
- **Parent Support Note:** Ask them: 'Why does adding a height of 1 make the square root go up by exactly one number?' (Because 1 squared is 1!).
- **Linked Revision Questions:** Revision Quick Check: If a triangle in the spiral has a base of √10, what is its hypotenuse? (√11).
- **Linked Exam Drill Refs:** Exam Drill Ref: Pythagoras Reasoning Drill 7.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To show the correct physical orientation for drawing the 90-degree angles.
  - **What Should Appear:** A close-up diagram of a protractor resting on the slanted hypotenuse OB, showing how to measure 90 degrees for line BC.
  - **Labels Required:** Protractor base line aligned with OB, 90° mark, new line BC.
  - **Misconception to Fix:** Prevents the fatal error of drawing the new line vertically relative to the paper instead of perpendicular to the hypotenuse.
  - **Location:** Asset 1, Page 3

- **Teaching Purpose:** A quick visual reference of the completed task.
  - **What Should Appear:** A clean, mathematically perfect square root spiral up to √6.
  - **Labels Required:** O (Center), 1 unit labels on all outer edges, √2, √3, √4, √5, √6 on the hypotenuses.
  - **Misconception to Fix:** Shows what the final product *should* look like so they can self-correct.
  - **Location:** Asset 2, Page 1

---

### D. Resource Links

- **Link:** [NCERT Class 9 Math Textbook Chapter 1]
  - **Why it is useful:** Official source for the construction steps.
  - **Best for:** basics

- **Link:** [Khan Academy: Spiral of Theodorus]
  - **Why it is useful:** Excellent digital drawing showing how the spiral forms.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** The Square Root spiral is a chain of right-angled triangles sharing a center point. By keeping the height of every triangle exactly 1 unit, the hypotenuses grow sequentially: √2, √3, √4... It proves irrational numbers follow geometric order.
- **Parent Helper Note per difficult subtopic:** This is a practical skill. You cannot help them by just talking about it; you have to watch them draw it. Ensure they rotate the paper for every new triangle so they draw the 90-degree angle accurately.
- **Concept Rescue Note:** Exam Rescue: If your spiral looks horribly wrong halfway through, do not erase the whole thing! Cross it out neatly and start fresh on a new page. A fresh start is faster than trying to fix a crooked spiral.
