# Physics Class 10 — Reflection of Light
**Topic ID:** `topic_09_physics_10`
**Concept Tags:** `reflection`, `ray-diagrams`, `the-normal`, `angle-of-incidence`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is Reflection?
- **Page ID:** `page_1_what_is_reflection`
- **Page Objective:** Understand the basic concept of light bouncing off surfaces.
- **Main Lesson Text:** Imagine throwing a tennis ball against a smooth brick wall. It bounces back! Light does exactly the same thing when it hits a surface. This bouncing back of light into the same medium it came from is called **Reflection**. Because light travels in straight lines (rectilinear propagation), it bounces in a very predictable way. Without reflection, you wouldn't be able to see anything in the room right now except the lightbulb itself!
- **Intuition-First Explanation:** Everything you see that doesn't glow on its own is acting like a mirror, bouncing the room's light into your eyes.
- **Formal Definition / Result:** Reflection is the phenomenon where a light ray, upon striking a surface, bounces back into the same optical medium.
- **Worked Examples:** Example 1: Sunlight bouncing off a lake, allowing you to see the mountains mirrored in the water. 
Example 2: A laser pointer bouncing off a bathroom mirror.
- **Kid Likely Doubt:** Do all objects reflect light? Yes, almost all of them! A white wall reflects almost all the light that hits it. A black shirt absorbs most of the light, but still reflects a little bit. Only perfectly black holes absorb EVERYTHING.
- **"If you are confused" Helper:** Reflection = Bouncing Back.
- **Common Mistakes:** Thinking only mirrors reflect light. If you can see an object, it is reflecting light into your eyes.
- **Mini Recap:** Reflection is the bouncing of light rays off a surface back into the same space.
- **Parent Explanation Tip:** Turn off the lights. Turn on a single flashlight and point it at the wall. Ask them how they can see the rest of the room. (The wall is reflecting the light!)
- **Suggested Resource Links:** [Khan Academy: Reflection of Light] - Great introductory video.
- **Suggested Visual Asset Notes:** A simple diagram of a tennis ball bouncing off a wall next to a light ray bouncing off a mirror to build the physical analogy.
- **Linked Questions / Quick Check:** Sample Quick Check: Why can you see the pages of this book? (Because they reflect light into your eyes).

#### Page 2: Introduction to Ray Diagrams
- **Page ID:** `page_2_ray_diagram_basics`
- **Page Objective:** Learn how physicists draw and trace light.
- **Main Lesson Text:** We can't easily photograph single beams of light bouncing around. So, physicists draw **Ray Diagrams** to map exactly what the light is doing. A Ray Diagram uses straight lines to represent the path of light. The most important rule of a ray diagram is the arrow! A straight line without an arrowhead is just geometry. A straight line WITH an arrowhead tells us which direction the light is travelling.
- **Intuition-First Explanation:** A ray diagram is just a treasure map showing exactly where the light traveled from start to finish.
- **Formal Definition / Result:** A ray diagram is a schematic representation of the path of light rays using directed line segments.
- **Worked Examples:** Example: Drawing a straight line from a lightbulb to an eye, with an arrow pointing toward the eye.
- **Kid Likely Doubt:** How many rays do I have to draw? A real lightbulb shoots out trillions of rays. But in physics, we usually only draw 1 or 2 rays to figure out exactly how an image is formed. We just pick the most useful ones!
- **"If you are confused" Helper:** No Arrow = No Light. Always draw the arrowhead.
- **Common Mistakes:** Drawing perfectly straight lines in an exam but forgetting to put the little arrowheads on them. Teachers will deduct marks for this!
- **Mini Recap:** Ray diagrams use arrows to trace the exact path light takes.
- **Parent Explanation Tip:** Check their homework. If they draw lines without arrows, hand it back and say 'I don't know which way the light is going!'
- **Suggested Resource Links:** [BYJU'S: Ray Diagrams] - Good examples of drawing conventions.
- **Suggested Visual Asset Notes:** A picture of a line with no arrow (marked 'WRONG') next to a line with an arrow (marked 'RIGHT').
- **Linked Questions / Quick Check:** Sample Quick Check: What must every light ray in a diagram have? (An arrowhead indicating direction).

#### Page 3: Naming the Parts of Reflection
- **Page ID:** `page_3_naming_the_parts`
- **Page Objective:** Learn the specific vocabulary used in reflection diagrams.
- **Main Lesson Text:** To talk about reflection, we need to name the parts of the bounce. 
1. **Incident Ray**: The incoming light ray traveling TOWARD the mirror. 
2. **Reflected Ray**: The outgoing light ray bouncing AWAY from the mirror. 
3. **Point of Incidence**: The exact spot on the mirror where the incident ray hits. 
When drawing the mirror itself, we usually draw a straight line with little diagonal dashes on one side. The dashes represent the 'back' (the painted, non-reflective side) of the mirror. The smooth side is the front.
- **Intuition-First Explanation:** Incident means 'arriving' or 'happening'. Reflected means 'bouncing away'.
- **Formal Definition / Result:** The ray of light striking the surface is the incident ray. The ray bouncing off is the reflected ray. The point of contact is the point of incidence.
- **Worked Examples:** Example: If you point a laser at a mirror, the beam traveling from your hand to the mirror is the Incident Ray. The beam hitting the wall is the Reflected Ray.
- **Kid Likely Doubt:** Why do we draw those weird slashes on the back of the mirror? Because on a piece of paper, a mirror just looks like a normal line! The slashes tell you which side is shiny.
- **"If you are confused" Helper:** Incident = INcoming. Reflected = Running away.
- **Common Mistakes:** Mixing up incident and reflected rays. Always look at the arrowhead! Arrow pointing AT the mirror = Incident.
- **Mini Recap:** Incident ray goes in, hits the point of incidence, and the reflected ray goes out.
- **Parent Explanation Tip:** Draw a blank diagram with the rays but no labels. Ask them to point to the Incident Ray based purely on the arrow direction.
- **Suggested Resource Links:** [NCERT Class 10 Science Chapter 10] - Learn the standard diagram notation.
- **Suggested Visual Asset Notes:** A labelled diagram showing the mirror (with slashes on the back), the Incident Ray, the Reflected Ray, and the Point of Incidence.
- **Linked Questions / Quick Check:** Sample Quick Check: What do the diagonal dashes on the mirror diagram represent? (The non-reflective back side of the mirror).

#### Page 4: The Most Important Line: The Normal
- **Page ID:** `page_4_the_normal`
- **Page Objective:** Understand the concept and purpose of the 'Normal' line.
- **Main Lesson Text:** If we want to measure the angles of the bounce, we have a big problem. What if the mirror is curved? What if the mirror is tilted? We need a reliable way to measure the angles. Enter **The Normal**. 
The Normal is an IMAGINARY line that we draw standing perfectly straight up (90 degrees, perpendicular) from the mirror surface, exactly at the Point of Incidence. We draw it as a dotted line because it's not a real beam of light; it's just a measuring stick.
- **Intuition-First Explanation:** Think of the Normal like a flagpole stuck straight into the ground. No matter how the ground tilts, the flagpole is always exactly 90 degrees to the surface.
- **Formal Definition / Result:** The Normal is an imaginary line drawn perpendicular to the reflecting surface at the point of incidence.
- **Worked Examples:** Example: If a mirror is lying flat on the floor, the Normal points straight up to the ceiling.
- **Kid Likely Doubt:** Is the Normal an actual laser beam? No! It is purely imaginary. We just draw it so we have a reference line to put our protractor on.
- **"If you are confused" Helper:** Normal = 90 degrees to the surface.
- **Common Mistakes:** Drawing the Normal at a random angle instead of exactly 90 degrees to the mirror surface.
- **Mini Recap:** The Normal is an imaginary 90-degree reference line drawn at the point of incidence.
- **Parent Explanation Tip:** Take a hand mirror and tape a pencil straight up from the center of it. Tilt the mirror around. Show them that the 'Normal' (the pencil) tilts with the mirror, always staying at 90 degrees.
- **Suggested Resource Links:** [Physics Classroom: Reflection] - Good text explanation of the Normal.
- **Suggested Visual Asset Notes:** A diagram showing a tilted mirror. The Normal is drawn as a dotted line exactly 90 degrees to the tilted surface, proving it tilts with the mirror.
- **Linked Questions / Quick Check:** Sample Quick Check: What angle does the Normal make with the surface of the mirror? (90 degrees).

#### Page 5: Measuring the Angles
- **Page ID:** `page_5_angles`
- **Page Objective:** Learn how to define and identify the Angle of Incidence and Angle of Reflection.
- **Main Lesson Text:** Now that we have our Normal line, we can measure the bounce! 
The **Angle of Incidence (∠i)** is the angle between the Incident Ray and the NORMAL. 
The **Angle of Reflection (∠r)** is the angle between the Reflected Ray and the NORMAL. 
This is the bridge to the Laws of Reflection, which we will study next. The critical thing to remember is where we measure from.
- **Intuition-First Explanation:** We always measure the angle from the imaginary upright flagpole (the Normal), NEVER from the flat ground (the mirror).
- **Formal Definition / Result:** Angle of Incidence (∠i) is the angle subtended between the incident ray and the normal. Angle of Reflection (∠r) is the angle between the reflected ray and the normal.
- **Worked Examples:** Example: If the incident ray is 30 degrees away from the normal, then ∠i = 30°.
- **Kid Likely Doubt:** Why don't we just measure from the mirror surface? It seems easier! Because if the mirror is curved (like a spoon), measuring from the surface becomes mathematically impossible. The Normal line allows us to measure angles on curves!
- **"If you are confused" Helper:** Always measure from the dotted line (Normal), never the solid line (Mirror).
- **Common Mistakes:** This is the #1 mistake in Class 10 Physics: Measuring the angle between the Incident Ray and the MIRROR. If a question says 'a ray hits the mirror at a 20 degree angle to the surface', the Angle of Incidence is actually 90 - 20 = 70 degrees!
- **Mini Recap:** Angles of incidence and reflection are always measured relative to the Normal.
- **Parent Explanation Tip:** Draw an angle between the ray and the mirror. Ask them 'Is this the angle of incidence?' (No!). Have them physically draw the Normal and find the correct angle.
- **Suggested Resource Links:** [NCERT Exemplar Questions] - Good practice for angle traps.
- **Suggested Visual Asset Notes:** A diagram highlighting the Angle of Incidence (between ray and normal) in green, and the false angle (between ray and mirror) in red with a big X.
- **Linked Questions / Quick Check:** Sample Quick Check: If a ray makes an angle of 40° with the mirror surface, what is the angle of incidence? (50°).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Diagram Vocabulary Cheat Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of all ray diagram terminology.
- **Compact Summary:** 1. **Incident Ray**: Incoming light (arrow pointing IN).
2. **Reflected Ray**: Bouncing light (arrow pointing OUT).
3. **Point of Incidence**: Where light hits the surface.
4. **Normal**: Imaginary dotted line 90° to the surface.
5. **Angle of Incidence (∠i)**: Angle between Incident Ray and Normal.
6. **Angle of Reflection (∠r)**: Angle between Reflected Ray and Normal.
- **Trouble-Spot Reminder:** Forgetting the arrowheads. A diagram without arrowheads gets zero marks because it doesn't show which way the light is moving.
- **Exam-Useful Points:** Exams will ask you to 'Draw a labelled ray diagram'. You must include all 6 of these labels to get full marks.
- **Remediation Notes:** Draw the diagram from memory. Then check the book. Which label did you forget? It's usually the Normal.
- **One-Page Recap Style:** Bulleted checklist mapping to a diagram.
- **Parent Support Note:** Play 'What's missing?' Draw a diagram but leave out the arrows, or leave out the normal. Ask them to fix your drawing.
- **Linked Revision Questions:** Revision Quick Check: What does the dotted line in a ray diagram represent? (The Normal).
- **Linked Exam Drill Refs:** Exam Drill Ref: Diagram Labelling 9.1

#### Revision Page 2: The Angle Trap
- **Page ID:** `page_rev_2`
- **Revision Goal:** Prevent the most common angle measurement mistake in physics exams.
- **Compact Summary:** The Angle of Incidence is ALWAYS measured from the Normal. 
The Trap: The exam question says, 'A ray strikes a mirror at an angle of 30° to the surface of the mirror.' 
What students do: Write ∠i = 30°. (WRONG!). 
What you should do: Draw the Normal. The Normal is 90° to the mirror. So, 90° - 30° = 60°. 
The true Angle of Incidence is 60°!
- **Trouble-Spot Reminder:** Reading the question too fast and missing the words 'to the surface of the mirror'.
- **Exam-Useful Points:** This trap appears in almost every single board exam paper. Read the wording carefully.
- **Remediation Notes:** If the question says 'angle to the surface', immediately subtract that number from 90 to get your real angle.
- **One-Page Recap Style:** Warning box with a calculation rule.
- **Parent Support Note:** Give them rapid-fire traps. 'Angle to the surface is 10 degrees. What is the angle of incidence?' (80 degrees!).
- **Linked Revision Questions:** Revision Quick Check: If the angle between the incident ray and the mirror is 45°, what is ∠i? (45°).
- **Linked Exam Drill Refs:** Exam Drill Ref: Angle Traps 9.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To serve as the definitive reference for drawing ray diagrams.
  - **What Should Appear:** A complete, perfectly labelled ray diagram of reflection.
  - **Labels Required:** Incident Ray, Reflected Ray, Normal, Point of Incidence, Angle i, Angle r, Mirror Surface (with hashes).
  - **Misconception to Fix:** Provides a perfect template so students don't invent their own incorrect drawing styles.
  - **Location:** Asset 1, Page 3

- **Teaching Purpose:** To visually break down the 'Angle Trap'.
  - **What Should Appear:** A diagram showing the 90 degree angle between the normal and the mirror broken into two chunks. The bottom chunk (ray to mirror) is 30°. The top chunk (ray to normal) is labeled '90-30=60°'.
  - **Labels Required:** Mirror, Normal, Incident Ray, 30° (surface angle), 60° (Angle of Incidence).
  - **Misconception to Fix:** Visually proves why subtracting from 90 gives the correct angle.
  - **Location:** Asset 2, Page 2

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the official diagrams you are expected to replicate in the exam.
  - **Best for:** basics

- **Link:** [Khan Academy: Specular and Diffuse Reflection]
  - **Why it is useful:** Good video that emphasizes the importance of the Normal line.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Reflection is light bouncing off a surface. We trace it using Ray Diagrams with arrows. The most important part of the diagram is the Normal: an imaginary 90-degree line drawn at the point of incidence. We ALWAYS measure our angles from the Normal.
- **Parent Helper Note per difficult subtopic:** The word 'Normal' in math and physics doesn't mean 'ordinary'. It means 'perpendicular' or 'at 90 degrees'. Ensure your child understands this specific definition, as it appears in math (tangents and normals) as well.
- **Concept Rescue Note:** Exam Rescue: If a question asks you to draw a reflection diagram, start by drawing the mirror line, then immediately draw the dotted Normal line. Everything else is built around the Normal.
