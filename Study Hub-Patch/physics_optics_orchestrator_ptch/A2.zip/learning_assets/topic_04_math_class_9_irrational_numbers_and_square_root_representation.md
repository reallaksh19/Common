# Mathematics Class 9 — Irrational Numbers and Square Root Representation
**Topic ID:** `topic_04_mathematics_9`
**Concept Tags:** `irrational-numbers`, `square-roots`, `number-line`, `pythagoras`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What Are Irrational Numbers?
- **Page ID:** `page_1_irrational_recap`
- **Page Objective:** Solidify the definition of irrational numbers and why non-perfect square roots are irrational.
- **Main Lesson Text:** An irrational number cannot be written as a neat fraction (p/q). Its decimal goes on forever without repeating. The most common irrational numbers we deal with in geometry are square roots of non-perfect squares. For example, √4 is 2 (rational). But √2 is 1.41421356... (irrational). Because √2 isn't a perfect integer fraction, we can't measure it exactly with a standard ruler.
- **Intuition-First Explanation:** A rational number fits perfectly into a measuring cup. An irrational number always leaves a microscopic bit overflowing, no matter how precise your cup is.
- **Formal Definition / Result:** If 'n' is a positive integer which is not a perfect square, then √n is an irrational number.
- **Worked Examples:** Example 1: √9 = 3 (Rational).
Example 2: √5 = 2.236067... (Irrational, because 5 is not a perfect square).
- **Kid Likely Doubt:** If √2 goes on forever, does that mean it's infinitely big? No! It is a very specific, finite length (just a bit more than 1.4). It's the *decimal description* of it that goes on forever, not the size of the number itself.
- **"If you are confused" Helper:** Always try to solve the root first. If it doesn't give you a clean whole number, it's irrational.
- **Common Mistakes:** Assuming √16/25 is irrational because it's a fraction inside a root. √16/√25 = 4/5, which is highly rational!
- **Mini Recap:** Square roots of non-perfect squares are irrational.
- **Parent Explanation Tip:** Ask them to punch √2, √3, and √4 into a calculator. Let them physically see the difference between the chaotic decimals and the clean '2'.
- **Suggested Resource Links:** [Khan Academy: Intro to Irrational Numbers] - Good for visualizing the decimals.
- **Suggested Visual Asset Notes:** A list of square roots (√1, √2, √3, √4) with arrows pointing them to 'Rational' or 'Irrational' bins.
- **Linked Questions / Quick Check:** Sample Quick Check: Is √12 rational or irrational? (Irrational, 12 is not a perfect square).

#### Page 2: The Magic of Pythagoras
- **Page ID:** `page_2_pythagoras`
- **Page Objective:** Understand how the Pythagorean Theorem creates exact irrational lengths.
- **Main Lesson Text:** If √2 is an endless decimal, how can we possibly draw a line exactly √2 units long? We can't use a ruler. We must use Geometry! The Pythagorean Theorem states that for a right-angled triangle, the square of the hypotenuse (the longest side) equals the sum of the squares of the other two sides: a² + b² = c².
- **Intuition-First Explanation:** If algebra can't give us a clean number for √2, geometry can give us a clean shape for it.
- **Formal Definition / Result:** In a right-angled triangle with base 'a' and perpendicular 'b', the hypotenuse 'c' is given by c = √(a² + b²).
- **Worked Examples:** Example: If we draw a right-angled triangle with a base of 1 unit and a height of 1 unit. The hypotenuse c = √(1² + 1²) = √(1+1) = √2.
- **Kid Likely Doubt:** Wait, did we just draw an infinite number? We drew a line with an exact length. The line is finite and perfect. It's only our Base-10 decimal system that struggles to write its name!
- **"If you are confused" Helper:** Base² + Height² = Hypotenuse². Use this to build any square root.
- **Common Mistakes:** Forgetting to take the square root at the very end. c² = 2, so c = √2, NOT 2.
- **Mini Recap:** A right triangle with sides 1 and 1 creates a hypotenuse exactly √2 long.
- **Parent Explanation Tip:** Cut out a 1-inch by 1-inch square of paper. Cut it diagonally. Tell them that diagonal edge is exactly √2 inches long. They are holding an irrational number!
- **Suggested Resource Links:** [BYJU'S: Pythagorean Theorem] - Quick refresher on the formula.
- **Suggested Visual Asset Notes:** A simple right-angled triangle with Base = 1, Height = 1, and Hypotenuse = √2.
- **Linked Questions / Quick Check:** Sample Quick Check: If a right triangle has base 2 and height 1, what is the hypotenuse? (√5).

#### Page 3: Placing √2 on the Number Line
- **Page ID:** `page_3_root_2_number_line`
- **Page Objective:** Learn the step-by-step geometric construction to place √2 exactly on the number line.
- **Main Lesson Text:** Now that we know a 1x1 right triangle gives us a length of √2, let's put it on the number line! 
Step 1: Draw a number line and mark 0 and 1. 
Step 2: From the '1' mark, draw a line straight up (perpendicular) exactly 1 unit high. 
Step 3: Connect the top of that line back to 0. You just made your triangle! The slanted line (hypotenuse) is exactly √2 long.
Step 4: Put the sharp point of a compass on 0, and the pencil tip on the top of the triangle. Draw an arc down until it hits the number line. That exact spot is √2!
- **Intuition-First Explanation:** You are literally picking up the hypotenuse and dropping it flat onto the number line using the compass like a swinging door.
- **Formal Definition / Result:** Let OA = 1 unit on the number line. Draw AB ⊥ OA such that AB = 1 unit. Join OB. By Pythagoras, OB = √2. With O as center and OB as radius, draw an arc intersecting the number line at P. Point P represents √2.
- **Worked Examples:** Example: The arc will land just before the 1.5 mark, because √2 is approximately 1.414.
- **Kid Likely Doubt:** Why do we need a compass? Why not just measure the slanted line with a ruler and copy it? Because your ruler only has millimeter marks (which are rational fractions). You can't measure 1.41421356... accurately with your eyes! The compass transfers the perfect exact length.
- **"If you are confused" Helper:** 1 Right, 1 Up, Connect, Swing the arc down.
- **Common Mistakes:** Drawing the 'up' line (perpendicular) starting from 0 instead of starting from 1.
- **Mini Recap:** Build a 1x1 triangle starting at 0 to 1, then swing the hypotenuse down to the line.
- **Parent Explanation Tip:** Have them practice this construction 3 times on paper. It's a guaranteed exam question.
- **Suggested Resource Links:** [NCERT Class 9 Math] - Refer to the textbook construction steps.
- **Suggested Visual Asset Notes:** A 4-step comic-strip style diagram showing the number line, the triangle being built, and the compass swinging the arc down.
- **Linked Questions / Quick Check:** Sample Quick Check: At what point do you place the sharp needle of the compass? (At 0).

#### Page 4: Placing √3 on the Number Line
- **Page ID:** `page_4_root_3_number_line`
- **Page Objective:** Learn how to build upon √2 to represent √3.
- **Main Lesson Text:** How do we draw √3? We use Pythagoras again! If we want a hypotenuse of √3, we need our Base² + Height² to equal 3. 
If we use our old √2 line as the base, and a height of 1, we get: (√2)² + (1)² = 2 + 1 = 3. The hypotenuse will be √3! 
Step 1: Construct √2 as we did before. 
Step 2: At the top tip of the √2 triangle, draw a NEW perpendicular line exactly 1 unit long. 
Step 3: Connect the top of that new line back to 0. This new hypotenuse is exactly √3. 
Step 4: Use the compass to swing this new length down to the number line.
- **Intuition-First Explanation:** We are building a new triangle using the roof of the old triangle as the new floor.
- **Formal Definition / Result:** Construct OB = √2. Draw BC ⊥ OB such that BC = 1. Join OC. OC = √((√2)² + 1²) = √3. Swing an arc with radius OC to the number line.
- **Worked Examples:** Example: The arc for √3 will land around 1.732 on the number line.
- **Kid Likely Doubt:** Does the new '1 unit' line point straight UP relative to the paper? NO! It must be perpendicular (90 degrees) relative to the slanted √2 line, not the bottom edge of the paper.
- **"If you are confused" Helper:** To get √3, you must build √2 first. It's a two-step process.
- **Common Mistakes:** Drawing the new 1-unit line straight up (vertically) instead of at a 90-degree angle to the slanted hypotenuse.
- **Mini Recap:** Use the √2 line as the base, add a height of 1, and the new hypotenuse is √3.
- **Parent Explanation Tip:** Check their work with a protractor. Ensure the angle between the √2 line and the new '1 unit' line is exactly 90 degrees.
- **Suggested Resource Links:** [YouTube: Locating Root 3 on a Number Line] - Visual step-by-step.
- **Suggested Visual Asset Notes:** A diagram showing the second triangle built directly on top of the hypotenuse of the first triangle.
- **Linked Questions / Quick Check:** Sample Quick Check: To construct √3, what lengths do the base and perpendicular of your triangle need to be? (√2 and 1).

#### Page 5: Shortcuts: Placing √5 and Beyond
- **Page ID:** `page_5_shortcuts`
- **Page Objective:** Learn how to skip steps for larger square roots by choosing clever base lengths.
- **Main Lesson Text:** What if you need to draw √5? Do you have to draw √2, then √3, then √4, just to get to √5? No! You can use a shortcut. 
We need Base² + Height² to equal 5. 
Think of perfect squares: 4 + 1 = 5. 
So, what if our Base is 2, and our Height is 1? 
2² + 1² = 4 + 1 = 5. The hypotenuse is √5! 
Step 1: Draw a number line. Mark 0 to 2. 
Step 2: Draw a perpendicular line 1 unit high starting at the '2' mark. 
Step 3: Connect back to 0. The hypotenuse is √5. Swing it down with a compass.
- **Intuition-First Explanation:** Instead of building a staircase one step at a time, we just use a wider base to jump straight to the number we want.
- **Formal Definition / Result:** To locate √n, find positive integers 'a' and 'b' such that a² + b² = n. Draw a right triangle with base 'a' and perpendicular 'b'.
- **Worked Examples:** Example 1: Locate √10. We know 9 + 1 = 10. So use a base of 3 and height of 1. (3² + 1² = 10). 
Example 2: Locate √13. We know 9 + 4 = 13. So use a base of 3 and a height of 2.
- **Kid Likely Doubt:** Can I use a base of 1 and a height of 2? Yes! A tall skinny triangle works exactly the same as a long short triangle. Both have a hypotenuse of √5.
- **"If you are confused" Helper:** Look for perfect squares (1, 4, 9, 16) that add up to your target number.
- **Common Mistakes:** Forgetting to square the base. Some students use a base of 4 to get √5, thinking 4+1=5. But 4² + 1² = 17, giving √17! You must use a base of 2.
- **Mini Recap:** Use a base of 2 and height of 1 to jump straight to √5.
- **Parent Explanation Tip:** Play a game: Call out a number like 17, and have them shout back the base and height they would use (Base 4, Height 1).
- **Suggested Resource Links:** [NCERT Exemplar] - Great practice for shortcut constructions.
- **Suggested Visual Asset Notes:** A long, flat right triangle stretching from 0 to 2 on the number line, with a height of 1.
- **Linked Questions / Quick Check:** Sample Quick Check: What base and height would you use to construct √10 in one step? (Base 3, Height 1).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: Irrational Numbers Summary
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of why certain roots are irrational.
- **Compact Summary:** 1. If a number is a perfect square (1, 4, 9, 16, 25...), its square root is an integer (RATIONAL).
2. If a positive integer is NOT a perfect square (2, 3, 5, 6, 7, 8...), its square root is IRRATIONAL.
3. Irrational numbers cannot be written as p/q, and their decimals never terminate and never repeat.
- **Trouble-Spot Reminder:** Students see a root symbol and panic. Don't panic. Just ask: 'What number times itself equals the number inside?' If the answer isn't a clean integer, it's irrational.
- **Exam-Useful Points:** 1-mark MCQs will ask you to pick the irrational number from a list like [√16, √12, √36]. The answer is √12.
- **Remediation Notes:** Memorize the perfect squares up to 100 (1, 4, 9, 16, 25, 36, 49, 64, 81, 100) so you can instantly spot what is rational.
- **One-Page Recap Style:** Bulleted checklist and warning list.
- **Parent Support Note:** Quiz them on perfect squares. 'What is 7 squared?' (49). 'So is √49 rational?' (Yes).
- **Linked Revision Questions:** Revision Quick Check: Is √8 irrational? (Yes, 8 is not a perfect square).
- **Linked Exam Drill Refs:** Exam Drill Ref: Root Classification 4.1

#### Revision Page 2: Construction Cheat Sheet
- **Page ID:** `page_rev_2`
- **Revision Goal:** Step-by-step master guide for geometric constructions of roots.
- **Compact Summary:** To construct √n on the number line:
1. Find two numbers whose SQUARES add up to n (e.g., for √5, 2² + 1² = 5).
2. Draw a number line. Make the base equal to the first number (from 0 to 2).
3. At the end of the base, draw a 90° perpendicular line equal to the second number (height of 1).
4. Connect the top back to 0. This is your hypotenuse (√n).
5. Use a compass, needle on 0, pencil on the top tip, and swing an arc down to the line.
- **Trouble-Spot Reminder:** When constructing √3, you MUST construct √2 first. You cannot do √3 in one step because there are no two perfect integer squares that add up to 3.
- **Exam-Useful Points:** This is a guaranteed 3 or 4-mark drawing question. You must show the compass arc marks; do not erase them! They prove you didn't just measure it with a ruler.
- **Remediation Notes:** If your arc for √2 lands past 1.5, you measured your 1-unit height wrong. It should land slightly before 1.5.
- **One-Page Recap Style:** Numbered 5-step procedure list.
- **Parent Support Note:** Check their geometry box. Ensure their pencil is sharp and their compass hinge is tight so the pencil doesn't slip during the arc.
- **Linked Revision Questions:** Revision Quick Check: To draw √17, what base and height should you use? (Base 4, height 1).
- **Linked Exam Drill Refs:** Exam Drill Ref: Geometry Construction Practice 4.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To visually prove that a geometric shape can perfectly represent an infinite decimal.
  - **What Should Appear:** A right-angled triangle with Base=1, Height=1. The hypotenuse is labelled '√2 = 1.414...'
  - **Labels Required:** Base, Height, 90-degree angle symbol, Hypotenuse.
  - **Misconception to Fix:** Fixes the misconception that irrational numbers are 'fake' or 'impossible to measure'.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** A quick visual reference for the 'Shortcut' method.
  - **What Should Appear:** A table showing Target Root -> Base -> Height. (e.g., √5 -> 2 -> 1).
  - **Labels Required:** Target, Base, Perpendicular.
  - **Misconception to Fix:** Prevents students from wasting 10 minutes drawing a 5-step spiral in an exam when they just needed √5.
  - **Location:** Asset 2, Page 2

---

### D. Resource Links

- **Link:** [NCERT Class 9 Math Textbook Chapter 1]
  - **Why it is useful:** Provides the official step-by-step construction diagrams expected in the exam.
  - **Best for:** basics

- **Link:** [YouTube: How to locate Root 2, Root 3, Root 5 on a number line]
  - **Why it is useful:** Watching someone physically use a compass is vastly superior to reading text descriptions for geometry.
  - **Best for:** remediation

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Non-perfect square roots are irrational. We can't write their exact decimal, but we can draw their exact length using right-angled triangles (Pythagoras) and swing them onto the number line with a compass.
- **Parent Helper Note per difficult subtopic:** For the geometry part, emphasize that the '1 unit' can be anything—1 inch, 1 cm, or 3 cm—as long as it is consistent. If the base is 1 inch, the height MUST be exactly 1 inch.
- **Concept Rescue Note:** Exam Rescue: Always leave your compass arc marks on the paper! Teachers look for the arc to give you marks. If you just draw a dot where you think √2 is, you get zero.
