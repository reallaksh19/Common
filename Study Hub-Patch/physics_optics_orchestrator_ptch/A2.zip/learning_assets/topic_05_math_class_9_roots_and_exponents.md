# Mathematics Class 9 — Roots and Exponents
**Topic ID:** `topic_05_mathematics_9`
**Concept Tags:** `exponents`, `roots`, `fractional-powers`, `exponent-laws`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 9, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 9 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: What is an Exponent?
- **Page ID:** `page_1_meaning_exponents`
- **Page Objective:** Understand that exponents are a shorthand for repeated multiplication.
- **Main Lesson Text:** Math is all about finding lazy, efficient ways to write things. Addition is repeated counting. Multiplication is repeated addition (5+5+5 is 5*3). Exponents are repeated multiplication! Instead of writing 2 * 2 * 2 * 2 * 2, we write 2⁵. The big number (2) is the **Base**, and the small number (5) is the **Exponent** (or power). It tells you how many times to multiply the base by itself.
- **Intuition-First Explanation:** Exponents represent aggressive growth. If a bacteria doubles every hour, it grows as 2, then 4, then 8, then 16... that is 2¹, 2², 2³, 2⁴.
- **Formal Definition / Result:** For any real number 'a' and positive integer 'n', aⁿ = a * a * ... * a (n times).
- **Worked Examples:** Example 1: 3⁴ = 3 * 3 * 3 * 3 = 81. 
Example 2: (-2)³ = (-2) * (-2) * (-2) = -8.
- **Kid Likely Doubt:** Is 3² the same as 3 * 2? NO! This is the most common mistake in the world. 3² means 3 * 3 (which is 9). 3 * 2 is 6.
- **"If you are confused" Helper:** The Base is the boss. The Exponent just tells the boss how many clones to make.
- **Common Mistakes:** Multiplying the base by the exponent (e.g., saying 5³ = 15 instead of 125).
- **Mini Recap:** An exponent tells you how many times to multiply the base by itself.
- **Parent Explanation Tip:** Have them write out '4³' longhand (4*4*4) before calculating the final answer. It breaks the habit of doing 4*3.
- **Suggested Resource Links:** [Khan Academy: Intro to Exponents] - Great visual overview.
- **Suggested Visual Asset Notes:** A graphic showing 2 * 2 * 2 shrinking down into 2³.
- **Linked Questions / Quick Check:** Sample Quick Check: What does 7² equal? (49).

#### Page 2: The Laws of Exponents
- **Page ID:** `page_2_laws_of_exponents`
- **Page Objective:** Learn the rules for multiplying and dividing numbers with exponents.
- **Main Lesson Text:** Because exponents are just shorthand, we can use logic to create shortcuts. 
**Law 1 (Multiplication):** a^m * a^n = a^(m+n). If you have (2³) * (2²), you have (2*2*2) * (2*2), which is five 2s in total, or 2⁵. When multiplying, ADD the powers.
**Law 2 (Division):** a^m / a^n = a^(m-n). If you have 2⁵ / 2³, three of the 2s cancel out top and bottom, leaving 2². When dividing, SUBTRACT the powers.
**Law 3 (Power of a Power):** (a^m)^n = a^(m*n). If you have (2³)², that means (2³) * (2³), which is six 2s. MULTIPLY the powers.
- **Intuition-First Explanation:** The laws only exist because you are literally just counting how many times the base appears. Adding exponents is just counting total clones.
- **Formal Definition / Result:** 1) a^m * a^n = a^(m+n) 
2) a^m / a^n = a^(m-n) 
3) (a^m)^n = a^(mn) 
(Where a > 0).
- **Worked Examples:** Example: Simplify x⁵ * x⁴ / x². 
Top: x^(5+4) = x⁹. 
Bottom: x². 
Result: x^(9-2) = x⁷.
- **Kid Likely Doubt:** Does this work if the bases are different? Like 2³ * 3²? NO! The laws of exponents ONLY work if the base number is exactly the same.
- **"If you are confused" Helper:** Multiply bases -> Add powers. Divide bases -> Subtract powers.
- **Common Mistakes:** Adding bases. Students often think 2³ * 3³ = 5³. Wrong! It equals 8 * 27 = 216. (Notice 5³ = 125).
- **Mini Recap:** The laws of exponents let us quickly combine powers, provided the base is the same.
- **Parent Explanation Tip:** When they get stuck, make them expand the whole expression out (e.g., write out x*x*x...) and physically cross out the letters.
- **Suggested Resource Links:** [BYJU'S: Laws of Exponents] - Good summary chart.
- **Suggested Visual Asset Notes:** A visual showing x³ / x² with the top and bottom x's getting slashed out in red.
- **Linked Questions / Quick Check:** Sample Quick Check: Simplify a⁴ * a³. (a⁷).

#### Page 3: Zero and Negative Exponents
- **Page ID:** `page_3_negative_zero_exponents`
- **Page Objective:** Understand the logic behind a⁰ = 1 and negative powers.
- **Main Lesson Text:** What happens if a power is 0? Any non-zero number raised to the power of 0 is 1. (a⁰ = 1). Why? Think of division: a³ / a³. Any number divided by itself is 1. But using our subtraction law, a³ / a³ = a^(3-3) = a⁰. Therefore, a⁰ must equal 1! 
What about negative powers? A negative exponent means 'divide' instead of 'multiply'. It flips the number upside down. a⁻ⁿ = 1 / aⁿ.
- **Intuition-First Explanation:** A positive exponent tells you to multiply by the base. A negative exponent tells you to do the exact opposite: divide by the base.
- **Formal Definition / Result:** a⁰ = 1 (for a ≠ 0). 
a⁻ⁿ = 1 / aⁿ.
- **Worked Examples:** Example 1: 5⁰ = 1. 
Example 2: 2⁻³ = 1 / 2³ = 1 / 8.
- **Kid Likely Doubt:** Does a negative exponent make the answer a negative number? NO! 2⁻³ is 1/8, which is a positive fraction. The negative sign in the exponent just flips it; it doesn't change the sign of the base.
- **"If you are confused" Helper:** Negative power? Flip it to the bottom of the fraction and make the power positive.
- **Common Mistakes:** Saying 3⁻² = -9. It is actually 1 / 3² = 1/9.
- **Mini Recap:** Anything to the power 0 is 1. Negative exponents flip the number into a fraction.
- **Parent Explanation Tip:** Ask them 'What is a million to the power of zero?' When they quickly say '1', praise them. It builds confidence.
- **Suggested Resource Links:** [NCERT Math Class 9] - Review the negative exponent proofs.
- **Suggested Visual Asset Notes:** An arrow showing a negative exponent pushing a number below a fraction line.
- **Linked Questions / Quick Check:** Sample Quick Check: What is 4⁻²? (1/16).

#### Page 4: Roots: The Inverse of Exponents
- **Page ID:** `page_4_roots_as_inverses`
- **Page Objective:** Understand roots as the exact opposite operation of exponents.
- **Main Lesson Text:** If addition has subtraction, and multiplication has division, what is the opposite of an exponent? A **Root**. 
If an exponent asks: 'What is 3 multiplied by itself 4 times?' (3⁴ = 81). 
A root asks: 'What number, multiplied by itself 4 times, equals 81?' (⁴√81 = 3). 
The square root (√) is the most common. It asks 'what number squared equals this?' √25 = 5.
- **Intuition-First Explanation:** Exponents build numbers up. Roots tear them back down to their original base.
- **Formal Definition / Result:** If aⁿ = b, then the n-th root of b is a. (ⁿ√b = a).
- **Worked Examples:** Example 1: ³√8 (Cube root of 8). What times itself 3 times equals 8? 2 * 2 * 2 = 8. So ³√8 = 2.
- **Kid Likely Doubt:** Why isn't there a little '2' outside the square root symbol? Because square roots are so common, mathematicians got lazy and stopped writing the 2. √x is exactly the same as ²√x.
- **"If you are confused" Helper:** Roots ask a 'Jeopardy' question: 'I am 64. What number squared itself to make me?'
- **Common Mistakes:** Confusing square roots and dividing by 2. √100 is 10 (because 10*10=100), not 50.
- **Mini Recap:** Roots are the reverse operation of exponents.
- **Parent Explanation Tip:** Play jeopardy! Say 'The answer is 36. What is the square root?' (6).
- **Suggested Resource Links:** [CK-12: Understanding Roots] - Good basic practice.
- **Suggested Visual Asset Notes:** A cycle diagram. 5 -> (square it) -> 25 -> (square root it) -> 5.
- **Linked Questions / Quick Check:** Sample Quick Check: What is the cube root of 27? (3).

#### Page 5: Fractional Exponents: The Big Secret
- **Page ID:** `page_5_fractional_exponents`
- **Page Objective:** Connect roots and exponents using fractional powers.
- **Main Lesson Text:** Here is the biggest secret in Class 9 Math: Roots and Exponents are actually the exact same thing! 
A root is just an exponent that is a fraction. 
The square root of x (√x) can be written as x^(1/2). 
The cube root of x (³√x) can be written as x^(1/3). 
This is incredibly powerful because it means ALL the laws of exponents (adding, subtracting) work for roots too!
- **Intuition-First Explanation:** A fraction in the power is a root in disguise. The bottom of the fraction tells you what kind of root it is.
- **Formal Definition / Result:** For any positive real number a and integer n > 1, ⁿ√a = a^(1/n). More generally, a^(m/n) = (ⁿ√a)^m.
- **Worked Examples:** Example: Evaluate 27^(2/3). 
The bottom is 3, so take the cube root of 27 (which is 3). 
The top is 2, so square that answer: 3² = 9. 
So, 27^(2/3) = 9.
- **Kid Likely Doubt:** Is 9^(1/2) just 9 divided by 2? NO! 9^(1/2) means the square root of 9, which is 3. 9 divided by 2 is 4.5. Be careful!
- **"If you are confused" Helper:** Fractional power: The bottom number is the Root (Roots are at the bottom of trees). The top number is the Power.
- **Common Mistakes:** Flipping the root and the power. Remember, the denominator is always the root.
- **Mini Recap:** A fractional exponent m/n means taking the n-th root, then raising it to the m-th power.
- **Parent Explanation Tip:** Draw a tree. Point to the roots at the bottom. Say 'The bottom of the fraction is the root'.
- **Suggested Resource Links:** [Khan Academy: Fractional Exponents] - Excellent step-by-step videos.
- **Suggested Visual Asset Notes:** A drawing of a fraction m/n. The 'n' has roots growing out of it. The 'm' has a superhero cape (power).
- **Linked Questions / Quick Check:** Sample Quick Check: What does 16^(1/2) equal? (4).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The Laws of Exponents Cheat Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast recall of all exponent rules.
- **Compact Summary:** 1. Multiply Bases -> Add Powers: x² * x³ = x⁵
2. Divide Bases -> Subtract Powers: x⁵ / x² = x³
3. Power of a Power -> Multiply Powers: (x²)³ = x⁶
4. Power of Zero -> Equals 1: x⁰ = 1
5. Negative Power -> Flip it: x⁻³ = 1/x³
6. Fractional Power -> Root: x^(1/2) = √x.
- **Trouble-Spot Reminder:** Students try to add powers when the bases are different! x² * y³ does NOT simplify. It just stays x²y³.
- **Exam-Useful Points:** Exams will give you a giant fraction with negatives and zeros and ask you to simplify. Do it step by step. Deal with the zeros first, then negatives, then combine.
- **Remediation Notes:** If you forget the rule in the exam, write it out! x³ / x = (x*x*x)/x. Cross one out. You have x² left. You just proved the subtraction rule to yourself.
- **One-Page Recap Style:** A 6-point formula box.
- **Parent Support Note:** Ask them to recite the 6 rules. If they hesitate on negative powers, remind them 'Flip it'.
- **Linked Revision Questions:** Revision Quick Check: Simplify (a³)² (a⁶).
- **Linked Exam Drill Refs:** Exam Drill Ref: Exponent Simplification 5.1

#### Revision Page 2: Evaluating Fractional Powers Quickly
- **Page ID:** `page_rev_2`
- **Revision Goal:** Master the skill of solving expressions like 64^(5/6) without panic.
- **Compact Summary:** When evaluating a number like 64^(5/6):
Step 1: Look at the denominator (6). It means '6th root'. 
Step 2: Ask, 'What number times itself 6 times equals 64?' (Answer: 2).
Step 3: Look at the numerator (5). It means 'power of 5'.
Step 4: Calculate 2⁵. (Answer: 32).
- **Trouble-Spot Reminder:** Trying to do the power first! Doing 64⁵ and THEN taking the 6th root is impossible without a calculator. ALWAYS do the root (bottom number) first to shrink the number down.
- **Exam-Useful Points:** Guaranteed 2-mark question. They will use familiar bases like 8, 16, 27, 32, 64, 125.
- **Remediation Notes:** Memorize your small powers. 2²=4, 2³=8, 2⁴=16, 2⁵=32, 2⁶=64. 3²=9, 3³=27. This makes finding roots instant.
- **One-Page Recap Style:** Step-by-step algorithm box.
- **Parent Support Note:** Quiz them on the powers of 2. It is the most useful thing they can memorize for this chapter.
- **Linked Revision Questions:** Revision Quick Check: Evaluate 8^(2/3). (Answer: 4).
- **Linked Exam Drill Refs:** Exam Drill Ref: Fractional Power Drill 5.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To serve as a visual cheat sheet for all exponent laws.
  - **What Should Appear:** A 3x2 grid. Each box has one law written cleanly with a generic example.
  - **Labels Required:** Multiplication, Division, Power of Power, Zero, Negative, Fraction.
  - **Misconception to Fix:** Fixes formula confusion.
  - **Location:** Asset 2, Page 1

- **Teaching Purpose:** To prevent students from calculating the power before the root.
  - **What Should Appear:** A diagram of a fractional exponent (e.g., 5/6). Arrow 1 points to the bottom '6' saying 'DO THIS FIRST (SHRINK IT)'. Arrow 2 points to the top '5' saying 'DO THIS SECOND (GROW IT)'.
  - **Labels Required:** Root First, Power Second.
  - **Misconception to Fix:** Prevents massive unmanageable calculations.
  - **Location:** Asset 2, Page 2

---

### D. Resource Links

- **Link:** [NCERT Class 9 Math Textbook Chapter 1]
  - **Why it is useful:** Provides the official exponent laws.
  - **Best for:** basics

- **Link:** [Khan Academy: Exponent properties]
  - **Why it is useful:** Excellent interactive practice to drill the rules.
  - **Best for:** revision

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Exponents are repeated multiplication. The laws let us add/subtract/multiply powers as shortcuts. Negative powers create fractions, zero powers equal 1, and fractional powers are actually roots in disguise.
- **Parent Helper Note per difficult subtopic:** When simplifying big expressions, tell your child to take a breath and apply one rule per line of paper. Rushing causes sign errors.
- **Concept Rescue Note:** Exam Rescue: If you see a negative fractional power, like 8^(-2/3), do it in three slow steps. 1. Flip it: 1 / 8^(2/3). 2. Root it: 1 / (2²). 3. Power it: 1/4.
