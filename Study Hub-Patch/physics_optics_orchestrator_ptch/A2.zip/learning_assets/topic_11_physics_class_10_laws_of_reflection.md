# Physics Class 10 — Laws of Reflection
**Topic ID:** `topic_11_physics_10`
**Concept Tags:** `laws-of-reflection`, `angle-of-incidence`, `the-normal`, `plane-of-incidence`

This is a complete, high-quality digital learning asset pack tailored for an Indian school student in Class 10, following the NCERT framing but enriched with intuition, examples, and deep conceptual pedagogy.

---

## Asset 1: Core Learning Pack

**Target Learner:** Class 10 student (Novice)
**Estimated Learning Time:** 45 minutes

### A. Asset 1 Full Page Content

#### Page 1: The First Law of Reflection
- **Page ID:** `page_1_first_law`
- **Page Objective:** Understand the mathematical relationship between the angle of incidence and reflection.
- **Main Lesson Text:** Light doesn't bounce randomly; it follows a strict geometric rule known as the First Law of Reflection. It states that the Angle of Incidence (∠i) is exactly equal to the Angle of Reflection (∠r). If a light ray hits the mirror at an angle of 30 degrees to the normal, it will bounce off at exactly 30 degrees to the normal on the other side.
- **Intuition-First Explanation:** Think of playing pool or billiards. If you hit a ball against the cushion at a sharp angle, it bounces off at that exact same sharp angle.
- **Formal Definition / Result:** The First Law of Reflection states that the angle of incidence is equal to the angle of reflection (∠i = ∠r).
- **Worked Examples:** Example: If ∠i = 45°, then ∠r = 45°.
- **Kid Likely Doubt:** What happens if I shine the light straight down the Normal line? The angle of incidence is 0 degrees (it is 0 degrees away from the normal). Therefore, the angle of reflection must also be 0 degrees. The light bounces straight back into your flashlight!
- **"If you are confused" Helper:** Whatever angle it comes in at, it leaves at.
- **Common Mistakes:** Writing ∠i + ∠r = 90°. They are equal to each other, they don't necessarily add up to 90!
- **Mini Recap:** The angle of incidence always equals the angle of reflection.
- **Parent Explanation Tip:** Roll a ball against a wall straight on, then at an angle. The ball perfectly demonstrates the first law.
- **Suggested Resource Links:** [Khan Academy: Law of Reflection] - Good basic visualization.
- **Suggested Visual Asset Notes:** A simple ray diagram showing ∠i and ∠r with the same value.
- **Linked Questions / Quick Check:** Sample Quick Check: If ∠i is 60°, what is ∠r? (60°).

#### Page 2: The Measuring Trap
- **Page ID:** `page_2_measuring_trap`
- **Page Objective:** Prevent the most common exam mistake: measuring from the mirror surface.
- **Main Lesson Text:** The First Law is easy: ∠i = ∠r. But examiners know how to trick you! They will give you a diagram where the angle between the Incident Ray and the MIRROR SURFACE is 20 degrees. Students will immediately write '∠i = 20°'. WRONG! You must always measure from the NORMAL. Since the Normal is 90 degrees to the mirror, you must subtract. 90° - 20° = 70°. The true Angle of Incidence is 70°.
- **Intuition-First Explanation:** The Normal is the ONLY official measuring stick. The mirror is just the floor it stands on.
- **Formal Definition / Result:** Angles of incidence and reflection must strictly be measured between the respective ray and the normal, not the reflecting surface.
- **Worked Examples:** Example: If the angle with the mirror is 35°, ∠i = 90° - 35° = 55°.
- **Kid Likely Doubt:** Why don't we just measure from the mirror? Because if the mirror is a curved dome (which you will study later), measuring from the surface becomes a nightmare. Measuring from the normal always works perfectly, even on curves.
- **"If you are confused" Helper:** If the question says 'angle with the mirror', STOP. Subtract it from 90 first.
- **Common Mistakes:** Taking the angle given in the question at face value without reading the words carefully.
- **Mini Recap:** Always measure angles from the Normal line, never the mirror line.
- **Parent Explanation Tip:** Give them a few trick questions verbally. 'Angle to the mirror is 10 degrees. What is the angle of reflection?' (80 degrees).
- **Suggested Resource Links:** [BYJU'S: Laws of Reflection] - Outlines the common traps.
- **Suggested Visual Asset Notes:** A diagram highlighting the trap angle in red, and the correct Angle of Incidence in green.
- **Linked Questions / Quick Check:** Sample Quick Check: Ray hits the mirror at a 40° angle to the surface. What is the angle of reflection? (50°).

#### Page 3: The Second Law of Reflection
- **Page ID:** `page_3_second_law`
- **Page Objective:** Understand the 3D plane requirement for reflection.
- **Main Lesson Text:** The Second Law of Reflection states: The incident ray, the normal at the point of incidence, and the reflected ray all lie in the same plane. What does 'same plane' mean? It means they are all perfectly flat against the same invisible sheet of paper. If you draw the incident ray and normal on a piece of paper, the reflected ray will NOT pop out of the page at you in 3D space, nor will it sink into the desk. It stays perfectly flat on the paper.
- **Intuition-First Explanation:** Imagine sliding a hockey puck on the ice. The puck hits the wall and bounces, but it stays ON THE ICE. It doesn't magically fly up into the air.
- **Formal Definition / Result:** The incident ray, the reflected ray, and the normal to the reflecting surface at the point of incidence, all lie in the same plane.
- **Worked Examples:** Example: If you set up a laser and a mirror on a flat table, the entire laser beam path will stay parallel to the table.
- **Kid Likely Doubt:** Why do we need a law for this? Isn't it obvious? In 2D drawings, it is obvious. But in 3D real life, light could theoretically bounce in any direction (up, down, sideways). This law proves it stays in a flat, predictable slice of space.
- **"If you are confused" Helper:** Same plane = perfectly flat sheet of paper.
- **Common Mistakes:** Forgetting to write 'at the point of incidence' when writing the definition in exams. Teachers dock points for this omission.
- **Mini Recap:** The incoming ray, bouncing ray, and normal all exist on one flat 2D plane.
- **Parent Explanation Tip:** Hold a piece of paper flat against a mirror. Show how drawing a line to the mirror results in a line bouncing back that stays on the paper.
- **Suggested Resource Links:** [NCERT Class 10 Science] - Read the exact wording of the Second Law.
- **Suggested Visual Asset Notes:** An isometric 3D drawing showing a flat pane of glass (the plane) intersecting a mirror, with all three lines resting flat on the glass.
- **Linked Questions / Quick Check:** Sample Quick Check: Do the incident and reflected rays exist in a 3D volume or a 2D plane? (A 2D plane).

#### Page 4: Verifying the Laws (Experiment)
- **Page ID:** `page_4_verification`
- **Page Objective:** Understand the standard school laboratory experiment used to prove the laws.
- **Main Lesson Text:** How do we prove these laws are true? We do an experiment using a mirror, a piece of paper, and some pins. 
1. Draw a straight line on paper and stand a mirror on it. 
2. Draw a Normal line. Draw an Incident line at a specific angle (say 30°). 
3. Stick two pins upright on the Incident line. 
4. Look INTO the mirror from the other side. You will see the reflections of the pins. 
5. Stick two new pins into the paper so they perfectly line up with the reflections you see in the mirror. 
6. Remove the mirror. Draw a line through the two new pins to the mirror. This is your Reflected line! 
7. Measure it with a protractor. It will be exactly 30°!
- **Intuition-First Explanation:** By lining up pins with their reflections by eye, you are physically tracing the path the light took to reach your eye.
- **Formal Definition / Result:** The verification experiment uses the principle of parallax to trace the incident and reflected rays, confirming ∠i = ∠r and coplanarity.
- **Worked Examples:** Example: If you place pins at a 45° angle to the normal, the reflected pins will align perfectly at 45° on the other side.
- **Kid Likely Doubt:** Why use pins instead of a laser? Lasers are great, but pins are cheap, don't require batteries, and let you draw the lines precisely with a ruler afterward!
- **"If you are confused" Helper:** Pins on the line -> Look in mirror -> Line up new pins -> Measure.
- **Common Mistakes:** Placing the pins too close together. If the pins are too close, it's hard to line them up accurately, causing angle errors.
- **Mini Recap:** The pin experiment visually traces the light path to mathematically prove the laws.
- **Parent Explanation Tip:** If you have a small mirror and some pushpins, you can do this on a cardboard box at home in 5 minutes.
- **Suggested Resource Links:** [YouTube: Verification of Laws of Reflection] - Seeing the pin experiment is essential.
- **Suggested Visual Asset Notes:** A top-down view of the paper, showing the mirror line, normal, incident line with two dots (pins), and reflected line with two dots.
- **Linked Questions / Quick Check:** Sample Quick Check: Why are pins used in the reflection experiment? (To trace the path of the incident and reflected light rays).

---

## Asset 2: Revision + Practice + Remediation Pack

**Estimated Learning Time:** 20 minutes

### B. Asset 2 Full Page Content

#### Revision Page 1: The Laws: Memorization Sheet
- **Page ID:** `page_rev_1`
- **Revision Goal:** Fast, perfect recall of the two laws exactly as NCERT demands.
- **Compact Summary:** **Law 1:** The angle of incidence is equal to the angle of reflection. (∠i = ∠r).
**Law 2:** The incident ray, the reflected ray, and the normal to the reflecting surface at the point of incidence, all lie in the same plane.
- **Trouble-Spot Reminder:** Forgetting the phrase 'at the point of incidence' in Law 2. The normal can be drawn anywhere on the mirror, but the law only applies to the normal drawn exactly where the light hits.
- **Exam-Useful Points:** This is a guaranteed 2-mark question. You must write them exactly. Do not paraphrase.
- **Remediation Notes:** Write Law 2 out three times on a piece of paper. Circle the words 'at the point of incidence'.
- **One-Page Recap Style:** Bold text definitions.
- **Parent Support Note:** Ask them to recite the two laws. If they miss words in Law 2, correct them.
- **Linked Revision Questions:** Revision Quick Check: What is the mathematical formula for the First Law? (∠i = ∠r).
- **Linked Exam Drill Refs:** Exam Drill Ref: State the Laws 11.1

#### Revision Page 2: Angle Calculation Drills
- **Page ID:** `page_rev_2`
- **Revision Goal:** Rapid practice for solving the 'Angle Trap' questions.
- **Compact Summary:** **Scenario A (The easy one):** The angle between the incident ray and the NORMAL is 40°. What is the angle of reflection? Answer: 40°.
**Scenario B (The trap):** The angle between the incident ray and the MIRROR is 25°. What is the angle of reflection? Answer: 90 - 25 = 65. So ∠i = 65°, which means ∠r = 65°.
**Scenario C (The total angle):** The total angle between the incident ray and the reflected ray is 100°. What is the angle of incidence? Answer: The normal splits the total angle in half. So 100 / 2 = 50°. ∠i = 50°.
- **Trouble-Spot Reminder:** Scenario C catches a lot of students. Remember, ∠i + ∠r = Total Angle. Since they are equal, the total angle is just 2 * ∠i.
- **Exam-Useful Points:** These scenarios will appear in Section A MCQs.
- **Remediation Notes:** Always draw a quick, messy diagram on your exam paper. Label the angles. It prevents mental math errors.
- **One-Page Recap Style:** Three-scenario breakdown.
- **Parent Support Note:** Read Scenario C to them with the number '80°'. See if they can figure out the answer (40°).
- **Linked Revision Questions:** Revision Quick Check: Total angle between incident and reflected ray is 120°. What is ∠r? (60°).
- **Linked Exam Drill Refs:** Exam Drill Ref: Angle Scenarios 11.2

---

### C. Visual Content Briefs

- **Teaching Purpose:** To serve as the definitive reference for the angle trap.
  - **What Should Appear:** A diagram showing the 90 degree angle between the normal and the mirror broken into two chunks. The bottom chunk (ray to mirror) is labeled 'TRAP'. The top chunk (ray to normal) is labeled 'CORRECT'.
  - **Labels Required:** Mirror, Normal, Incident Ray, Trap Angle, Correct Angle.
  - **Misconception to Fix:** Visually proves why subtracting from 90 gives the correct angle.
  - **Location:** Asset 1, Page 2

- **Teaching Purpose:** To visualize the concept of 'the same plane'.
  - **What Should Appear:** A 3D drawing of a flat sheet of glass intersecting a mirror. The incident ray, normal, and reflected ray are all drawn flat on the sheet of glass.
  - **Labels Required:** Plane of Incidence, Mirror, Normal, Rays.
  - **Misconception to Fix:** Prevents students from thinking 'plane' means an airplane. It means a flat 2D slice of 3D space.
  - **Location:** Asset 1, Page 3

---

### D. Resource Links

- **Link:** [NCERT Class 10 Science Textbook Chapter 10]
  - **Why it is useful:** Provides the exact wording for the laws that examiners look for.
  - **Best for:** basics

- **Link:** [YouTube: Verification of Laws of Reflection using Pins]
  - **Why it is useful:** Seeing the physical experiment makes the abstract laws concrete.
  - **Best for:** deeper understanding

---

### E. Recap Assets

- **Revision Summary per difficult subtopic:** Light follows strict laws: The incoming angle equals the outgoing angle (measured from the Normal, NOT the mirror), and the entire 'V' shape of the bounce stays perfectly flat on a 2D plane.
- **Parent Helper Note per difficult subtopic:** The word 'Normal' in math and physics means 'perpendicular'. The word 'Plane' means 'a flat sheet'. Translating these jargon words into plain English fixes 90% of student confusion.
- **Concept Rescue Note:** Exam Rescue: If you get a word problem with an angle, DRAW IT. Put the normal in, label the angle given, and find the missing pieces. Visualizing it stops you from falling into the angle trap.
