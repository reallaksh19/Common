# Topic Blueprint: Number System

## A. Topic metadata
- **topicId:** math_9_number_system
- **subjectId:** mathematics
- **classLevel:** 9
- **title:** Number System
- **description:** Exploration of natural numbers, whole numbers, integers, rational numbers, irrational numbers, and real numbers.
- **order suggestion:** 1
- **difficulty:** beginner
- **tags:** math, class_9, number_system, hierarchy
- **helperText:** Essential chapter building foundational intuition on number classification.
- **coverAssetPath placeholder:** `assets/math_9_number_system_cover.png`

## B. Stable ID rules
- **page ids:** `page_math_9_number_system_[core|rev]_[01-12]`
- **page file names:** `page_[01-12].json`
- **question set ids:** `qset_math_9_number_system_[type]`
- **asset ids:** `asset_math_9_number_system_[img|svg|pdf]_[01-05]`
- **conceptTags:** `tag_math_9_number_system_[subconcept]`
- **revision set ids:** `revset_math_9_number_system`
- **exam drill ids:** `examdrill_math_9_number_system`

## C. Asset 1 structure (Core Learning Pack)
### Page 1: The Natural and Whole Numbers
- **pageId:** `page_math_9_number_system_core_01`
- **slug:** `core-concept-natural-whole`
- **title:** The Natural and Whole Numbers
- **objective:** Identify counting numbers and the addition of zero.
- **estimatedMinutes:** 5
- **prerequisitePageIds:** []
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_natural, tag_math_9_number_system_whole]`
- **revisionSummary placeholders:** `Review definition of Natural (starts at 1) vs Whole (starts at 0).`
- **helper note placeholders:** `Parent Tip: Count physical objects to show zero isn't a natural starting point.`
- **clarifier placeholders:** `Kid Doubt: Is infinity a number? -> Clarifier: Infinity is a concept of boundlessness, not a specific coordinate.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/natural-whole-intro`
- **expected question-set links:** `[qset_math_9_number_system_quickcheck]`

### Page 2: Adding Direction: Integers
- **pageId:** `page_math_9_number_system_core_02`
- **slug:** `core-concept-integers`
- **title:** Adding Direction: Integers
- **objective:** Introduce negative numbers to represent deficits.
- **estimatedMinutes:** 5
- **prerequisitePageIds:** [`page_math_9_number_system_core_01`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_integers, tag_math_9_number_system_negative]`
- **revisionSummary placeholders:** `Integers mirror the whole numbers below zero.`
- **helper note placeholders:** `Parent Tip: Use a thermometer to show temperatures above and below zero.`
- **clarifier placeholders:** `Misconception: -5 is a whole number. -> Repair: Whole numbers strictly stop at zero. Negatives are integers.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/integers-intro`
- **expected question-set links:** `[qset_math_9_number_system_reasoning]`

### Page 3: The Spaces Between: Rational Numbers
- **pageId:** `page_math_9_number_system_core_03`
- **slug:** `core-concept-rational`
- **title:** The Spaces Between: Rational Numbers
- **objective:** Define numbers expressible as p/q ratios.
- **estimatedMinutes:** 10
- **prerequisitePageIds:** [`page_math_9_number_system_core_02`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_rational, tag_math_9_number_system_fractions]`
- **revisionSummary placeholders:** `A rational number is any number that can be written as a fraction of integers.`
- **helper note placeholders:** `Parent Tip: Slice a pizza to show ratios of whole numbers.`
- **clarifier placeholders:** `Misconception: Integers are not rational. -> Repair: Any integer 'z' is rational because it is z/1.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/rational-def`
- **expected question-set links:** `[qset_math_9_number_system_assertion]`

### Page 4: The Infinite Mess: Irrational Numbers
- **pageId:** `page_math_9_number_system_core_04`
- **slug:** `core-concept-irrational`
- **title:** The Infinite Mess: Irrational Numbers
- **objective:** Identify numbers that cannot be written as p/q.
- **estimatedMinutes:** 10
- **prerequisitePageIds:** [`page_math_9_number_system_core_03`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_irrational, tag_math_9_number_system_pi]`
- **revisionSummary placeholders:** `Irrational numbers have infinite, non-repeating decimal expansions.`
- **helper note placeholders:** `Parent Tip: Try writing out Pi to show no repeating block.`
- **clarifier placeholders:** `Misconception: Pi is exactly 22/7. -> Repair: 22/7 is a rational approximation. Pi never repeats.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/irrational-intro`
- **expected question-set links:** `[qset_math_9_number_system_quickcheck]`

### Page 5: The Ultimate Set: Real Numbers
- **pageId:** `page_math_9_number_system_core_05`
- **slug:** `core-concept-real-numbers`
- **title:** The Ultimate Set: Real Numbers
- **objective:** Combine rational and irrational into one continuous set.
- **estimatedMinutes:** 5
- **prerequisitePageIds:** [`page_math_9_number_system_core_04`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_real_numbers]`
- **revisionSummary placeholders:** `Real numbers contain both rational and irrational numbers.`
- **helper note placeholders:** `Parent Tip: Think of Real Numbers as a giant umbrella covering the entire number line.`
- **clarifier placeholders:** `Kid Doubt: Can a number be both rational and irrational? -> Clarifier: Never. They are mutually exclusive subsets.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/real-numbers`
- **expected question-set links:** `[qset_math_9_number_system_reasoning]`

### Page 6: Visual Hierarchy of Number Sets
- **pageId:** `page_math_9_number_system_core_06`
- **slug:** `core-concept-hierarchy`
- **title:** Visual Hierarchy of Number Sets
- **objective:** Memorize the subset relationships N c W c Z c Q c R.
- **estimatedMinutes:** 5
- **prerequisitePageIds:** [`page_math_9_number_system_core_05`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_hierarchy]`
- **revisionSummary placeholders:** `N is a subset of W, which is a subset of Z, which is a subset of Q.`
- **helper note placeholders:** `Parent Tip: Draw nesting boxes on paper.`
- **clarifier placeholders:** `Misconception: Irrational numbers are a subset of rational. -> Repair: They are completely disjoint. They only meet under Real.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/number-sets`
- **expected question-set links:** `[qset_math_9_number_system_assertion]`

### Page 7: Placement on the Number Line
- **pageId:** `page_math_9_number_system_core_07`
- **slug:** `core-concept-number-line`
- **title:** Placement on the Number Line
- **objective:** Map integer, fraction, and root points on a continuous line.
- **estimatedMinutes:** 10
- **prerequisitePageIds:** [`page_math_9_number_system_core_06`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_plotting]`
- **revisionSummary placeholders:** `Every real number corresponds to exactly one point on the number line.`
- **helper note placeholders:** `Parent Tip: Draw a large line and place 1/2 and sqrt(2).`
- **clarifier placeholders:** `Misconception: Irrationals take up 'fuzzy' space on the line. -> Repair: They are exact, infinitely precise coordinates.`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/plotting-irrationals`
- **expected question-set links:** `[qset_math_9_number_system_reasoning]`

### Page 8: Rational vs Irrational Decimals
- **pageId:** `page_math_9_number_system_core_08`
- **slug:** `core-concept-decimal-classification`
- **title:** Rational vs Irrational Decimals
- **objective:** Classify decimals as terminating/repeating vs non-repeating.
- **estimatedMinutes:** 10
- **prerequisitePageIds:** [`page_math_9_number_system_core_04`]
- **relatedPageIds:** []
- **conceptTags:** `[tag_math_9_number_system_decimal_classification]`
- **revisionSummary placeholders:** `Terminating or perfectly repeating = Rational. Chaotic and infinite = Irrational.`
- **helper note placeholders:** `Parent Tip: Show 1/3 (repeats) vs a random chaotic decimal string.`
- **clarifier placeholders:** `Misconception: Any pattern means repeating. -> Repair: It must be the EXACT same block of digits over and over (e.g. 0.1010010001 is not rational).`
- **recommended block types:** TextBlock, ImageBlock, QuizBlock
- **expected resources:** `https://khanacademy.org/math/decimal-patterns`
- **expected question-set links:** `[qset_math_9_number_system_assertion]`

## D. Asset 2 structure (Revision / Practice Pack)
### Page 1: Hierarchy Chart Drill
- **pageId:** `page_math_9_number_system_rev_01`
- **slug:** `revision-hierarchy-chart`
- **title:** Hierarchy Chart Drill
- **objective:** Rapid recall of subset nesting.
- **estimatedMinutes:** 10
- **conceptTags:** `[tag_math_9_number_system_hierarchy]`
- **revision role:** Summary Chart
- **remediation role:** Review the Matryoshka doll analogy if failed.
- **exam role:** Multiple Choice ID
- **recommended quick-drill blocks:** MCQ, True/False
- **recommended summary cards:** FlashcardBlock
- **linked question sets:** `[qset_math_9_number_system_revdrill]`

### Page 2: Misconception: Zero and Negatives
- **pageId:** `page_math_9_number_system_rev_02`
- **slug:** `revision-zero-negatives`
- **title:** Misconception: Zero and Negatives
- **objective:** Fix common sorting errors for 0 and negative integers.
- **estimatedMinutes:** 5
- **conceptTags:** `[tag_math_9_number_system_integers, tag_math_9_number_system_whole]`
- **revision role:** Misconception Fixer
- **remediation role:** Remind that Whole stops at 0. Negatives are strictly Integers/Rational.
- **exam role:** True/False Speed Test
- **recommended quick-drill blocks:** True/False
- **recommended summary cards:** FlashcardBlock
- **linked question sets:** `[qset_math_9_number_system_rescue]`

### Page 3: Decimal Identification Tricks
- **pageId:** `page_math_9_number_system_rev_03`
- **slug:** `revision-decimal-tricks`
- **title:** Decimal Identification Tricks
- **objective:** Instantly spot rational vs irrational decimals.
- **estimatedMinutes:** 10
- **conceptTags:** `[tag_math_9_number_system_decimal_classification]`
- **revision role:** Rapid Drill
- **remediation role:** If chaotic: Irrational. If block repeats: Rational.
- **exam role:** Match the following decimal types.
- **recommended quick-drill blocks:** MCQ, Match
- **recommended summary cards:** FlashcardBlock
- **linked question sets:** `[qset_math_9_number_system_examdrill]`

### Page 4: Simplification Before Classification
- **pageId:** `page_math_9_number_system_rev_04`
- **slug:** `revision-simplification-trap`
- **title:** Simplification Before Classification
- **objective:** Avoid traps like sqrt(9) being called irrational.
- **estimatedMinutes:** 10
- **conceptTags:** `[tag_math_9_number_system_irrational]`
- **revision role:** Exam Trap Prep
- **remediation role:** Always solve the root/fraction before naming the set.
- **exam role:** Assertion-Reason Drill
- **recommended quick-drill blocks:** Assertion-Reason
- **recommended summary cards:** FlashcardBlock
- **linked question sets:** `[qset_math_9_number_system_examdrill]`

## E. Question architecture
- **1 quick-check set per major subtopic:** `qset_math_9_number_system_quickcheck` (Title: [Auto-generated Title]; Purpose: Verify reading comprehension; ConceptTags: core; Count: 15; Difficulty: Easy; Type: MCQ; Support: page 1)
- **1 reasoning set per major subtopic:** `qset_math_9_number_system_reasoning` (Title: [Auto-generated Title]; Purpose: Deepen understanding; ConceptTags: core; Count: 15; Difficulty: Medium; Type: Short Answer; Support: page 2)
- **1 assertion-reason set where suitable:** `qset_math_9_number_system_assertion` (Title: [Auto-generated Title]; Purpose: Exam prep; ConceptTags: core; Count: 20; Difficulty: Hard; Type: Assertion-Reason; Support: page 3)
- **1 revision drill set:** `qset_math_9_number_system_revdrill` (Title: [Auto-generated Title]; Purpose: Speed building; ConceptTags: rev; Count: 20; Difficulty: Mixed; Type: Fill-up; Support: rev page 1)
- **1 exam drill set:** `qset_math_9_number_system_examdrill` (Title: [Auto-generated Title]; Purpose: Final test; ConceptTags: rev; Count: 20; Difficulty: Hard; Type: MCQ; Support: rev page 2)
- **1 doubt-rescue set:** `qset_math_9_number_system_rescue` (Title: [Auto-generated Title]; Purpose: Remediation; ConceptTags: rev; Count: 10; Difficulty: Easy; Type: True/False; Support: rev page 3)

## F. Asset plan
- **2 SVG briefs:** 
  1. `asset_math_9_number_system_svg_01`: Venn diagram showing N inside W inside Z inside Q, with Irrationals separate, all inside R. Must use high-contrast bold colors.
  2. `asset_math_9_number_system_svg_02`: A number line highlighting integers with large ticks, 1.5 with a medium tick, and sqrt(2) with a distinct colored arrow.
- **2 image/illustration briefs:** 
  1. `asset_math_9_number_system_img_01`: A Matryoshka (nesting) doll graphic to represent number subsets.
  2. `asset_math_9_number_system_img_02`: A pizza sliced into 8 pieces with 3 removed to visually represent rational p/q.
- **1 printable worksheet/PDF brief:** 
  - `asset_math_9_number_system_pdf_01`: 2-page printable PDF titled 'Number Classification Speed Test' (Match columns and True/False).
- **3-8 curated resource link placeholders:** 
  - `[link_math_9_number_system_ncert_chapter]`
  - `[link_math_9_number_system_khan_academy_sets]`
  - `[link_math_9_number_system_byjus_reference]`
- **1 video/resource placeholder per difficult subtopic:** 
  - `[video_math_9_number_system_remediation_irrationals]`

## G. App-ready JSON blueprint
### `topic.json`
```json
{
  "topicId": "math_9_number_system",
  "title": "Number System",
  "pages": ["page_01.json", "page_02.json"],
  "questionLibrary": "question-library.json",
  "assetsManifest": "assets-manifest.json"
}
```
### `pages/page_01.json` (Asset 1 Example)
```json
{
  "pageId": "page_math_9_number_system_core_01",
  "title": "The Natural and Whole Numbers",
  "objective": "Identify counting numbers and the addition of zero.",
  "blocks": [
     {"type": "TextBlock", "contentId": "text_block_01"},
     {"type": "QuizBlock", "contentId": "qset_math_9_number_system_quickcheck"}
  ]
}
```
### `pages/page_02.json` (Asset 1 Example)
```json
{
  "pageId": "page_math_9_number_system_core_02",
  "title": "Adding Direction: Integers",
  "objective": "Introduce negative numbers to represent deficits.",
  "blocks": [
     {"type": "TextBlock", "contentId": "text_block_02"},
     {"type": "QuizBlock", "contentId": "qset_math_9_number_system_reasoning"}
  ]
}
```
### `pages/rev_01.json` (Asset 2 Example)
```json
{
  "pageId": "page_math_9_number_system_rev_01",
  "title": "Hierarchy Chart Drill",
  "objective": "Rapid recall of subset nesting.",
  "blocks": [
     {"type": "FlashcardBlock", "contentId": "flashcard_01"},
     {"type": "QuizBlock", "contentId": "qset_math_9_number_system_revdrill"}
  ]
}
```
### `question-library.json`
```json
{
  "sets": ["qset_math_9_number_system_quickcheck", "qset_math_9_number_system_assertion"]
}
```
### `assets-manifest.json`
```json
{
  "images": ["asset_math_9_number_system_img_01.png"],
  "svgs": ["asset_math_9_number_system_svg_01.svg"]
}
```

## H. Validation checklist
- [x] all page ids stable
- [x] all slugs stable
- [x] all conceptTags reused consistently
- [x] all question sets linked to pages
- [x] all support references valid
