import os
from PIL import Image, ImageDraw, ImageFont

def generate_images():
    os.makedirs("output/assets", exist_ok=True)
    
    # Image 1: Matryoshka doll abstract representation
    img1 = Image.new('RGB', (400, 400), color=(255, 255, 255))
    d1 = ImageDraw.Draw(img1)
    
    # Draw nested circles/ovals to represent dolls
    colors = [(25, 118, 210), (33, 150, 243), (100, 181, 246), (187, 222, 251)]
    for i, color in enumerate(colors):
        offset = i * 40
        d1.ellipse([offset + 20, offset + 20, 380 - offset, 380 - offset], fill=color, outline="black", width=2)
        
    d1.text((160, 180), "Nested", fill="black")
    d1.text((165, 200), "Sets", fill="black")
    
    img1.save("output/assets/asset_math_9_number_system_img_01.png")
    
    # Image 2: Pizza slice representation
    img2 = Image.new('RGB', (400, 400), color=(255, 255, 255))
    d2 = ImageDraw.Draw(img2)
    
    # Draw full circle (pizza)
    d2.ellipse([50, 50, 350, 350], fill=(255, 204, 128), outline="orange", width=4)
    
    # Draw lines to make 8 slices
    d2.line([50, 200, 350, 200], fill="orange", width=4)
    d2.line([200, 50, 200, 350], fill="orange", width=4)
    d2.line([94, 94, 306, 306], fill="orange", width=4)
    d2.line([94, 306, 306, 94], fill="orange", width=4)
    
    # "Remove" 3 slices by coloring them white (background)
    d2.pieslice([50, 50, 350, 350], start=0, end=135, fill=(255, 255, 255), outline="orange", width=4)
    
    d2.text((180, 20), "5 / 8 Remaining", fill="black")
    
    img2.save("output/assets/asset_math_9_number_system_img_02.png")

if __name__ == '__main__':
    generate_images()
