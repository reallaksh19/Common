import os
import json

def generate_jsons():
    os.makedirs("output/pages", exist_ok=True)
    os.makedirs("output/assets", exist_ok=True)
    
    # topic.json
    topic_data = {
      "topicId": "math_9_number_system",
      "title": "Number System",
      "pages": ["page_01.json", "page_02.json", "rev_01.json"],
      "questionLibrary": "question-library.json",
      "assetsManifest": "assets-manifest.json"
    }
    with open("output/topic.json", "w", encoding="utf-8") as f:
        json.dump(topic_data, f, indent=2)

    # page_01.json
    page_01 = {
      "pageId": "page_math_9_number_system_core_01",
      "title": "The Natural and Whole Numbers",
      "objective": "Identify counting numbers and the addition of zero.",
      "blocks": [
         {"type": "TextBlock", "contentId": "text_block_01"},
         {"type": "QuizBlock", "contentId": "qset_math_9_number_system_quickcheck"}
      ]
    }
    with open("output/pages/page_01.json", "w", encoding="utf-8") as f:
        json.dump(page_01, f, indent=2)

    # page_02.json
    page_02 = {
      "pageId": "page_math_9_number_system_core_02",
      "title": "Adding Direction: Integers",
      "objective": "Introduce negative numbers to represent deficits.",
      "blocks": [
         {"type": "TextBlock", "contentId": "text_block_02"},
         {"type": "QuizBlock", "contentId": "qset_math_9_number_system_reasoning"}
      ]
    }
    with open("output/pages/page_02.json", "w", encoding="utf-8") as f:
        json.dump(page_02, f, indent=2)
        
    # rev_01.json
    rev_01 = {
      "pageId": "page_math_9_number_system_rev_01",
      "title": "Hierarchy Chart Drill",
      "objective": "Rapid recall of subset nesting.",
      "blocks": [
         {"type": "FlashcardBlock", "contentId": "flashcard_01"},
         {"type": "QuizBlock", "contentId": "qset_math_9_number_system_revdrill"}
      ]
    }
    with open("output/pages/rev_01.json", "w", encoding="utf-8") as f:
        json.dump(rev_01, f, indent=2)

    # question-library.json
    q_lib = {
      "sets": [
          {"id": "qset_math_9_number_system_quickcheck", "title": "Quick Check 1", "purpose": "Verify reading comprehension"},
          {"id": "qset_math_9_number_system_reasoning", "title": "Reasoning 1", "purpose": "Deepen understanding"}
      ]
    }
    with open("output/question-library.json", "w", encoding="utf-8") as f:
        json.dump(q_lib, f, indent=2)

    # assets-manifest.json
    manifest = {
      "images": ["asset_math_9_number_system_img_01.png", "asset_math_9_number_system_img_02.png"],
      "svgs": ["asset_math_9_number_system_svg_01.svg", "asset_math_9_number_system_svg_02.svg"],
      "pdfs": ["asset_math_9_number_system_pdf_01.pdf"]
    }
    with open("output/assets-manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

if __name__ == '__main__':
    generate_jsons()
