import os

def build_svg1():
    # Venn diagram showing N inside W inside Z inside Q, with Irrationals separate, all inside R.
    svg = """<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400">
  <rect width="100%" height="100%" fill="#E3F2FD" rx="15" />
  <text x="20" y="30" font-family="Arial" font-weight="bold" font-size="20" fill="#0D47A1">Real Numbers (R)</text>

  <!-- Rational Group -->
  <rect x="20" y="50" width="380" height="330" fill="#BBDEFB" rx="10" stroke="#1976D2" stroke-width="2"/>
  <text x="30" y="80" font-family="Arial" font-weight="bold" font-size="16" fill="#1565C0">Rational Numbers (Q)</text>

  <!-- Integer Group -->
  <rect x="40" y="100" width="340" height="260" fill="#90CAF9" rx="10" stroke="#1565C0" stroke-width="2"/>
  <text x="50" y="130" font-family="Arial" font-weight="bold" font-size="16" fill="#0D47A1">Integers (Z)</text>

  <!-- Whole Group -->
  <rect x="60" y="150" width="300" height="190" fill="#64B5F6" rx="10" stroke="#0D47A1" stroke-width="2"/>
  <text x="70" y="180" font-family="Arial" font-weight="bold" font-size="16" fill="#000">Whole Numbers (W)</text>

  <!-- Natural Group -->
  <rect x="80" y="200" width="260" height="120" fill="#42A5F5" rx="10" stroke="#000" stroke-width="2"/>
  <text x="90" y="230" font-family="Arial" font-weight="bold" font-size="16" fill="#FFF">Natural Numbers (N)</text>
  
  <text x="100" y="260" font-family="Arial" font-size="14" fill="#FFF">1, 2, 3...</text>
  <text x="70" y="310" font-family="Arial" font-size="14" fill="#000">0</text>
  <text x="50" y="340" font-family="Arial" font-size="14" fill="#0D47A1">-1, -2...</text>
  <text x="30" y="360" font-family="Arial" font-size="14" fill="#1565C0">1/2, -3/4...</text>

  <!-- Irrational Group -->
  <rect x="420" y="50" width="160" height="330" fill="#C8E6C9" rx="10" stroke="#388E3C" stroke-width="2"/>
  <text x="430" y="80" font-family="Arial" font-weight="bold" font-size="16" fill="#1B5E20">Irrationals</text>
  <text x="440" y="150" font-family="Arial" font-size="14" fill="#1B5E20">π, √2, √3...</text>
</svg>"""
    with open("output/assets/asset_math_9_number_system_svg_01.svg", "w", encoding="utf-8") as f:
        f.write(svg)

def build_svg2():
    # Number line
    svg = """<svg xmlns="http://www.w3.org/2000/svg" width="600" height="200">
  <rect width="100%" height="100%" fill="#FFFFFF" />
  
  <!-- Line -->
  <line x1="50" y1="100" x2="550" y2="100" stroke="#000" stroke-width="3" />
  <!-- Arrows -->
  <polygon points="50,100 65,95 65,105" fill="#000" />
  <polygon points="550,100 535,95 535,105" fill="#000" />

  <!-- Ticks -2 to 2 -->
  <line x1="150" y1="90" x2="150" y2="110" stroke="#000" stroke-width="2" />
  <text x="145" y="130" font-family="Arial" font-size="16">-2</text>
  
  <line x1="250" y1="90" x2="250" y2="110" stroke="#000" stroke-width="2" />
  <text x="245" y="130" font-family="Arial" font-size="16">-1</text>
  
  <line x1="350" y1="90" x2="350" y2="110" stroke="#000" stroke-width="2" />
  <text x="345" y="130" font-family="Arial" font-size="16">0</text>
  
  <line x1="450" y1="90" x2="450" y2="110" stroke="#000" stroke-width="2" />
  <text x="445" y="130" font-family="Arial" font-size="16">1</text>
  
  <!-- 1.5 Tick (Medium) -->
  <line x1="500" y1="95" x2="500" y2="105" stroke="#1565C0" stroke-width="2" />
  <text x="490" y="145" font-family="Arial" font-size="14" fill="#1565C0">1.5</text>
  
  <!-- sqrt(2) tick (~1.414 -> between 1 and 1.5) -->
  <line x1="491.4" y1="80" x2="491.4" y2="100" stroke="#D32F2F" stroke-width="2" />
  <polygon points="491.4,100 487.4,90 495.4,90" fill="#D32F2F" />
  <text x="475" y="70" font-family="Arial" font-size="14" fill="#D32F2F" font-weight="bold">√2 (~1.41)</text>

</svg>"""
    with open("output/assets/asset_math_9_number_system_svg_02.svg", "w", encoding="utf-8") as f:
        f.write(svg)

if __name__ == '__main__':
    os.makedirs("output/assets", exist_ok=True)
    build_svg1()
    build_svg2()
