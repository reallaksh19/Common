import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def create_worksheet():
    os.makedirs("output/assets", exist_ok=True)
    c = canvas.Canvas("output/assets/asset_math_9_number_system_pdf_01.pdf", pagesize=letter)
    width, height = letter
    
    # Page 1
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, height - 50, "Number Classification Speed Test")
    
    c.setFont("Helvetica", 14)
    c.drawString(50, height - 80, "Part 1: Match the Number to its Most Specific Set")
    
    questions = [
        ("1. -15", "A. Natural Numbers (N)"),
        ("2. 0", "B. Whole Numbers (W)"),
        ("3. 22/7", "C. Integers (Z)"),
        ("4. sqrt(2)", "D. Rational Numbers (Q)"),
        ("5. 42", "E. Irrational Numbers")
    ]
    
    y = height - 120
    for q, a in questions:
        c.drawString(70, y, q)
        c.drawString(300, y, a)
        y -= 40
        
    c.drawString(50, y - 40, "Part 2: True or False (Explain your reasoning briefly)")
    y -= 80
    
    tf_qs = [
        "1. Every integer is a rational number.",
        "2. All real numbers are either rational or irrational.",
        "3. 0.3333... is an irrational number."
    ]
    
    for q in tf_qs:
        c.drawString(70, y, q)
        c.line(70, y - 20, 500, y - 20) # line for answer
        y -= 60
        
    c.showPage()
    
    # Page 2 (Answer Key)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, height - 50, "Answer Key")
    
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 100, "Part 1: 1-C, 2-B, 3-D, 4-E, 5-A")
    c.drawString(50, height - 130, "Part 2: 1-True (n/1), 2-True (definition), 3-False (repeating is rational)")
    
    c.save()

if __name__ == '__main__':
    create_worksheet()
