# Known Issues & Future Improvements

This document tracks known issues, technical debt, and planned feature enhancements for the Harshi-App Study Hub project.

## 1. Missing Asset Library & Usage Tracking
* **Issue:** Parents must manually enter image/PDF paths into blocks or clarifiers. There is no central library to upload, tag, preview, or reuse assets.
* **Impact:** Managing diagrams, PDFs, and other resources is error-prone. There is no indication of which pages reference a file, making it risky to delete or replace assets.
* **Proposed Solution:** Create an interface where parents can upload images, PDFs, and SVGs into a topic‑scoped library, see thumbnails, search by tag, view where each asset is used, and replace or delete assets safely.

## 2. Incomplete Draft/Publish/Export State Indicators
* **Issue:** The app autosaves drafts to `localStorage`, but parents are not shown whether a topic is merely a draft, is saved to disk, has been exported as a chapter pack, or is the version being shown to students.
* **Impact:** Revisiting a topic can be confusing, as it is unclear what state the content is in relative to what the student sees.
* **Proposed Solution:** Show clear indicators for each topic (e.g., “Draft saved locally”, “Published for students”, “Exported pack version 2”) and provide a version history to restore older versions or see what changed.

## 3. Lack of Version History & Undo
* **Issue:** Large numbers of topics or pages can become unmanageable because there is no way to revert to a previous version of a page.
* **Impact:** Accidental deletions or bad edits are difficult to recover from without falling back to a previously exported `.zip` content pack.
* **Proposed Solution:** Implement version tracking on the backend (e.g., saving `[slug]-v1.json`, `[slug]-v2.json`) or integrate a simple git-backed save mechanism for content files.

## 4. Loose Slugs and Topic IDs Consistency
* **Issue:** Page IDs often incorporate the subject and topic (e.g., `physics-optics-refraction`) but the `topic.json` file sometimes uses a different pattern (e.g., `light-and-visibility`).
* **Impact:** Pathing errors can occur during imports/exports if the ID generation isn't strictly adhered to.
* **Proposed Solution:** Introduce robust helper functions that generate page IDs, slugs, and file names consistently from the page title and topic ID, enforcing this universally rather than trusting the manually created mock data.

## 5. Potential AI Provider Abstraction Needed
* **Issue:** Currently, Gemini AI API logic is tightly coupled or mocked within the UI components (e.g., `RightSidebar.jsx`).
* **Impact:** Switching to a Firebase AI Logic route (Option A) or serverless functions will require significant UI changes.
* **Proposed Solution:** Factor out AI calls behind an `aiProvider` interface, allowing the app to switch between mock, serverless functions, or Firebase AI Logic without altering UI code.
