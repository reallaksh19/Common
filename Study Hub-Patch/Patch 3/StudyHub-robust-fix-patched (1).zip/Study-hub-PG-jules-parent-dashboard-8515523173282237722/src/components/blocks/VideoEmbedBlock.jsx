import React from 'react';

function toEmbedUrl(url = '') {
  if (!url) return '';
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes('youtube.com')) {
      if (parsed.pathname.startsWith('/embed/')) return url;
      const v = parsed.searchParams.get('v');
      return v ? `https://www.youtube.com/embed/${v}` : url;
    }
    if (parsed.hostname === 'youtu.be') {
      const id = parsed.pathname.replace(/^\//, '');
      return id ? `https://www.youtube.com/embed/${id}` : url;
    }
    if (parsed.hostname.includes('vimeo.com')) {
      const id = parsed.pathname.replace(/^\//, '');
      return id ? `https://player.vimeo.com/video/${id}` : url;
    }
    if (parsed.pathname.includes('/embed/')) return url;
    return '';
  } catch {
    return '';
  }
}

export function VideoEmbedBlock({ url = '', title = 'Video', caption = '', height = 360 }) {
  const embedUrl = toEmbedUrl(url);
  return (
    <div className="mb-4">
      {embedUrl ? (
        <iframe
          src={embedUrl}
          title={title}
          className="w-full rounded border bg-black"
          style={{ height: `${height || 360}px` }}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ) : (
        <div className="border rounded p-4 bg-gray-50">
          <div className="font-semibold mb-2">{title}</div>
          <div className="text-sm text-gray-600 mb-3">This provider does not support direct embed here. Open the link in a new tab.</div>
          <a href={url} target="_blank" rel="noreferrer" className="text-blue-600 font-medium underline break-all">{url}</a>
        </div>
      )}
      {caption && <p className="text-sm text-gray-500 mt-2 text-center">{caption}</p>}
    </div>
  );
}
