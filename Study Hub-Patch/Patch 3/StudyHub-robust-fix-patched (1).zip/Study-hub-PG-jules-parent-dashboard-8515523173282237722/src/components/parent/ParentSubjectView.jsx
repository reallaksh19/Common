import React, { useMemo, useState } from 'react';
import { slugify } from '../../utils/slugify.js';
import { createDirectory, saveJSON } from '../../services/parentApiService.js';
import { formatRelativeTime, getTopicStatus } from '../../services/topicStateService.js';
import { buildTopicId } from '../../utils/contentPaths.js';

export function ParentSubjectView({ subject, topics }) {
  const [search, setSearch] = useState('');
  if (!subject) return <div>Subject not found</div>;

  const filteredTopics = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return topics;
    return topics.filter((topic) => topic.title?.toLowerCase().includes(q) || topic.folder?.toLowerCase().includes(q));
  }, [search, topics]);

  const handleAddTopic = async () => {
    const title = window.prompt('Enter new topic title:');
    if (!title) return;

    const folder = slugify(title);
    const newTopic = {
      id: buildTopicId(subject.id, folder),
      subjectId: subject.id,
      title,
      difficulty: 'medium',
      estimatedMinutes: 30,
      pages: []
    };

    try {
      const subjectFolder = subject.folder || subject.id || subject.title;
      await createDirectory(`${subjectFolder}/${folder}/pages`);
      await createDirectory(`${subjectFolder}/${folder}/assets`);
      await saveJSON(`${subjectFolder}/${folder}/topic.json`, newTopic);
      window.location.hash = `#/parent/subject/${subject.id}/topic/${folder}`;
    } catch (err) {
      alert('Failed to create topic: backend might be unavailable.');
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">{subject.title} Topics</h1>
        <button onClick={handleAddTopic} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          + Add Topic
        </button>
      </div>

      <div className="mb-4 flex items-center gap-3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search topics or folders"
          className="w-full max-w-md border rounded px-3 py-2"
        />
        <div className="text-sm text-gray-500">{filteredTopics.length} topic(s)</div>
      </div>

      <div className="bg-white border rounded shadow-sm">
        {filteredTopics.map((topic) => {
          const status = getTopicStatus(`${subject.id}/${topic.folder || topic.id}`);
          return (
            <div key={topic.id} className="flex items-center justify-between p-4 border-b last:border-0 hover:bg-gray-50 gap-4">
              <div>
                <div className="font-bold text-lg">{topic.title}</div>
                <div className="text-sm text-gray-500">
                  {topic.pages?.length || 0} pages · {topic.difficulty || 'Medium'}
                </div>
                <div className="text-xs text-gray-500 mt-1 flex flex-wrap gap-3">
                  <span>Draft: {status.hasDraft ? formatRelativeTime(status.draftSavedAt) : 'none'}</span>
                  <span>Published: {formatRelativeTime(status.publishedAt)}</span>
                  <span>Exported: {status.exportCount || 0} time(s)</span>
                </div>
              </div>
              <div className="flex gap-2">
                <a href={`#/parent/subject/${subject.id}/topic/${topic.folder || topic.id.replace(`${subject.id}-`, '')}`} className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded text-sm">
                  Edit
                </a>
              </div>
            </div>
          );
        })}
        {filteredTopics.length === 0 && <div className="p-8 text-center text-gray-500">No topics yet.</div>}
      </div>
    </div>
  );
}
