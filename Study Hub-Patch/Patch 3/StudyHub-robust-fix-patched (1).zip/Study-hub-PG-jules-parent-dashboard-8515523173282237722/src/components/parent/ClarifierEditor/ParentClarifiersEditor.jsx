import React, { useEffect, useMemo, useState } from 'react';
import { ClarifierForm } from './ClarifierForm.jsx';
import { generateClarifierId } from '../../../utils/idFactory.js';
import { saveJSON } from '../../../services/parentApiService.js';

export function ParentClarifiersEditor({
  subjectId,
  subjectFolder,
  topicFolder,
  topicPages = [],
  embedded = false,
  clarifiers: controlledClarifiers,
  onClarifiersChange,
  pageSlug,
  onSave: onEmbeddedSave,
}) {
  const [selectedPageId, setSelectedPageId] = useState(topicPages[0]?.id || null);
  const pageObj = useMemo(() => topicPages.find((p) => p.id === selectedPageId), [topicPages, selectedPageId]);
  const derivedPageSlug = pageObj?.file?.split('/').pop().replace('.json', '') || pageSlug || selectedPageId;
  const initialClarifiers = embedded ? (controlledClarifiers || []) : (pageObj?._fullData?.clarifiers || []);

  const [clarifiers, setClarifiers] = useState(initialClarifiers);
  const [selectedId, setSelectedId] = useState(null);

  useEffect(() => {
    setClarifiers(initialClarifiers);
  }, [initialClarifiers]);

  const persist = async (updatedClarifiers) => {
    if (embedded) {
      onClarifiersChange?.(updatedClarifiers);
      onEmbeddedSave?.(updatedClarifiers);
      return;
    }
    if (!pageObj) return;
    const updatedPage = { ...pageObj._fullData, clarifiers: updatedClarifiers };
    const folder = subjectFolder || subjectId;
    await saveJSON(`${folder}/${topicFolder}/pages/${derivedPageSlug}.json`, updatedPage);
    alert('Clarifiers saved!');
  };

  const handleAdd = () => {
    const newId = generateClarifierId(derivedPageSlug, clarifiers.length + 1);
    const newC = { id: newId, type: 'tip', title: 'New Helper Note', body: '' };
    const next = [...clarifiers, newC];
    setClarifiers(next);
    if (embedded) onClarifiersChange?.(next);
    setSelectedId(newId);
  };

  const handleChange = (id, newClarifier) => {
    const next = clarifiers.map((c) => (c.id === id ? newClarifier : c));
    setClarifiers(next);
    if (embedded) onClarifiersChange?.(next);
  };

  const handleDelete = (id) => {
    const next = clarifiers.filter((c) => c.id !== id);
    setClarifiers(next);
    if (embedded) onClarifiersChange?.(next);
    if (selectedId === id) setSelectedId(null);
  };

  return (
    <div>
      {!embedded && (
        <div className="p-4 border-b bg-gray-50 flex items-center">
          <label className="font-bold mr-4">Select Page:</label>
          <select className="border rounded p-2" value={selectedPageId || ''} onChange={(e) => setSelectedPageId(e.target.value)}>
            {topicPages.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
          <button onClick={() => persist(clarifiers)} className="ml-auto bg-blue-600 text-white px-4 py-2 rounded font-bold">💾 Save</button>
        </div>
      )}
      <div className="flex h-[calc(100vh-220px)] border rounded bg-white overflow-hidden">
        <div className="w-1/3 border-r pr-4 flex flex-col p-4">
          <button onClick={handleAdd} className="w-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold p-2 rounded mb-4">
            + Add Helper Note
          </button>
          <div className="flex-1 overflow-y-auto space-y-2">
            {clarifiers.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedId(c.id)}
                className={`p-3 border rounded cursor-pointer ${c.id === selectedId ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
              >
                <div className="flex justify-between gap-2">
                  <div>
                    <div className="text-xs text-gray-500 font-bold uppercase">{c.type}</div>
                    <div className="text-sm font-bold">{c.title || '(Untitled)'}</div>
                  </div>
                  <button onClick={(e) => { e.stopPropagation(); handleDelete(c.id); }} className="text-xs text-red-600 border border-red-200 px-2 py-1 rounded">Delete</button>
                </div>
              </div>
            ))}
            {!clarifiers.length && <div className="text-sm text-gray-500">No helper notes yet.</div>}
          </div>
        </div>
        <div className="flex-1 p-4 overflow-y-auto flex flex-col">
          {!embedded && (
            <div className="flex justify-end mb-4">
              <button onClick={() => persist(clarifiers)} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                💾 Save Clarifiers
              </button>
            </div>
          )}
          <ClarifierForm
            clarifier={clarifiers.find((c) => c.id === selectedId)}
            onChange={handleChange}
          />
        </div>
      </div>
    </div>
  );
}
