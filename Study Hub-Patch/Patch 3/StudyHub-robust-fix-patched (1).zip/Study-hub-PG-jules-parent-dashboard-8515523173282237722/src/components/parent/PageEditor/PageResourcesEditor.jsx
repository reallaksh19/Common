import React from 'react';

function makeEmptyAttachment(kind = 'resource') {
  return {
    id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    title: '',
    description: '',
    path: '',
    kind,
    openMode: kind === 'pdf' ? 'new_tab' : 'inline',
  };
}

export function PageResourcesEditor({ attachments = [], onChange, onPickAsset }) {
  const update = (id, patch) => {
    onChange(attachments.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  };

  const remove = (id) => onChange(attachments.filter((item) => item.id !== id));

  const addAttachment = (kind) => onChange([...(attachments || []), makeEmptyAttachment(kind)]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button onClick={() => addAttachment('pdf')} className="px-3 py-2 border rounded bg-white hover:bg-gray-50 text-sm font-medium">+ PDF resource</button>
        <button onClick={() => addAttachment('image')} className="px-3 py-2 border rounded bg-white hover:bg-gray-50 text-sm font-medium">+ Image resource</button>
        <button onClick={() => addAttachment('svg')} className="px-3 py-2 border rounded bg-white hover:bg-gray-50 text-sm font-medium">+ SVG resource</button>
        <button onClick={() => addAttachment('video_link')} className="px-3 py-2 border rounded bg-white hover:bg-gray-50 text-sm font-medium">+ Video link</button>
        <button onClick={() => addAttachment('external_link')} className="px-3 py-2 border rounded bg-white hover:bg-gray-50 text-sm font-medium">+ External link</button>
      </div>

      {!attachments.length && (
        <div className="text-sm text-gray-500 border rounded p-4 bg-gray-50">
          No page resources yet. Add worksheets, diagrams, videos or links that help the child when the concept becomes difficult.
        </div>
      )}

      {attachments.map((item, index) => (
        <div key={item.id} className="border rounded-lg p-4 bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="font-semibold text-gray-800">Resource {index + 1}</div>
            <button onClick={() => remove(item.id)} className="text-sm text-red-700 border border-red-200 px-2 py-1 rounded hover:bg-red-50">Delete</button>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            <label className="text-sm font-medium text-gray-700">
              Title
              <input className="mt-1 w-full border rounded px-3 py-2" value={item.title || ''} onChange={(e) => update(item.id, { title: e.target.value })} />
            </label>
            <label className="text-sm font-medium text-gray-700">
              Kind
              <select className="mt-1 w-full border rounded px-3 py-2" value={item.kind || 'resource'} onChange={(e) => update(item.id, { kind: e.target.value })}>
                <option value="pdf">PDF</option>
                <option value="image">Image</option>
                <option value="svg">SVG</option>
                <option value="video_link">Video Link</option>
                <option value="external_link">External Link</option>
              </select>
            </label>
          </div>
          <label className="text-sm font-medium text-gray-700 block">
            Why this helps
            <textarea className="mt-1 w-full border rounded px-3 py-2 h-20" value={item.description || ''} onChange={(e) => update(item.id, { description: e.target.value })} />
          </label>
          <div className="grid md:grid-cols-[1fr_auto] gap-3 items-end">
            <label className="text-sm font-medium text-gray-700 block">
              File or URL
              <input className="mt-1 w-full border rounded px-3 py-2" value={item.path || ''} onChange={(e) => update(item.id, { path: e.target.value })} placeholder={item.kind === 'video_link' || item.kind === 'external_link' ? 'https://…' : '/Mathematics/whole-numbers/assets/…'} />
            </label>
            {onPickAsset && ['pdf', 'image', 'svg'].includes(item.kind) && (
              <button onClick={() => onPickAsset(item.id)} className="px-3 py-2 border rounded bg-indigo-50 text-indigo-700 font-medium hover:bg-indigo-100">Pick from asset library</button>
            )}
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            <label className="text-sm font-medium text-gray-700">
              Open mode
              <select className="mt-1 w-full border rounded px-3 py-2" value={item.openMode || 'new_tab'} onChange={(e) => update(item.id, { openMode: e.target.value })}>
                <option value="inline">Inline / preview</option>
                <option value="new_tab">Open in new tab</option>
              </select>
            </label>
            <div className="text-xs text-gray-500 flex items-end">
              Use resources for worksheets, Khan Academy links, NCERT PDFs, and extra diagrams that should sit below the main lesson.
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
