import React, { useEffect, useMemo, useRef, useState } from 'react';
import { deleteFile, listFiles, readJSON, saveJSON, uploadAsset } from '../../../services/parentApiService.js';

const EMPTY_MANIFEST = { assets: {} };

function inferType(name = '') {
  const ext = name.split('.').pop()?.toLowerCase();
  if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) return 'image';
  if (ext === 'svg') return 'svg';
  if (ext === 'pdf') return 'pdf';
  return 'file';
}

export function AssetLibrary({ subjectFolder, topicFolder, usageMap = {}, block, onUseAsset, onAttachAsset }) {
  const [assets, setAssets] = useState([]);
  const [manifest, setManifest] = useState(EMPTY_MANIFEST);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const uploadRef = useRef(null);
  const replaceRef = useRef(null);
  const [replaceTarget, setReplaceTarget] = useState(null);

  const manifestPath = `${subjectFolder}/${topicFolder}/assets-manifest.json`;
  const assetsDir = `${subjectFolder}/${topicFolder}/assets`;

  const loadAssets = async () => {
    setLoading(true);
    try {
      const [files, manifestData] = await Promise.all([
        listFiles(assetsDir).catch(() => []),
        readJSON(manifestPath).catch(() => EMPTY_MANIFEST),
      ]);
      setAssets(files.filter((file) => file.type === 'file'));
      setManifest(manifestData || EMPTY_MANIFEST);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAssets();
  }, [assetsDir]);

  const filteredAssets = useMemo(() => {
    const q = search.trim().toLowerCase();
    return assets.filter((asset) => {
      const tags = manifest.assets?.[asset.name]?.tags || [];
      return !q || asset.name.toLowerCase().includes(q) || tags.some((tag) => tag.toLowerCase().includes(q));
    });
  }, [assets, manifest, search]);

  const persistManifest = async (next) => {
    setManifest(next);
    await saveJSON(manifestPath, next);
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const targetPath = `${assetsDir}/${file.name}`;
    await uploadAsset(file, targetPath);
    const next = {
      ...manifest,
      assets: {
        ...(manifest.assets || {}),
        [file.name]: manifest.assets?.[file.name] || { tags: [] },
      },
    };
    await persistManifest(next);
    await loadAssets();
    e.target.value = '';
  };

  const handleReplace = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !replaceTarget) return;
    await uploadAsset(file, `${assetsDir}/${replaceTarget.name}`);
    await loadAssets();
    setReplaceTarget(null);
    e.target.value = '';
  };

  const handleDelete = async (asset) => {
    const key = asset.path;
    if ((usageMap[key] || []).length > 0) {
      alert('This asset is still used by one or more pages. Remove references before deleting it.');
      return;
    }
    await deleteFile(key);
    const nextAssets = { ...(manifest.assets || {}) };
    delete nextAssets[asset.name];
    await persistManifest({ ...manifest, assets: nextAssets });
    await loadAssets();
  };

  const updateTags = async (assetName, value) => {
    const tags = value.split(',').map((tag) => tag.trim()).filter(Boolean);
    const next = {
      ...manifest,
      assets: {
        ...(manifest.assets || {}),
        [assetName]: { ...(manifest.assets?.[assetName] || {}), tags },
      },
    };
    await persistManifest(next);
  };

  const applyAsset = (asset) => {
    const publicPath = `/${asset.path}`;
    if (!block) return;
    if (block.type === 'image') {
      onUseAsset({ src: publicPath, alt: block.data?.alt || asset.name });
    } else if (block.type === 'svg') {
      onUseAsset({ src: publicPath, caption: block.data?.caption || asset.name });
    } else if (block.type === 'pdf_embed') {
      onUseAsset({ src: publicPath, title: block.data?.title || asset.name });
    } else if (block.type === 'image_link') {
      onUseAsset({ src: publicPath, alt: block.data?.alt || asset.name });
    } else if (block.type === 'link_card') {
      onUseAsset({ url: publicPath, title: block.data?.title || asset.name, linkType: inferType(asset.name) === 'pdf' ? 'pdf' : 'external' });
    }
  };

  return (
    <div className="mt-6 border-t pt-4">
      <div className="flex items-center justify-between gap-2 mb-3">
        <h4 className="font-bold text-sm uppercase text-gray-600">Topic Asset Library</h4>
        <button onClick={() => uploadRef.current?.click()} className="text-sm bg-indigo-600 text-white px-3 py-1 rounded">Upload</button>
        <input ref={uploadRef} type="file" className="hidden" onChange={handleUpload} />
        <input ref={replaceRef} type="file" className="hidden" onChange={handleReplace} />
      </div>
      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by file name or tag" className="w-full border rounded px-2 py-1 mb-3 text-sm" />
      {loading && <div className="text-sm text-gray-500">Loading assets…</div>}
      <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
        {filteredAssets.map((asset) => {
          const usageKey = asset.path;
          const usage = usageMap[usageKey] || [];
          const type = inferType(asset.name);
          const tags = manifest.assets?.[asset.name]?.tags || [];
          const publicPath = `/${asset.path}`;
          return (
            <div key={asset.name} className="border rounded p-3 bg-gray-50">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-medium text-sm break-all">{asset.name}</div>
                  <div className="text-xs text-gray-500">{type.toUpperCase()} · {usage.length} page reference(s)</div>
                </div>
                <div className="flex gap-2">
                  {block && ['image', 'svg', 'pdf_embed', 'image_link', 'link_card'].includes(block.type) && (
                    <button onClick={() => applyAsset(asset)} className="text-xs bg-blue-600 text-white px-2 py-1 rounded">Use in block</button>
                  )}
                  {onAttachAsset && (
                    <button onClick={() => onAttachAsset(asset)} className="text-xs bg-emerald-600 text-white px-2 py-1 rounded">Attach to page</button>
                  )}
                  <button onClick={() => { setReplaceTarget(asset); replaceRef.current?.click(); }} className="text-xs border px-2 py-1 rounded">Replace</button>
                  <button onClick={() => handleDelete(asset)} className="text-xs border border-red-300 text-red-700 px-2 py-1 rounded">Delete</button>
                </div>
              </div>
              {['image', 'svg'].includes(type) ? (
                <img src={publicPath} alt={asset.name} className="mt-2 max-h-24 rounded border bg-white" />
              ) : (
                <div className="mt-2 text-xs text-gray-600">Preview unavailable in panel.</div>
              )}
              <div className="mt-2 text-xs text-gray-600">
                Used in: {usage.length ? usage.map((entry) => entry.title).join(', ') : 'Not used yet'}
              </div>
              <input
                type="text"
                className="mt-2 w-full border rounded px-2 py-1 text-xs"
                placeholder="Tags (comma separated)"
                defaultValue={tags.join(', ')}
                onBlur={(e) => updateTags(asset.name, e.target.value)}
              />
            </div>
          );
        })}
        {!filteredAssets.length && !loading && <div className="text-sm text-gray-500">No assets yet.</div>}
      </div>
    </div>
  );
}
