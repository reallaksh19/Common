import React, { useMemo, useState, useEffect } from 'react';
import { BlockList } from './PageEditor/BlockList.jsx';
import { BlockEditorPanel } from './PageEditor/BlockEditorPanel.jsx';
import { BlockToolbar } from './PageEditor/BlockToolbar.jsx';
import { AssetLibrary } from './PageEditor/AssetLibrary.jsx';
import { PageResourcesEditor } from './PageEditor/PageResourcesEditor.jsx';
import { ParentClarifiersEditor } from './ClarifierEditor/ParentClarifiersEditor.jsx';
import { ParentQuestionsEditor } from './QuestionEditor/ParentQuestionsEditor.jsx';
import { generateBlockId } from '../../utils/idFactory.js';
import { getHistory, readJSON, restoreVersion, saveJSON } from '../../services/parentApiService.js';
import { computeAssetUsageMap } from '../../utils/assetUsage.js';
import { markTopicDraft, markTopicPublished, getTopicStatus, formatRelativeTime } from '../../services/topicStateService.js';

const EMPTY_PAGE = (subjectId, topicFolder, pageSlug) => ({
  id: `${subjectId}-${topicFolder}-${pageSlug}`,
  topicId: `${subjectId}-${topicFolder}`,
  title: pageSlug,
  blocks: [],
  clarifiers: [],
  questions: [],
  attachments: [],
});

const TABS = [
  { id: 'lesson', label: 'Lesson' },
  { id: 'help', label: 'Help notes' },
  { id: 'practice', label: 'Practice' },
  { id: 'resources', label: 'Resources' },
];

export function ParentPageEditor({ subjectId, subjectFolder, topicFolder, pageSlug, topicPages = [], topicTitle = '' }) {
  const [pageData, setPageData] = useState(EMPTY_PAGE(subjectId, topicFolder, pageSlug));
  const [selectedId, setSelectedId] = useState(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [historyEntries, setHistoryEntries] = useState([]);
  const [topicPagesData, setTopicPagesData] = useState(topicPages);
  const [activeTab, setActiveTab] = useState('lesson');

  const topicKey = `${subjectId}/${topicFolder}`;
  const draftKey = `parent_draft__${subjectId}__${topicFolder}__${pageSlug}`;
  const filePath = `${subjectFolder}/${topicFolder}/pages/${pageSlug}.json`;

  const usageMap = useMemo(
    () => computeAssetUsageMap(topicPagesData, `${subjectFolder}/${topicFolder}/assets/`),
    [topicPagesData, subjectFolder, topicFolder]
  );
  const status = getTopicStatus(topicKey);

  const blocks = pageData.blocks || [];
  const clarifiers = pageData.clarifiers || [];
  const questions = pageData.questions || [];
  const attachments = pageData.attachments || [];

  const reloadHistory = async () => {
    setHistoryEntries(await getHistory(filePath).catch(() => []));
  };

  const reloadTopicPages = async () => {
    try {
      const topicData = await readJSON(`${subjectFolder}/${topicFolder}/topic.json`);
      const detailed = await Promise.all(
        (topicData.pages || []).map(async (pageRef) => ({
          ...pageRef,
          _fullData: await readJSON(`${subjectFolder}/${topicFolder}/${pageRef.file}`).catch(() => null),
        }))
      );
      setTopicPagesData(detailed.filter((page) => page._fullData));
    } catch {
      setTopicPagesData(topicPages);
    }
  };

  useEffect(() => {
    async function load() {
      const draftStr = localStorage.getItem(draftKey);
      let draftData = null;
      if (draftStr) {
        try {
          draftData = JSON.parse(draftStr);
        } catch {}
      }

      try {
        const fileData = await readJSON(filePath);
        if (draftData && JSON.stringify(draftData) !== JSON.stringify(fileData)) {
          if (window.confirm('Restore unsaved draft?')) {
            setPageData({ ...EMPTY_PAGE(subjectId, topicFolder, pageSlug), ...draftData });
            setHasUnsavedChanges(true);
          } else {
            setPageData({ ...EMPTY_PAGE(subjectId, topicFolder, pageSlug), ...fileData });
            localStorage.removeItem(draftKey);
          }
        } else {
          setPageData({ ...EMPTY_PAGE(subjectId, topicFolder, pageSlug), ...fileData });
        }
      } catch {
        if (draftData) {
          setPageData({ ...EMPTY_PAGE(subjectId, topicFolder, pageSlug), ...draftData });
          setHasUnsavedChanges(true);
        }
      }
      reloadHistory();
      reloadTopicPages();
    }
    load();
  }, [filePath, draftKey, subjectId, topicFolder, pageSlug]);

  useEffect(() => {
    if (!hasUnsavedChanges) return undefined;
    const timer = setInterval(() => {
      localStorage.setItem(draftKey, JSON.stringify(pageData));
      markTopicDraft(topicKey);
    }, 10000);
    return () => clearInterval(timer);
  }, [pageData, hasUnsavedChanges, draftKey, topicKey]);

  const mutatePage = (updater) => {
    setPageData((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      return next;
    });
    setHasUnsavedChanges(true);
    markTopicDraft(topicKey);
  };

  const handleSave = async () => {
    try {
      const existing = await readJSON(filePath).catch(() => EMPTY_PAGE(subjectId, topicFolder, pageSlug));
      const merged = {
        ...existing,
        ...pageData,
        blocks,
        clarifiers,
        questions,
        attachments,
      };
      await saveJSON(filePath, merged);
      setPageData(merged);
      setHasUnsavedChanges(false);
      localStorage.removeItem(draftKey);
      markTopicPublished(topicKey);
      await reloadHistory();
      await reloadTopicPages();
      alert('Saved!');
    } catch (err) {
      alert(err.message || 'Failed to save');
    }
  };

  const handleAddBlock = (type) => {
    const id = generateBlockId(pageSlug, blocks.length + 1);
    const defaults = type === 'video_embed'
      ? { url: '', title: 'Video explanation', caption: '', height: 360 }
      : type === 'pdf_embed'
        ? { src: '', title: 'Worksheet PDF', height: 600 }
        : {};
    const newBlock = { id, type, data: defaults };
    const idx = blocks.findIndex((b) => b.id === selectedId);
    const newBlocks = [...blocks];
    if (idx >= 0) newBlocks.splice(idx + 1, 0, newBlock);
    else newBlocks.push(newBlock);
    mutatePage((prev) => ({ ...prev, blocks: newBlocks }));
    setSelectedId(id);
    if (!['lesson'].includes(activeTab)) setActiveTab('lesson');
  };

  const handleBlockChange = (id, newData) => {
    mutatePage((prev) => ({
      ...prev,
      blocks: (prev.blocks || []).map((b) => (b.id === id ? { ...b, data: newData } : b)),
    }));
  };

  const handleReorder = (oldIndex, newIndex) => {
    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(oldIndex, 1);
    newBlocks.splice(newIndex, 0, moved);
    mutatePage((prev) => ({ ...prev, blocks: newBlocks }));
  };

  const handleDeleteBlock = (id) => {
    mutatePage((prev) => ({ ...prev, blocks: (prev.blocks || []).filter((b) => b.id !== id) }));
    if (selectedId === id) setSelectedId(null);
  };

  const handleDuplicate = (id) => {
    const block = blocks.find((b) => b.id === id);
    if (!block) return;
    const newId = generateBlockId(pageSlug, blocks.length + 1);
    const newBlock = { ...block, id: newId, data: JSON.parse(JSON.stringify(block.data)) };
    const idx = blocks.findIndex((b) => b.id === id);
    const newBlocks = [...blocks];
    newBlocks.splice(idx + 1, 0, newBlock);
    mutatePage((prev) => ({ ...prev, blocks: newBlocks }));
    setSelectedId(newId);
  };

  const selectedBlock = blocks.find((b) => b.id === selectedId);

  const handleRestoreVersion = async (versionName) => {
    if (!window.confirm('Restore this previous version? Current file will be snapshotted before restore.')) return;
    await restoreVersion(filePath, versionName);
    const restored = await readJSON(filePath);
    setPageData({ ...EMPTY_PAGE(subjectId, topicFolder, pageSlug), ...restored });
    setHasUnsavedChanges(false);
    localStorage.removeItem(draftKey);
    markTopicPublished(topicKey);
    await reloadHistory();
    await reloadTopicPages();
  };

  const attachAssetToPage = (asset) => {
    const path = `/${asset.path}`;
    const kind = asset.name.toLowerCase().endsWith('.pdf') ? 'pdf' : asset.name.toLowerCase().endsWith('.svg') ? 'svg' : 'image';
    mutatePage((prev) => ({
      ...prev,
      attachments: [
        ...(prev.attachments || []),
        {
          id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          title: asset.name,
          description: '',
          path,
          kind,
          openMode: kind === 'pdf' ? 'new_tab' : 'inline',
        },
      ],
    }));
    setActiveTab('resources');
  };

  const counts = {
    lesson: blocks.length,
    help: clarifiers.length,
    practice: questions.length,
    resources: attachments.length,
  };

  return (
    <div className="flex h-[calc(100vh-80px)] gap-4">
      <div className="w-72 border-r pr-4 flex flex-col h-full">
        <div className="mb-4 flex flex-wrap gap-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-2 rounded text-sm font-medium ${activeTab === tab.id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
            >
              {tab.label} <span className="ml-1 text-xs opacity-80">{counts[tab.id]}</span>
            </button>
          ))}
        </div>

        {activeTab === 'lesson' ? (
          <>
            <div className="mb-4">
              <BlockToolbar onAddBlock={handleAddBlock} />
            </div>
            <div className="flex-1 overflow-y-auto">
              <BlockList
                blocks={blocks}
                selectedId={selectedId}
                onSelect={setSelectedId}
                onReorder={handleReorder}
                onDuplicate={handleDuplicate}
                onDelete={handleDeleteBlock}
              />
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto text-sm text-gray-600 border rounded p-4 bg-gray-50">
            {activeTab === 'help' && 'Add clarifiers, memory tips, warnings and concept helpers based on how the kid is performing.'}
            {activeTab === 'practice' && 'Create quick checks, practice problems and help cards for weak areas.'}
            {activeTab === 'resources' && 'Attach worksheets, NCERT PDFs, Khan Academy links and reference diagrams to this page.'}
          </div>
        )}
      </div>

      <div className="flex-1 pl-2 flex flex-col h-full overflow-y-auto">
        <div className="flex justify-between items-center mb-4 pb-2 border-b sticky top-0 bg-white z-10">
          <div>
            <div className="text-gray-800 font-bold">{topicTitle || topicFolder} / {pageData.title || pageSlug}</div>
            <div className="text-xs text-gray-500">
              Draft: {status.hasDraft ? formatRelativeTime(status.draftSavedAt) : 'none'} · Published: {formatRelativeTime(status.publishedAt)} · Exported: {status.exportCount || 0} time(s)
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-gray-500 font-bold">
              {hasUnsavedChanges ? <span className="text-amber-500">● Unsaved changes</span> : 'All changes saved'}
            </div>
            <button onClick={handleSave} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
              💾 Save Page
            </button>
          </div>
        </div>

        {activeTab === 'lesson' && (
          <>
            <label className="text-sm font-medium text-gray-700 mb-3 block">
              Page title
              <input className="mt-1 w-full border rounded px-3 py-2" value={pageData.title || ''} onChange={(e) => mutatePage((prev) => ({ ...prev, title: e.target.value }))} />
            </label>
            <BlockEditorPanel block={selectedBlock} onChange={handleBlockChange} />
            <AssetLibrary
              subjectFolder={subjectFolder}
              topicFolder={topicFolder}
              usageMap={usageMap}
              block={selectedBlock}
              onUseAsset={(patch) => selectedBlock && handleBlockChange(selectedBlock.id, { ...selectedBlock.data, ...patch })}
              onAttachAsset={attachAssetToPage}
            />
          </>
        )}

        {activeTab === 'help' && (
          <ParentClarifiersEditor
            embedded
            clarifiers={clarifiers}
            onClarifiersChange={(next) => mutatePage((prev) => ({ ...prev, clarifiers: next }))}
            pageSlug={pageSlug}
          />
        )}

        {activeTab === 'practice' && (
          <ParentQuestionsEditor
            embedded
            pageSlug={pageSlug}
            questions={questions}
            onQuestionsChange={(next) => mutatePage((prev) => ({ ...prev, questions: next }))}
            pageBlocks={blocks}
            pageClarifiers={clarifiers}
          />
        )}

        {activeTab === 'resources' && (
          <>
            <PageResourcesEditor
              attachments={attachments}
              onChange={(next) => mutatePage((prev) => ({ ...prev, attachments: next }))}
              onPickAsset={(attachmentId) => {
                const asset = window.prompt('Type the asset path from the asset library list below, or use “Attach to page” inside the library.');
                if (!asset) return;
                mutatePage((prev) => ({
                  ...prev,
                  attachments: (prev.attachments || []).map((item) => item.id === attachmentId ? { ...item, path: asset.startsWith('/') ? asset : `/${asset}` } : item),
                }));
              }}
            />
            <AssetLibrary
              subjectFolder={subjectFolder}
              topicFolder={topicFolder}
              usageMap={usageMap}
              onAttachAsset={attachAssetToPage}
            />
          </>
        )}
      </div>

      <div className="w-80 border-l pl-4 overflow-y-auto">
        <h4 className="font-bold text-sm uppercase text-gray-600 mb-3">Version History</h4>
        <div className="space-y-2">
          {historyEntries.map((entry) => (
            <div key={entry.name} className="border rounded p-3 bg-gray-50">
              <div className="text-sm font-medium break-all">{entry.name}</div>
              <button onClick={() => handleRestoreVersion(entry.name)} className="mt-2 text-xs bg-white border px-2 py-1 rounded">Restore</button>
            </div>
          ))}
          {!historyEntries.length && <div className="text-sm text-gray-500">No prior versions yet.</div>}
        </div>
      </div>
    </div>
  );
}
