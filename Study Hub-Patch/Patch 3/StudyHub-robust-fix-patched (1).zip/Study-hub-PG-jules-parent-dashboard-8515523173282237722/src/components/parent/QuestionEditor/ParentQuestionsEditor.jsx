import React, { useEffect, useState } from 'react';
import { QuestionForm } from './QuestionForm.jsx';
import { generateQuestionId } from '../../../utils/idFactory.js';

export function ParentQuestionsEditor({
  pageSlug,
  initialQuestions = [],
  pageBlocks = [],
  pageClarifiers = [],
  onSave,
  embedded = false,
  questions: controlledQuestions,
  onQuestionsChange,
  presets = true,
}) {
  const [internalQuestions, setInternalQuestions] = useState(initialQuestions);
  const [selectedId, setSelectedId] = useState(null);

  const questions = embedded ? (controlledQuestions || []) : internalQuestions;
  const setQuestions = embedded ? (onQuestionsChange || (() => {})) : setInternalQuestions;

  useEffect(() => {
    if (!embedded) setInternalQuestions(initialQuestions || []);
  }, [embedded, initialQuestions]);

  const addQuestion = (partial = {}) => {
    const newId = generateQuestionId(pageSlug, questions.length + 1);
    const newQ = {
      id: newId,
      type: partial.type || 'mcq',
      prompt: partial.prompt || '',
      options: partial.options,
      answer: partial.answer,
      explanation: partial.explanation,
      modelAnswer: partial.modelAnswer,
      hint: partial.hint,
      supportClarifierIds: partial.supportClarifierIds,
      supportBlockIds: partial.supportBlockIds,
      embedContent: partial.embedContent,
      externalLink: partial.externalLink,
    };
    setQuestions([...(questions || []), newQ]);
    setSelectedId(newId);
  };

  const handleChange = (id, newQuestion) => {
    setQuestions((questions || []).map((q) => (q.id === id ? newQuestion : q)));
  };

  const handleDelete = (id) => {
    setQuestions((questions || []).filter((q) => q.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const handleSave = () => {
    if (onSave) onSave(questions);
  };

  const presetButtons = [
    {
      label: 'Quick check',
      partial: { type: 'mcq', prompt: 'Quick check question', options: ['', '', '', ''], answer: 0, explanation: '' },
    },
    {
      label: 'Explain in words',
      partial: { type: 'short_answer', prompt: 'Explain the idea in your own words', modelAnswer: '' },
    },
    {
      label: 'Practice problem',
      partial: { type: 'numeric', prompt: 'Solve the problem', answer: 0, tolerance: 0 },
    },
    {
      label: 'Help card',
      partial: { type: 'concept_strengthener', prompt: 'Read and strengthen the concept', embedContent: '', externalLink: '' },
    },
  ];

  return (
    <div className="flex h-[calc(100vh-220px)] border rounded bg-white overflow-hidden">
      <div className="w-1/3 border-r pr-4 flex flex-col p-4">
        <button onClick={() => addQuestion()} className="w-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold p-2 rounded mb-3">
          + Add Question
        </button>
        {presets && (
          <div className="grid grid-cols-2 gap-2 mb-4">
            {presetButtons.map((preset) => (
              <button key={preset.label} onClick={() => addQuestion(preset.partial)} className="text-xs border rounded px-2 py-2 bg-gray-50 hover:bg-gray-100">
                {preset.label}
              </button>
            ))}
          </div>
        )}
        {!embedded && (
          <button onClick={handleSave} className="w-full bg-blue-600 text-white font-bold p-2 rounded mb-4">
            💾 Save
          </button>
        )}
        <div className="flex-1 overflow-y-auto space-y-2">
          {(questions || []).map((q) => (
            <div
              key={q.id}
              onClick={() => setSelectedId(q.id)}
              className={`p-3 border rounded cursor-pointer ${q.id === selectedId ? 'border-indigo-500 bg-indigo-50' : 'hover:bg-gray-50'}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs text-gray-500 font-bold uppercase">{q.type}</div>
                  <div className="text-sm truncate">{q.prompt || '(Empty prompt)'}</div>
                </div>
                <button onClick={(e) => { e.stopPropagation(); handleDelete(q.id); }} className="text-xs text-red-600 border border-red-200 px-2 py-1 rounded">Delete</button>
              </div>
            </div>
          ))}
          {!questions?.length && <div className="text-sm text-gray-500">No practice items yet.</div>}
        </div>
      </div>
      <div className="flex-1 p-4 overflow-y-auto flex flex-col">
        {!embedded && (
          <div className="flex justify-end mb-4">
            <button onClick={handleSave} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
              💾 Save Questions
            </button>
          </div>
        )}
        <QuestionForm
          question={(questions || []).find((q) => q.id === selectedId)}
          pageBlocks={pageBlocks}
          pageClarifiers={pageClarifiers}
          onChange={handleChange}
        />
      </div>
    </div>
  );
}
