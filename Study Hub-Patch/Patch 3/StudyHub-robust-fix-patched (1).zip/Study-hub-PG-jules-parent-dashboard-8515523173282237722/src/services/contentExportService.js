import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { loadTopicWithPages } from './jsonContentService.js';
import { markTopicExported } from './topicStateService.js';

function collectAssetPaths(topic) {
  const assets = new Set();
  const pages = topic?._fullPages || [];
  pages.forEach((pageRef) => {
    const page = pageRef?._fullData;
    if (!page) return;
    (page.blocks || []).forEach((block) => {
      ['src', 'url', 'href'].forEach((field) => {
        const value = block?.data?.[field];
        if (typeof value === 'string' && /\/assets\//i.test(value)) assets.add(value);
      });
    });
    (page.attachments || []).forEach((att) => {
      if (typeof att?.path === 'string' && /\/assets\//i.test(att.path)) assets.add(att.path);
    });
  });
  if (typeof topic.coverAssetPath === 'string' && /\/assets\//i.test(topic.coverAssetPath)) assets.add(topic.coverAssetPath);
  return [...assets];
}

async function addAssetFile(zip, assetPath) {
  const normalized = assetPath.startsWith('/') ? assetPath : `/${assetPath}`;
  const response = await fetch(normalized);
  if (!response.ok) return false;
  const blob = await response.blob();
  zip.file(normalized.replace(/^\//, ''), blob);
  return true;
}

export async function exportPack(subjects, topics) {
  const pack = {
    version: 2,
    topics: [],
    pages: {},
  };

  const zip = new JSZip();

  for (const topicMeta of topics) {
    if (topicMeta.source !== 'json') continue;
    const topic = await loadTopicWithPages(topicMeta.folderSubject || topicMeta.subjectFolder || topicMeta._subjectFolder || topicMeta.subject || topicMeta.subjectId, topicMeta.folder || topicMeta.id.replace(`${topicMeta.subjectId}-`, ''));
    if (!topic) continue;

    const exportTopic = { ...topic };
    delete exportTopic._fullPages;
    delete exportTopic.source;
    exportTopic.folder = topicMeta.folder || topic.folder;
    pack.topics.push(exportTopic);

    for (const page of topic._fullPages || []) {
      if (page._fullData) {
        pack.pages[page.id] = page._fullData;
      }
    }

    const assetPaths = collectAssetPaths(topic);
    for (const assetPath of assetPaths) {
      await addAssetFile(zip, assetPath);
    }

    const topicKey = `${topic.subjectId}/${topicMeta.folder || topic.folder}`;
    markTopicExported(topicKey);
  }

  zip.file('content-pack.json', JSON.stringify(pack, null, 2));
  const manifest = {
    schemaVersion: '2.0',
    exportedAt: new Date().toISOString(),
    topicCount: pack.topics.length,
    pageCount: Object.keys(pack.pages).length,
  };
  zip.file('manifest.json', JSON.stringify(manifest, null, 2));

  const blob = await zip.generateAsync({ type: 'blob' });
  saveAs(blob, 'content-pack.zip');
}
