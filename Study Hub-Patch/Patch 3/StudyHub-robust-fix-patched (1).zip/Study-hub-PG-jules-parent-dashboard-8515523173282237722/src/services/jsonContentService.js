import { getCandidatePageFiles, extractPageSlug, buildPageFile } from '../utils/contentPaths.js';

export async function loadTopic(subject, topicFolder) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/topic.json`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading topic.json for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

export async function loadPage(subject, topicFolder, pageFile) {
  try {
    const res = await fetch(`/${subject}/${topicFolder}/${pageFile}`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Error loading ${pageFile} for ${subject}/${topicFolder}:`, err);
    return null;
  }
}

async function loadBestPage(subject, topicFolder, topic, pageRef) {
  const candidates = getCandidatePageFiles({ ...pageRef, topicId: topic?.id });
  for (const candidate of candidates) {
    const pageData = await loadPage(subject, topicFolder, candidate);
    if (pageData) {
      return {
        ...pageRef,
        file: candidate,
        slug: extractPageSlug({ ...pageRef, file: candidate, topicId: topic?.id }),
        _fullData: pageData,
      };
    }
  }

  const fallbackSlug = extractPageSlug({ ...pageRef, topicId: topic?.id });
  return {
    ...pageRef,
    file: pageRef.file || buildPageFile(fallbackSlug),
    slug: fallbackSlug,
    _fullData: null,
  };
}

export async function loadTopicWithPages(subject, topicFolder) {
  const topic = await loadTopic(subject, topicFolder);
  if (!topic) return null;

  const fullPages = await Promise.all(
    (topic.pages || []).map((pageRef) => loadBestPage(subject, topicFolder, topic, pageRef))
  );

  const normalizedPages = fullPages.map((page) => ({
    ...page,
    id: page.id || page._fullData?.id || `${topic.id}-${page.slug}`,
    title: page.title || page._fullData?.title || page.slug,
  }));

  return {
    ...topic,
    folder: topicFolder,
    _subjectFolder: subject,
    _fullPages: normalizedPages,
    pages: normalizedPages.map(({ _fullData, slug, ...meta }) => ({ ...meta })),
    source: 'json',
  };
}
