import re

with open('js/pro2dcanvas/Pro2D_PropertyPanel.tsx', 'r') as f:
    content = f.read()

# Fix the Array.from in useSceneStore that causes infinite loop in React 19
content = content.replace("const selectedIds = useSceneStore((state) => Array.from(state.selectedIds));", "const selectedIdsSet = useSceneStore((state) => state.selectedIds);\n  const selectedIds = Array.from(selectedIdsSet);")

with open('js/pro2dcanvas/Pro2D_PropertyPanel.tsx', 'w') as f:
    f.write(content)
