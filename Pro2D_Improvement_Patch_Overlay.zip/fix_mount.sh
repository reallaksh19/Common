sed -i 's|../../js/smart2dcanvas/Smart2Dcanvas_AppShell.tsx|../../js/pro2dcanvas/Pro2D_AppShell.tsx|g' js/coord2pcf/coord2pcf-tab.js
sed -i 's|Smart2Dcanvas_AppShell|Pro2D_AppShell|g' js/coord2pcf/coord2pcf-tab.js
sed -i 's|c2p-smart2d-mount|c2p-pro2d-mount|g' js/coord2pcf/coord2pcf-tab.js
sed -i 's|c2p-smart2d-mount|c2p-pro2d-mount|g' index.html
