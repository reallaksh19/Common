import React, { useState } from 'react';

type OpsProps = {
  inputSnapshot: any;
  pipelineMetrics: any;
  onAction: (actionId: string) => void;
};

const tabButton = (active: boolean) => `px-3 py-1.5 rounded-md border text-xs ${active ? 'border-amber-500 bg-amber-500/10 text-amber-200' : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500'}`;

const block = 'rounded border border-slate-800 bg-slate-900/60 p-2 space-y-2';
const actionBtn = 'rounded border border-slate-700 bg-slate-900 hover:border-amber-500 hover:text-amber-200 px-2 py-1 text-xs';

const Pro2D_CoorOpsPanel: React.FC<OpsProps> = ({ inputSnapshot, pipelineMetrics, onAction }) => {
  const [activeTab, setActiveTab] = useState<'route'|'emit'|'fittings'|'pcf'>('route');
  return (
    <div className="p-3 border-t border-slate-800 text-xs text-slate-300 bg-slate-950 space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-wide text-amber-400">CoorCanvas / Coor2PCF operator ribbon</div>
          <div className="text-[11px] text-slate-500">Dedicated route, emit, fittings, and PCF options surfaced inside Pro 2D.</div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button className={tabButton(activeTab === 'route')} onClick={() => setActiveTab('route')}>Route</button>
          <button className={tabButton(activeTab === 'emit')} onClick={() => setActiveTab('emit')}>Emit</button>
          <button className={tabButton(activeTab === 'fittings')} onClick={() => setActiveTab('fittings')}>Fittings</button>
          <button className={tabButton(activeTab === 'pcf')} onClick={() => setActiveTab('pcf')}>PCF</button>
        </div>
      </div>
      {activeTab === 'route' && (
        <div className="grid grid-cols-3 gap-3">
          <div className={block}>
            <div className="font-semibold text-slate-200">Imported route snapshot</div>
            <div>Runs: {inputSnapshot?.parsedRuns?.length || 0}</div>
            <div>Support points: {inputSnapshot?.supportPoints?.length || 0}</div>
            <div>Canvas fittings: {inputSnapshot?.canvasFittings?.length || 0}</div>
            <div>Bore: {inputSnapshot?.options?.bore || 250}</div>
            <div>Pipeline Ref: {inputSnapshot?.options?.pipelineRef || '—'}</div>
          </div>
          <div className={block}>
            <div className="font-semibold text-slate-200">Route actions</div>
            <div className="flex gap-2 flex-wrap">
              <button className={actionBtn} onClick={() => onAction('pullInput')}>Pull Input</button>
              <button className={actionBtn} onClick={() => onAction('validate')}>Validate Route</button>
              <button className={actionBtn} onClick={() => onAction('benchmark')}>Run Bench</button>
            </div>
            <div className="text-slate-500">Use this panel to refresh route state from Coord2PCF and rerun validation/benchmarks.</div>
          </div>
          <div className={block}>
            <div className="font-semibold text-slate-200">Route metrics</div>
            <div>Route points: {pipelineMetrics?.routePointCount || 0}</div>
            <div>Final elements: {pipelineMetrics?.finalElementCount || 0}</div>
            <div>Auto supports: {pipelineMetrics?.autoSupportCount || 0}</div>
          </div>
        </div>
      )}
      {activeTab === 'emit' && (
        <div className="grid grid-cols-2 gap-3">
          <div className={block}>
            <div className="font-semibold text-slate-200">Emit operators</div>
            <div className="flex gap-2 flex-wrap">
              <button className={actionBtn} onClick={() => onAction('emitCuts')}>Run Emit Cuts</button>
              <button className={actionBtn} onClick={() => onAction('autoSupports')}>Auto Supports</button>
            </div>
            <div className="text-slate-500">Runs the imported CoorCanvas emit/support pipeline and updates the metrics dock.</div>
          </div>
          <div className={block}>
            <div className="font-semibold text-slate-200">Emit metrics</div>
            <div>Emit count: {pipelineMetrics?.emitCount || 0}</div>
            <div>Auto supports: {pipelineMetrics?.autoSupportCount || 0}</div>
            <div>Final elements: {pipelineMetrics?.finalElementCount || 0}</div>
          </div>
        </div>
      )}
      {activeTab === 'fittings' && (
        <div className="grid grid-cols-2 gap-3">
          <div className={block}>
            <div className="font-semibold text-slate-200">Fitting quick-insert tools</div>
            <div className="flex gap-2 flex-wrap">
              <button className={actionBtn} onClick={() => onAction('tool_valve')}>Valve</button>
              <button className={actionBtn} onClick={() => onAction('tool_flange')}>Flange</button>
              <button className={actionBtn} onClick={() => onAction('tool_fvf')}>FVF</button>
              <button className={actionBtn} onClick={() => onAction('tool_reducer')}>Reducer</button>
              <button className={actionBtn} onClick={() => onAction('tool_support')}>Support</button>
            </div>
            <div className="text-slate-500">These map directly to the existing viewport insertion tools and make CoorCanvas fitting workflows explicit.</div>
          </div>
          <div className={block}>
            <div className="font-semibold text-slate-200">Planned but not wired yet</div>
            <div className="flex gap-2 flex-wrap">
              <button className={actionBtn} onClick={() => onAction('tool_bend')}>Bend</button>
              <button className={actionBtn} onClick={() => onAction('tool_tee')}>Tee</button>
            </div>
            <div className="text-slate-500">These stay visible so the operator surface matches the work instruction, but the command path still needs canonical insert handlers.</div>
          </div>
        </div>
      )}
      {activeTab === 'pcf' && (
        <div className="grid grid-cols-2 gap-3">
          <div className={block}>
            <div className="font-semibold text-slate-200">PCF interop</div>
            <div className="flex gap-2 flex-wrap">
              <button className={actionBtn} onClick={() => onAction('routeToPcf')}>Route → PCF</button>
              <button className={actionBtn} onClick={() => onAction('exportDxf')}>Export DXF</button>
              <button className={actionBtn} onClick={() => onAction('exportSvg')}>Export SVG</button>
            </div>
            <div className="text-slate-500">Keeps PCF conversion visible next to route/emit/fittings instead of hiding it behind a summary panel only.</div>
          </div>
          <div className={block}>
            <div className="font-semibold text-slate-200">PCF notes</div>
            <div>This patch improves operator surface and debugging. It does not replace the legacy emitter or add a full Pro2D bend/tee-to-PCF authoring workflow yet.</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Pro2D_CoorOpsPanel;
