import { Pro2D_toolMap } from './Pro2D_ToolRegistry.mjs';

const toolAction = (toolId) => ({
  id: `tool_${toolId}`,
  label: Pro2D_toolMap[toolId].label,
  icon: Pro2D_toolMap[toolId].icon,
  implemented: Pro2D_toolMap[toolId].implemented,
  note: Pro2D_toolMap[toolId].note,
});

export const Pro2D_ribbonSections = [
  {
    id: 'file',
    title: 'File',
    actions: [
      { id: 'loadMock', label: 'Mock', icon: '🧪', implemented: true },
      { id: 'pullInput', label: 'Pull Input', icon: '⟳', implemented: true },
      { id: 'validate', label: 'Validate', icon: '✔', implemented: true },
      { id: 'benchmark', label: 'Benchmark', icon: '⏱', implemented: true },
      { id: 'clear', label: 'Clear', icon: '🗑', implemented: true },
    ],
  },
  {
    id: 'draft',
    title: 'Draft',
    actions: [
      toolAction('select'),
      toolAction('marquee'),
      toolAction('measure'),
      toolAction('line'),
      toolAction('bend'),
      toolAction('tee'),
      toolAction('polyline'),
      toolAction('spline'),
      toolAction('underlay'),
    ],
  },
  {
    id: 'fittings',
    title: 'Fittings',
    actions: [
      toolAction('valve'),
      toolAction('flange'),
      toolAction('fvf'),
      toolAction('reducer'),
      toolAction('support'),
    ],
  },
  {
    id: 'repair',
    title: 'Topology / Repair',
    actions: [
      toolAction('break'),
      toolAction('connect'),
      toolAction('stretch'),
      toolAction('gapClean'),
      toolAction('overlapSolver'),
    ],
  },
  {
    id: 'interop',
    title: 'DXF / SVG / PCF',
    actions: [
      { id: 'exportSvg', label: 'SVG', icon: '🖼', implemented: true },
      { id: 'exportDxf', label: 'DXF', icon: '📐', implemented: true },
      { id: 'routeToPcf', label: 'Route→PCF', icon: '⇢', implemented: true },
      { id: 'emitCuts', label: 'Emit Cuts', icon: '⚡', implemented: true },
      { id: 'autoSupports', label: 'Auto Supports', icon: '📍', implemented: true },
      toolAction('annotations'),
      toolAction('minimap'),
    ],
  },
];
