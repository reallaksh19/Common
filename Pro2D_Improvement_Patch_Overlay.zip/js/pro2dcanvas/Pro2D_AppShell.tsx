import React, { useMemo, useState } from 'react';
import Smart2Dcanvas_CanvasViewport from '../smart2dcanvas/Smart2Dcanvas_CanvasViewport';
import Smart2Dcanvas_StatusBar from '../smart2dcanvas/Smart2Dcanvas_StatusBar';
import { useSceneStore } from '../smart2dcanvas/Smart2Dcanvas_SceneStore';
import Pro2D_Ribbon from './Pro2D_Ribbon';
import Pro2D_LeftRail from './Pro2D_LeftRail';
import Pro2D_PropertyPanel from './Pro2D_PropertyPanel';
import Pro2D_DebugDock from './Pro2D_DebugDock';
import Pro2D_CoorOpsPanel from './Pro2D_CoorOpsPanel';
import { Pro2D_buildMockState, Pro2D_fromCoord2PcfSnapshot, Pro2D_toSceneBundle, Pro2D_createEmptyState } from './Pro2D_Canonical.mjs';
import { Pro2D_validateState } from './Pro2D_ValidationEngine.mjs';
import { Pro2D_runBenchmark } from './Pro2D_Benchmark.mjs';
import { Pro2D_exportSimpleSvg } from './Pro2D_SvgAdapter.mjs';
import { Pro2D_exportSimpleDxf } from './Pro2D_DxfAdapter.mjs';
import { Pro2D_mockRoute, Pro2D_mockEmits } from './Pro2D_MockData.mjs';
import { Pro2D_runEmitPipeline } from './Pro2D_EmitEngine.mjs';
import { Pro2D_toolMap } from './Pro2D_ToolRegistry.mjs';

function pushToStore(bundle: any) {
  useSceneStore.getState().loadSceneBundle(bundle);
}

const Pro2D_AppShell: React.FC = () => {
  const [doc, setDoc] = useState<any>(() => Pro2D_createEmptyState('Pro2D Empty'));
  const [validation, setValidation] = useState<any>({ issues: [], summary: { errors: 0, warnings: 0, totalEntities: 0, totalRoutes: 0, totalNodes: 0 } });
  const [benchmark, setBenchmark] = useState<any>(null);
  const [lastSvg, setLastSvg] = useState('');
  const [lastDxf, setLastDxf] = useState('');
  const [inputSnapshot, setInputSnapshot] = useState<any>({ parsedRuns: [], supportPoints: [], canvasFittings: [], options: {} });
  const [pipelineMetrics, setPipelineMetrics] = useState<any>(null);
  const [logs, setLogs] = useState<Array<{ level: string; text: string }>>([]);
  const clearSelection = useSceneStore((state) => state.clearSelection);

  const summaryText = useMemo(() => {
    const s = validation?.summary;
    return `${s?.totalEntities ?? 0} entities · ${s?.totalNodes ?? 0} nodes · ${s?.errors ?? 0} errors · ${s?.warnings ?? 0} warnings`;
  }, [validation]);

  const addLog = (level: string, text: string) => {
    setLogs((prev) => [...prev, { level, text }].slice(-200));
  };

  const loadDoc = (nextDoc: any) => {
    const validated = Pro2D_validateState(nextDoc);
    setDoc({ ...nextDoc });
    setValidation({ ...validated });
    pushToStore(Pro2D_toSceneBundle(nextDoc));
    clearSelection();
    addLog('info', `[doc] loaded ${Object.keys(nextDoc?.entities || {}).length} entities / ${Object.keys(nextDoc?.nodes || {}).length} nodes`);
  };

  const onAction = (actionId: string) => {
    if (actionId === 'loadMock') {
      loadDoc(Pro2D_buildMockState());
      return;
    }
    if (actionId === 'pullInput') {
      const getter = (window as any).__getCoord2PcfSnapshot;
      const snapshot = typeof getter === 'function' ? getter() : {};
      setInputSnapshot(snapshot);
      loadDoc(Pro2D_fromCoord2PcfSnapshot(snapshot));
      return;
    }
    if (actionId === 'validate') {
      const result = { ...Pro2D_validateState({ ...doc }) };
      setValidation(result);
      addLog(result.summary.errors > 0 ? 'error' : 'info', `[validate] ${result.summary.errors} errors / ${result.summary.warnings} warnings`);
      return;
    }
    if (actionId === 'benchmark') {
      const result = Pro2D_runBenchmark();
      setBenchmark(result);
      addLog('info', `[benchmark] mock=${result.phase1LoadMs}ms validate=${result.phase1ValidateMs}ms 10k=${result.phase3Load10kMs}ms`);
      return;
    }
    if (actionId === 'clear') {
      loadDoc(Pro2D_createEmptyState('Pro2D Empty'));
      return;
    }
    if (actionId === 'exportSvg') {
      setLastSvg(Pro2D_exportSimpleSvg(doc));
      addLog('info', '[interop] SVG export generated');
      return;
    }
    if (actionId === 'exportDxf') {
      setLastDxf(Pro2D_exportSimpleDxf(Pro2D_toSceneBundle(doc)));
      addLog('info', '[interop] DXF export generated');
      return;
    }
    if (actionId === 'emitCuts' || actionId === 'autoSupports' || actionId === 'routeToPcf') {
      const metrics = Pro2D_runEmitPipeline({ route: Pro2D_mockRoute, bore: 250, emits: Pro2D_mockEmits }).metrics;
      setPipelineMetrics(metrics);
      addLog('info', `[pipeline:${actionId}] emits=${metrics.emitCount} supports=${metrics.autoSupportCount} elements=${metrics.finalElementCount}`);
      return;
    }
    if (actionId.startsWith('tool_')) {
      const toolId = actionId.replace('tool_', '');
      const meta: any = Pro2D_toolMap[toolId];
      if (meta?.implemented === false) {
        addLog('error', `[tool:${toolId}] ${meta.note || 'Planned, not implemented yet.'}`);
        return;
      }
      if (toolId === 'marquee') {
        useSceneStore.getState().setActiveTool('select' as any);
        addLog('info', '[tool] marquee uses select-mode drag selection in current viewport');
        return;
      }
      if (toolId === 'underlay') {
        addLog('info', '[tool] underlay is store-supported; add image action still needs UI picker wiring');
        return;
      }
      useSceneStore.getState().setActiveTool(toolId as any);
      addLog('info', `[tool] ${toolId}`);
      return;
    }
    addLog('error', `[unhandled] ${actionId} has no command implementation`);
    console.info('[Pro2D] Ribbon action invoked:', actionId);
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-950 text-slate-200">
      <Pro2D_Ribbon onAction={onAction} />
      <div className="px-3 py-2 border-b border-slate-800 bg-slate-900/80 text-xs flex items-center justify-between">
        <div>
          <span className="font-semibold text-amber-300">Pro 2D Canvas</span>
          <span className="ml-2 text-slate-400">Unified Smart2D shell + CoorCanvas operator panels + canonical state</span>
        </div>
        <div className="text-slate-300">{summaryText}</div>
      </div>
      <div className="flex min-h-0 flex-1">
        <Pro2D_LeftRail />
        <div className="flex-1 min-h-0 flex flex-col">
          <div className="flex-1 min-h-0 relative">
            <Smart2Dcanvas_CanvasViewport />
          </div>
          <Pro2D_CoorOpsPanel inputSnapshot={inputSnapshot} pipelineMetrics={pipelineMetrics} onAction={onAction} />
          {(lastSvg || lastDxf) && (
            <div className="border-t border-slate-800 bg-slate-950 text-xs grid grid-cols-2 gap-0 max-h-44 overflow-auto">
              <div className="border-r border-slate-800 p-2">
                <div className="uppercase text-[10px] tracking-wide text-cyan-400 mb-1">SVG export preview</div>
                <pre className="whitespace-pre-wrap break-all text-slate-300">{lastSvg || '—'}</pre>
              </div>
              <div className="p-2">
                <div className="uppercase text-[10px] tracking-wide text-emerald-400 mb-1">DXF export preview</div>
                <pre className="whitespace-pre-wrap break-all text-slate-300">{lastDxf || '—'}</pre>
              </div>
            </div>
          )}
          <Pro2D_DebugDock logs={logs} validation={validation} benchmark={benchmark} pipelineMetrics={pipelineMetrics} />
          <Smart2Dcanvas_StatusBar />
        </div>
        <div className="w-[360px] min-w-[360px]">
          <Pro2D_PropertyPanel doc={doc} validation={validation} />
        </div>
      </div>
    </div>
  );
};

export default Pro2D_AppShell;
