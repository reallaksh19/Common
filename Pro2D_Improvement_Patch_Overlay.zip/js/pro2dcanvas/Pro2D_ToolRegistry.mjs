export const Pro2D_toolRegistry = [
  { id: "select", label: "Select", icon: "🖱", zone: "draft", implemented: true, shortcut: "Esc" },
  { id: "marquee", label: "Marquee", icon: "▭", zone: "draft", implemented: true, note: "Uses existing select-mode marquee in the viewport." },
  { id: "measure", label: "Measure", icon: "📏", zone: "draft", implemented: false, note: "Distance overlay and measure report are not implemented yet." },
  { id: "pan", label: "Pan", icon: "✋", zone: "draft", implemented: true },
  { id: "line", label: "Pipe", icon: "／", zone: "draft", implemented: true },
  { id: "bend", label: "Bend", icon: "↷", zone: "draft", implemented: false, note: "Canonical bend insert command is not wired yet." },
  { id: "tee", label: "Tee", icon: "┬", zone: "draft", implemented: false, note: "Canonical tee insert command is not wired yet." },
  { id: "polyline", label: "Polyline", icon: "〰", zone: "draft", implemented: true },
  { id: "spline", label: "Spline", icon: "∿", zone: "draft", implemented: true },
  { id: "support", label: "Support", icon: "✚", zone: "fittings", implemented: true },
  { id: "valve", label: "Valve", icon: "◇", zone: "fittings", implemented: true },
  { id: "flange", label: "Flange", icon: "▮", zone: "fittings", implemented: true },
  { id: "fvf", label: "FVF", icon: "▮◇▮", zone: "fittings", implemented: true },
  { id: "reducer", label: "Reducer", icon: "⬘", zone: "fittings", implemented: true },
  { id: "break", label: "Break", icon: "✂", zone: "repair", implemented: false, note: "Ribbon command exists but no canonical break pipeline is wired." },
  { id: "connect", label: "Connect", icon: "⛓", zone: "repair", implemented: false, note: "No connect-endpoints command is implemented." },
  { id: "stretch", label: "Stretch", icon: "↔", zone: "repair", implemented: false, note: "No stretch-endpoint command is implemented." },
  { id: "gapClean", label: "Gap Clean", icon: "🧹", zone: "repair", implemented: false, note: "Repair placeholder only." },
  { id: "overlapSolver", label: "Overlap", icon: "🧩", zone: "repair", implemented: false, note: "Repair placeholder only." },
  { id: "underlay", label: "Underlay", icon: "🖼", zone: "interop", implemented: true, note: "Viewport supports underlay images through the store." },
  { id: "annotations", label: "Issues", icon: "💬", zone: "interop", implemented: false, note: "Annotation layer is planned, not implemented." },
  { id: "minimap", label: "Radar", icon: "🧭", zone: "interop", implemented: false, note: "No minimap/radar component is mounted yet." }
];

export const Pro2D_toolMap = Object.fromEntries(Pro2D_toolRegistry.map((tool) => [tool.id, tool]));
export function Pro2D_getToolsByZone(zone) { return Pro2D_toolRegistry.filter((tool) => tool.zone === zone); }
