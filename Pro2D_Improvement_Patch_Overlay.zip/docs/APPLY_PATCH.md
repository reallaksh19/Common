# How to apply this patch

This zip is an **overlay patch** intended for the current Pro2D session tree.

## Recommended base
Apply it on top of the current project state that already includes:
- your original `PCF Studio 2D update.zip` project
- the previously delivered Pro2D session overlay

## Apply steps
1. Extract this zip.
2. Copy the included `index.html`, `js/`, and `tests/` contents into your project root.
3. Allow overwrite when prompted.
4. Run the included tests:
   - `node tests/pro2d_patch_pass.mjs`
   - `node tests/pro2d_patch_smoke.mjs`
5. Open the app and verify:
   - Pro2D ribbon shows honest implemented/disabled tools
   - left rail shows CoorCanvas-related fitting tools
   - route / emit / fittings / pcf operator panel appears under the viewport
   - debug dock appears above the status bar

## What this patch improves immediately
- Adds a dedicated CoorCanvas / Coor2PCF operator panel
- Adds a tool registry with implemented vs planned status
- Adds a debug dock with logs / validation / performance
- Restores missing Smart2D support files required by Pro2D imports
- Makes DXF export slightly more standards-shaped for smoke testing

## What still needs future coding
- Bend / tee canonical insert commands
- Measure overlay
- Break / connect / stretch commands
- Gap clean / overlap solver logic
- Annotation layer
- Minimap/radar component
