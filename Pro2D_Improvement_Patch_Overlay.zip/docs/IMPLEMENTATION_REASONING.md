# Pro2D Improvement Patch — reasoning

This patch is an overlay on top of the previously delivered Pro2D session zip.

## Why this patch exists
The earlier delivery had three practical gaps:
1. it exposed a Pro2D shell but did not surface CoorCanvas/Coor2PCF workflows through dedicated operator panels;
2. several requested tools were visible only as placeholders, making the UI look more complete than the command implementation actually was;
3. the latest session zip was missing some Smart2D support files that Pro2D imports.

## What changed
### 1. Honest tool contract
A `Pro2D_ToolRegistry` now marks each tool as implemented or planned. Ribbon and left-rail buttons use this registry so placeholder tools are clearly disabled with reasons.

### 2. Dedicated CoorCanvas / Coor2PCF operator surface
`Pro2D_CoorOpsPanel.tsx` introduces dedicated Route / Emit / Fittings / PCF sub-panels. This is the minimal UI step required to bring CoorCanvas workflows forward into Pro2D instead of hiding them behind one summary card.

### 3. Debug-first workflow
`Pro2D_DebugDock.tsx` adds action logs, validation summaries, and performance/pipeline metrics to the mounted UI. This makes tool-click/debugging/state issues visible during integration.

### 4. Missing Smart2D support files restored
The patch includes `Smart2Dcanvas_SceneStore.ts`, `Smart2Dcanvas_GeometryTypes.ts`, and `Smart2Dcanvas_SnapEngine.ts` so the overlay is materially more implementable.

### 5. Typed property visibility
The property panel now shows header group / source badges so fixed and dynamic metadata are easier to audit.

## What this patch intentionally does not claim
- It does **not** claim that bend, tee, measure, break, connect, stretch, gap clean, overlap, annotations, or minimap are fully implemented.
- It does **not** convert the app into a production-ready static-host deployment by itself.
- It does **not** replace the legacy Coord2PCF emitter.

## Why these choices are better than pretending all tools are complete
Because the original instruction explicitly asked for auditing every icon/tool/UI/debug path. A patch that shows incomplete tools as complete makes the system harder to test and maintain. This patch moves the package toward a truthfully operable state while preserving room for later command implementation.
