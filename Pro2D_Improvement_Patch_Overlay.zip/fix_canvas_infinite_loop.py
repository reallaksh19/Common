import re

with open('js/smart2dcanvas/Smart2Dcanvas_CanvasViewport.tsx', 'r') as f:
    content = f.read()

content = content.replace("const [isOrtho, isOsnap] = useSceneStore((state) => [state.isOrtho, state.isOsnap]);", "const isOrtho = useSceneStore((state) => state.isOrtho);\n  const isOsnap = useSceneStore((state) => state.isOsnap);")

with open('js/smart2dcanvas/Smart2Dcanvas_CanvasViewport.tsx', 'w') as f:
    f.write(content)
