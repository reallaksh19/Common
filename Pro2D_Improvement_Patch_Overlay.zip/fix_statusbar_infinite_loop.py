import re

with open('js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx', 'r') as f:
    content = f.read()

content = content.replace("const [isOrtho, setOrtho] = useSceneStore((state) => [state.isOrtho, state.setOrtho]);\n  const [isOsnap, setOsnap] = useSceneStore((state) => [state.isOsnap, state.setOsnap]);", "const isOrtho = useSceneStore((state) => state.isOrtho);\n  const setOrtho = useSceneStore((state) => state.setOrtho);\n  const isOsnap = useSceneStore((state) => state.isOsnap);\n  const setOsnap = useSceneStore((state) => state.setOsnap);")

with open('js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx', 'w') as f:
    f.write(content)
