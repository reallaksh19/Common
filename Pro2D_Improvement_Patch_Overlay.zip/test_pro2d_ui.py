import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        
        # Capture console logs
        logs = []
        page.on("console", lambda msg: logs.append(f"{msg.type}: {msg.text}"))
        
        await page.goto("http://localhost:5173") # Assuming Vite is running on 5173
        
        # Click the main tab Coord -> PCF
        await page.click("text=Coord → PCF")
        await page.wait_for_timeout(1000)
        
        # Click the Pro 2D Canvas tab
        await page.click("text=Pro 2D Canvas")
        await page.wait_for_timeout(2000)
        
        await page.screenshot(path="pro2d_phase2_screenshot.png")
        
        print("Console logs:")
        for log in logs:
            print(log)
            
        await browser.close()

asyncio.run(main())
