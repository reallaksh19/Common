import assert from 'node:assert/strict';
import { Pro2D_buildMockState, Pro2D_toSceneBundle } from '../js/pro2dcanvas/Pro2D_Canonical.mjs';
import { Pro2D_exportSimpleSvg } from '../js/pro2dcanvas/Pro2D_SvgAdapter.mjs';
import { Pro2D_exportSimpleDxf } from '../js/pro2dcanvas/Pro2D_DxfAdapter.mjs';
import { Pro2D_validateState } from '../js/pro2dcanvas/Pro2D_ValidationEngine.mjs';

const doc = Pro2D_buildMockState();
const svg = Pro2D_exportSimpleSvg(doc);
const dxf = Pro2D_exportSimpleDxf(Pro2D_toSceneBundle(doc));
const validation = Pro2D_validateState(doc);

assert.ok(svg.includes('<svg'), 'SVG export should emit an SVG root element');
assert.ok(dxf.includes('SECTION'), 'DXF export should emit a SECTION header');
assert.equal(validation.summary.errors, 0, 'Smoke validation should stay error-free');

console.log(JSON.stringify({
  status: 'PASS',
  svgLength: svg.length,
  dxfLength: dxf.length,
  entities: validation.summary.totalEntities,
  nodes: validation.summary.totalNodes,
}, null, 2));
