import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Pro2D_toolRegistry, Pro2D_toolMap } from '../js/pro2dcanvas/Pro2D_ToolRegistry.mjs';
import { Pro2D_ribbonSections } from '../js/pro2dcanvas/Pro2D_RibbonConfig.mjs';
import { Pro2D_buildMockState, Pro2D_toSceneBundle, Pro2D_fromCoord2PcfSnapshot } from '../js/pro2dcanvas/Pro2D_Canonical.mjs';
import { Pro2D_validateState } from '../js/pro2dcanvas/Pro2D_ValidationEngine.mjs';
import { Pro2D_runEmitPipeline } from '../js/pro2dcanvas/Pro2D_EmitEngine.mjs';
import { Pro2D_mockRoute, Pro2D_mockEmits } from '../js/pro2dcanvas/Pro2D_MockData.mjs';
import { Pro2D_runBenchmark } from '../js/pro2dcanvas/Pro2D_Benchmark.mjs';

const requiredTools = ['select','marquee','measure','line','bend','tee','support','valve','flange','fvf','reducer','break','connect','stretch','gapClean','overlapSolver','underlay','annotations','minimap'];
for (const id of requiredTools) assert.ok(Pro2D_toolMap[id], `Missing tool registry entry: ${id}`);
assert.ok(Pro2D_toolRegistry.length >= 19, 'Tool registry is unexpectedly small');

const requiredSections = ['file','draft','fittings','repair','interop'];
for (const id of requiredSections) assert.ok(Pro2D_ribbonSections.find((s) => s.id === id), `Missing ribbon section: ${id}`);

const mock = Pro2D_buildMockState();
const validated = Pro2D_validateState(mock);
assert.ok(Object.keys(mock.entities).length >= 10, 'Mock state should contain multiple entities');
assert.ok(Object.keys(mock.nodes).length >= 10, 'Mock state should contain multiple nodes');
assert.equal(validated.summary.errors, 0, 'Mock state should validate without errors');

const bundle = Pro2D_toSceneBundle(mock);
assert.ok(Object.keys(bundle.segments).length > 0, 'Scene bundle should include segments');
assert.ok(Object.keys(bundle.supports).length > 0, 'Scene bundle should include supports');
assert.ok(Object.keys(bundle.inlineItems).length > 0, 'Scene bundle should include inline items');

const pipeline = Pro2D_runEmitPipeline({ route: Pro2D_mockRoute, bore: 250, emits: Pro2D_mockEmits });
assert.ok(pipeline.metrics.emitCount > 0, 'Emit pipeline should see mock emits');
assert.ok(pipeline.metrics.finalElementCount >= pipeline.metrics.emitCount, 'Emit pipeline should produce final elements');
assert.ok(pipeline.metrics.autoSupportCount > 0, 'Emit pipeline should produce auto supports');

const imported = Pro2D_fromCoord2PcfSnapshot({
  parsedRuns: [{ points: [{ x: 0, y: 0, z: 0 }, { x: 1000, y: 0, z: 0 }, { x: 1000, y: 1000, z: 0 }] }],
  supportPoints: [[100,0],[900,0]],
  canvasFittings: [{ type: 'valve', x: 500, y: 0 }],
  options: { bore: 200, pipelineRef: 'P-100' },
});
assert.ok(Object.keys(imported.entities).length >= 4, 'Coord2PCF import should produce entities');
assert.equal(Pro2D_validateState(imported).summary.errors, 0, 'Coord2PCF import should validate');

const appShell = fs.readFileSync(new URL('../js/pro2dcanvas/Pro2D_AppShell.tsx', import.meta.url), 'utf-8');
assert.ok(appShell.includes('Pro2D_CoorOpsPanel'), 'AppShell should mount the CoorCanvas operator panel');
assert.ok(appShell.includes('Pro2D_DebugDock'), 'AppShell should mount the debug dock');

const benchmark = Pro2D_runBenchmark();
assert.ok(Number.isFinite(benchmark.phase1LoadMs), 'Benchmark phase1LoadMs should be numeric');
assert.ok(Number.isFinite(benchmark.phase3Load10kMs), 'Benchmark phase3Load10kMs should be numeric');

console.log(JSON.stringify({
  status: 'PASS',
  toolCount: Pro2D_toolRegistry.length,
  ribbonSections: Pro2D_ribbonSections.length,
  mockEntities: Object.keys(mock.entities).length,
  mockNodes: Object.keys(mock.nodes).length,
  emitMetrics: pipeline.metrics,
  benchmark: {
    phase1LoadMs: benchmark.phase1LoadMs,
    phase1ValidateMs: benchmark.phase1ValidateMs,
    phase1SceneBundleMs: benchmark.phase1SceneBundleMs,
    phase2EmitPipelineMs: benchmark.phase2EmitPipelineMs,
    phase3Load10kMs: benchmark.phase3Load10kMs,
    phase3Validate10kMs: benchmark.phase3Validate10kMs,
  }
}, null, 2));
