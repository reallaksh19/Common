with open('js/pro2dcanvas/Pro2D_LeftRail.tsx', 'r') as f:
    content = f.read()

# Only keep select, pan, pipe, polyline, spline, rotate in LeftRail
content = content.replace("""const TOOLS = [
  { id: 'select', label: 'Select', icon: '🖱' },
  { id: 'pan', label: 'Pan', icon: '✋' },
  { id: 'line', label: 'Pipe', icon: '／' },
  { id: 'polyline', label: 'Polyline', icon: '〰' },
  { id: 'spline', label: 'Spline', icon: '∿' },
  { id: 'support', label: 'Support', icon: '✚' },
  { id: 'valve', label: 'Valve', icon: '◇' },
  { id: 'flange', label: 'Flange', icon: '▮' },
  { id: 'fvf', label: 'FVF', icon: '▮◇▮' },
  { id: 'reducer', label: 'Reducer', icon: '⬘' },
];""", """const TOOLS = [
  { id: 'select', label: 'Select', icon: '🖱' },
  { id: 'pan', label: 'Pan', icon: '✋' },
  { id: 'line', label: 'Pipe', icon: '／' },
  { id: 'polyline', label: 'Polyline', icon: '〰' },
  { id: 'spline', label: 'Spline', icon: '∿' },
  { id: 'rotate', label: 'Rotate', icon: '↻' },
];""")

with open('js/pro2dcanvas/Pro2D_LeftRail.tsx', 'w') as f:
    f.write(content)
