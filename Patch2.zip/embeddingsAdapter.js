import { GoogleGenerativeAI } from "@google/generative-ai";

// FIX C-1: removed "|| true" — fallback now only activates when explicitly set
//          or when no API key is available
// FIX C-2: all paths use EMBEDDING_DIM=768 consistently;
//          fallback uses content-sensitive vectors so equal-length strings don't collide

const EMBEDDING_DIM = 768;
const embedCache = new Map();

// FNV-1a 32-bit — better distribution than original
function hashText(text) {
    let hash = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = (hash * 0x01000193) >>> 0;
    }
    return hash.toString(36);
}

/**
 * Content-sensitive deterministic fallback embedding.
 * Uses character bigram/trigram frequencies so texts of equal length
 * produce different vectors. Unit-norm output of EMBEDDING_DIM dimensions.
 * NOT semantically meaningful — use only when API key is absent.
 */
function deterministicFallbackVector(text) {
    const vec = new Float64Array(EMBEDDING_DIM);
    const norm = text.toLowerCase();
    for (let i = 0; i < norm.length; i++) {
        const c0 = norm.charCodeAt(i);
        const c1 = i + 1 < norm.length ? norm.charCodeAt(i + 1) : 0;
        const c2 = i + 2 < norm.length ? norm.charCodeAt(i + 2) : 0;
        vec[(c0 * 31 + c1) % EMBEDDING_DIM]          += 1;
        vec[(c0 * 961 + c1 * 31 + c2) % EMBEDDING_DIM] += 0.5;
    }
    let mag = 0;
    for (let i = 0; i < EMBEDDING_DIM; i++) mag += vec[i] * vec[i];
    mag = Math.sqrt(mag) || 1;
    return Array.from(vec).map(x => x / mag);
}

export async function getEmbeddings(texts) {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;

    // FIX C-1: only fall back when flag explicitly set OR no key present
    const isTestFallback =
        process.env.EMBEDDING_TEST_FALLBACK === "1" ||
        !apiKey || apiKey.trim() === "";

    const results = new Array(texts.length);
    const toFetch = [];

    texts.forEach((text, i) => {
        const key = hashText(text);
        const cached = embedCache.get(key);
        if (cached) {
            results[i] = cached;
        } else {
            toFetch.push({ text, originalIndex: i });
        }
    });

    if (toFetch.length === 0) return results;

    if (isTestFallback) {
        toFetch.forEach((item) => {
            const vec = deterministicFallbackVector(item.text);
            results[item.originalIndex] = vec;
            embedCache.set(hashText(item.text), vec);
        });
        return results;
    }

    try {
        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({ model: "text-embedding-004" });
        const requests = toFetch.map(item => ({
            content: { role: "user", parts: [{ text: item.text }] }
        }));
        const response = await model.batchEmbedContents({ requests });
        const embeddings = response.embeddings.map(e => e.values);
        toFetch.forEach((item, i) => {
            const vec = embeddings[i];
            results[item.originalIndex] = vec;
            embedCache.set(hashText(item.text), vec);
        });
    } catch (err) {
        console.error("[getEmbeddings] Gemini API call failed, using content-sensitive fallback:", err.message);
        // FIX C-2: error path uses same dim/method as normal fallback — never produces zero vectors
        toFetch.forEach(item => {
            const vec = deterministicFallbackVector(item.text);
            results[item.originalIndex] = vec;
            embedCache.set(hashText(item.text), vec);
        });
    }

    return results;
}
