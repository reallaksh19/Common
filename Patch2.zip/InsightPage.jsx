// FIX C-3: applyIncrementalUpdate args were swapped + wrong types — fixed
// FIX H-3: children now looked up from storiesById map and rendered with real content
// FIX H-4: result (not just parents) stored in state so storiesById is accessible
// FIX H-5: weakTree flag now visually surfaced on parent card
import React, { useEffect, useState, useCallback } from 'react';
import { runInsightPipeline, applyIncrementalUpdate } from '../insight/src/index.js';
import { slotFetcher } from '../adapters/insightFetcher.js';
import { DEFAULT_CONFIG } from '../insight/src/types/index.js';
import Header from '../components/Header.jsx';
import EmptyState from '../components/EmptyState.jsx';

// Angle badge colours
const ANGLE_STYLE = {
    base_report:         { bg: '#1a3a5c', color: '#60a5fa', label: 'BASE'     },
    official_response:   { bg: '#1a3d2b', color: '#4ade80', label: 'OFFICIAL' },
    fact_update:         { bg: '#3d2e0a', color: '#fbbf24', label: 'FACT'     },
    market_reaction:     { bg: '#2d1f47', color: '#c084fc', label: 'MARKET'   },
    expert_analysis:     { bg: '#3d1e1a', color: '#f87171', label: 'EXPERT'   },
    regional_followup:   { bg: '#1e2d3d', color: '#94a3b8', label: 'REGIONAL' },
    investigative_detail:{ bg: '#2d2a0a', color: '#facc15', label: 'INVEST.'  },
    correction:          { bg: '#3d1a1a', color: '#fb923c', label: 'CORRECTION'},
    background_context:  { bg: '#1a2a2d', color: '#67e8f9', label: 'CONTEXT'  },
    reaction_public:     { bg: '#2a1a3d', color: '#a78bfa', label: 'PUBLIC'   },
    unknown:             { bg: '#2a2a2a', color: '#9ca3af', label: 'OTHER'    },
};

function AngleBadge({ angle }) {
    const s = ANGLE_STYLE[angle] || ANGLE_STYLE.unknown;
    return (
        <span style={{
            background: s.bg, color: s.color,
            padding: '2px 6px', borderRadius: '3px',
            fontSize: '10px', fontWeight: '700',
            textTransform: 'uppercase', letterSpacing: '0.5px',
            flexShrink: 0, alignSelf: 'flex-start', marginTop: '2px',
        }}>
            {s.label}
        </span>
    );
}

function SnapshotDots({ snapshotPresence }) {
    const slots = ['now', 'minus4h', 'minus12h', 'minus24h'];
    const labels = { now: 'now', minus4h: '−4h', minus12h: '−12h', minus24h: '−24h' };
    return (
        <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            {slots.map(slot => (
                <span key={slot} title={labels[slot]} style={{
                    width: '8px', height: '8px', borderRadius: '50%',
                    background: snapshotPresence[slot]
                        ? 'var(--color-primary, #3b82f6)'
                        : 'var(--color-border, #374151)',
                    display: 'inline-block',
                }} />
            ))}
        </div>
    );
}

function ChildStory({ childId, storiesById }) {
    // FIX H-3: look up actual story from storiesById instead of showing raw ID
    const story = storiesById?.get(childId);
    if (!story) return null;

    const timeAgo = (() => {
        const m = Math.round((Date.now() - story.publishedAt) / 60000);
        if (m < 60) return `${m}m ago`;
        return `${Math.round(m / 60)}h ago`;
    })();

    return (
        <li style={{
            padding: '10px 0',
            borderBottom: '1px solid var(--color-border, #374151)',
            display: 'flex', gap: '10px', alignItems: 'flex-start',
        }}>
            <AngleBadge angle={story.angle || 'unknown'} />
            <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                    fontSize: '13px', fontWeight: '600',
                    color: 'var(--color-text-primary)',
                    marginBottom: '3px',
                }}>
                    {story.title}
                </div>
                <div style={{
                    fontSize: '12px',
                    color: 'var(--color-text-secondary)',
                    lineHeight: '1.5',
                    marginBottom: '4px',
                }}>
                    {story.summary}
                </div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-tertiary, #6b7280)' }}>
                    {story.source} · {timeAgo}
                    {story.sourceTier && (
                        <span style={{ marginLeft: '6px', opacity: 0.6 }}>Tier {story.sourceTier}</span>
                    )}
                </div>
            </div>
        </li>
    );
}

function ParentCard({ parent, storiesById, isExpanded, onToggle }) {
    const hiddenCount = parent.hiddenDuplicateIds?.length ?? 0;

    return (
        <div style={{
            background: 'var(--color-surface)',
            borderRadius: '12px',
            border: `1px solid ${parent.weakTree ? 'var(--color-warning, #d97706)' : 'var(--color-border)'}`,
            overflow: 'hidden',
            marginBottom: '16px',
            // FIX H-5: dim weak-tree parents slightly
            opacity: parent.weakTree ? 0.75 : 1,
        }}>
            <div style={{ padding: '16px' }}>
                {/* Title row */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
                    <h3 style={{ margin: '0 0 8px 0', fontSize: '17px', fontWeight: 'bold', flex: 1 }}>
                        {parent.canonicalHeadline}
                    </h3>
                    <div style={{ display: 'flex', gap: '6px', flexShrink: 0, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                        {parent.isRising && (
                            <span style={{ background: '#854d0e', color: '#fef08a', padding: '2px 7px', borderRadius: '4px', fontSize: '11px', fontWeight: 'bold' }}>
                                🔥 Rising
                            </span>
                        )}
                        {/* FIX H-5: show weak tree warning badge */}
                        {parent.weakTree && (
                            <span style={{ background: '#78350f', color: '#fde68a', padding: '2px 7px', borderRadius: '4px', fontSize: '11px', fontWeight: 'bold' }} title="Fewer than 3 quality child stories found for this cluster">
                                ⚠ Thin
                            </span>
                        )}
                        <span style={{ background: 'var(--color-surface-hover)', padding: '2px 7px', borderRadius: '4px', fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                            {parent.finalParentScore.toFixed(2)}
                        </span>
                    </div>
                </div>

                {/* Summary */}
                <p style={{ margin: '0 0 12px 0', fontSize: '13px', color: 'var(--color-text-secondary)', lineHeight: '1.5' }}>
                    {parent.canonicalSummary}
                </p>

                {/* Meta row */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                    <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                        <SnapshotDots snapshotPresence={parent.snapshotPresence} />
                        <span style={{ fontSize: '11px', color: 'var(--color-text-tertiary, #6b7280)' }}>
                            {parent.debug?.clusterSize ?? '?'} stories
                        </span>
                        {/* FIX H-4: show real hidden count — populated by pipeline fix */}
                        {hiddenCount > 0 && (
                            <span style={{ fontSize: '11px', color: 'var(--color-text-tertiary, #6b7280)' }}>
                                {hiddenCount} similar hidden
                            </span>
                        )}
                    </div>
                    <button
                        onClick={onToggle}
                        style={{
                            background: 'var(--color-bg)', border: '1px solid var(--color-border)',
                            color: 'var(--color-text-primary)', cursor: 'pointer',
                            fontWeight: 'bold', padding: '5px 12px', borderRadius: '6px', fontSize: '12px',
                        }}
                    >
                        {isExpanded ? '− Hide' : `+ ${parent.childStoryIds.length} Stories`}
                    </button>
                </div>
            </div>

            {/* Children panel */}
            {isExpanded && (
                <div style={{
                    borderTop: '1px solid var(--color-border)',
                    padding: '8px 16px 12px',
                    background: 'var(--color-surface-elevated, var(--color-surface))',
                }}>
                    {parent.childStoryIds.length === 0 ? (
                        <p style={{ fontSize: '13px', color: 'var(--color-text-tertiary)', padding: '8px 0' }}>
                            No diverse child stories for this cluster.
                        </p>
                    ) : (
                        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                            {parent.childStoryIds.map(childId => (
                                <ChildStory
                                    key={childId}
                                    childId={childId}
                                    storiesById={storiesById}
                                />
                            ))}
                        </ul>
                    )}
                </div>
            )}
        </div>
    );
}

function InsightPage() {
    // FIX C-3 + H-3: store full result (not just parents) so storiesById is accessible
    const [result, setResult] = useState(null);
    const [loading, setLoading]   = useState(true);
    const [expanded, setExpanded] = useState({});

    const parents    = result?.parents    ?? [];
    const storiesById = result?.storiesById ?? new Map();

    useEffect(() => {
        let isMounted = true;
        async function fetchInitial() {
            try {
                setLoading(true);
                const r = await runInsightPipeline(slotFetcher, DEFAULT_CONFIG);
                if (isMounted) setResult(r);
            } catch (e) {
                console.error('Failed to run insight pipeline:', e);
            } finally {
                if (isMounted) setLoading(false);
            }
        }
        fetchInitial();
        return () => { isMounted = false; };
    }, []);

    // FIX C-3: correct arg order — applyIncrementalUpdate(newStories, existingResult, cfg)
    useEffect(() => {
        if (!result) return;
        const interval = setInterval(async () => {
            try {
                const freshStories = await slotFetcher('now');
                if (freshStories.length > 0) {
                    const updated = applyIncrementalUpdate(freshStories, result, DEFAULT_CONFIG);
                    setResult({ ...updated });
                }
            } catch (e) {
                console.error('Incremental update failed:', e);
            }
        }, 5 * 60 * 1000);
        return () => clearInterval(interval);
    }, [result]);

    const toggleExpand = useCallback((id) => {
        setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
    }, []);

    if (loading) {
        return (
            <div className="page-container insight-page">
                <Header title="Insight" stateLabel="Loading" stateType="loading" />
                <div className="modern-container">
                    <p style={{ textAlign: 'center', marginTop: '20px' }}>Running AI pipeline…</p>
                </div>
            </div>
        );
    }

    if (!parents.length) {
        return (
            <div className="page-container insight-page">
                <Header title="Insight" stateLabel="Up to date" stateType="live" />
                <div className="modern-container">
                    <EmptyState
                        icon="🧠"
                        title="No Insights Available"
                        message="Couldn't generate clusters from the latest news right now."
                    />
                </div>
            </div>
        );
    }

    return (
        <div className="page-container insight-page">
            <Header title="Insight" stateLabel="Live" stateType="live" />
            <div className="modern-container" style={{ padding: '16px' }}>
                {parents.map((p) => (
                    <ParentCard
                        key={p.parentId}
                        parent={p}
                        storiesById={storiesById}
                        isExpanded={!!expanded[p.parentId]}
                        onToggle={() => toggleExpand(p.parentId)}
                    />
                ))}
            </div>
        </div>
    );
}

export default InsightPage;
