import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        
        # Listen to console logs to see what's wrong with the react mount
        logs = []
        page.on("console", lambda msg: logs.append(msg.text))
        
        await page.goto("http://localhost:5173")
        
        # Click the theme toggle to test dark mode for better visibility of react components
        await page.click("#btn-theme-toggle")
        await page.wait_for_timeout(1000)

        # Click the main tab Coord -> PCF
        await page.click("text=Coord → PCF")
        await page.wait_for_timeout(2000)
        
        # Click the Pro 2D Canvas tab
        await page.click("text=Pro 2D Canvas")
        await page.wait_for_timeout(4000)
        
        for log in logs:
            print("LOG:", log)
            
        await page.screenshot(path="pro2d_screenshot.png", full_page=True)
        await browser.close()

asyncio.run(main())
