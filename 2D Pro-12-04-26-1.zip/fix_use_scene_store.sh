sed -i 's/const scene = useSceneStore((state) => ({/const scene = useSceneStore((state) => { return {/g' js/pro2dcanvas/Pro2D_AppShell.tsx
sed -i 's/  }));/  }; });/g' js/pro2dcanvas/Pro2D_AppShell.tsx
