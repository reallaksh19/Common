sed -i 's/const { activeTool, scale, isOrtho, isOsnap, selectedCount, revision } = useSceneStore((state) => ({/import { useShallow } from "zustand\/react\/shallow";\n\nconst Smart2Dcanvas_StatusBar: React.FC = () => {\n  const { activeTool, scale, isOrtho, isOsnap, selectedCount, revision } = useSceneStore(useShallow((state) => ({/g' js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx
sed -i 's/    revision: state.revision,/    revision: state.revision,\n  })));/g' js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx
sed -i 's/  }));//g' js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx
sed -i '/const Smart2Dcanvas_StatusBar: React.FC = () => {/d' js/smart2dcanvas/Smart2Dcanvas_StatusBar.tsx
