const fs = require('fs');
console.log(fs.existsSync('viewer/js/pcf2glb/ui/Proglb_ProGlbViewerPanel.js'));
