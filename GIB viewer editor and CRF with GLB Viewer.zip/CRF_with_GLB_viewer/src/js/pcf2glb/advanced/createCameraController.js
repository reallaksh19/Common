import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { computeBounds, fitPerspectiveToBox } from './fitBounds.js';

export function createCameraController(camera, domElement) {
  const controls = new OrbitControls(camera, domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.screenSpacePanning = true;
  controls.minDistance = 0.25;
  controls.maxDistance = 1000000;
  controls.minPolarAngle = 0.03;
  controls.maxPolarAngle = Math.PI - 0.03;

  let currentCenter = new THREE.Vector3();
  let currentDistance = 100;

  return {
    controls,
    update: () => controls.update(),

    fitScene: (sceneRoot) => {
        if (!sceneRoot || sceneRoot.children.length === 0) return;
        const box = computeBounds(sceneRoot, false);
        currentDistance = fitPerspectiveToBox(camera, controls, box);
        currentCenter = box.getCenter(new THREE.Vector3());
    },

    fitObject: (object3D) => {
        const box = computeBounds(object3D, true);
        fitPerspectiveToBox(camera, controls, box);
        controls.target.copy(box.getCenter(new THREE.Vector3()));
        controls.update();
    },

    resetTarget: () => {
        controls.target.copy(currentCenter);
        controls.update();
    },

    setPresetView: (name) => {
        camera.up.set(0, 1, 0); // Always restore default up
        if (name === 'ISO') {
            camera.position.copy(controls.target).add(new THREE.Vector3(1, 1, 1).normalize().multiplyScalar(currentDistance));
        } else if (name === 'TOP') {
            camera.position.copy(controls.target).add(new THREE.Vector3(0, 1, 0).normalize().multiplyScalar(currentDistance));
            camera.up.set(0, 0, -1);
        } else if (name === 'FRONT') {
            camera.position.copy(controls.target).add(new THREE.Vector3(0, 0, 1).normalize().multiplyScalar(currentDistance));
        } else if (name === 'SIDE') {
            camera.position.copy(controls.target).add(new THREE.Vector3(1, 0, 0).normalize().multiplyScalar(currentDistance));
        }
        camera.lookAt(controls.target);
        controls.update();
    },

    dispose: () => controls.dispose()
  };
}
