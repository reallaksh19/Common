import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createRenderer } from './createRenderer.js';
import { createCameraController } from './createCameraController.js';
import { createToolbar } from './createToolbar.js';
import { buildSceneIndex } from './sceneIndex.js';
import { createSelection } from './createSelection.js';
import { createPropertyPanel } from './createPropertyPanel.js';
import { createHeatmap } from './createHeatmap.js';
import { createSectionBox } from './createSectionBox.js';
import { createMarqueeZoom } from './createMarqueeZoom.js';
import { disposeScene } from './disposeRuntime.js';
import { createAxisHelper } from './createAxisHelper.js';
import { createDebugPanel } from './createDebugPanel.js';

export function createViewerApp(previewContainer, toolbarContainer, propPanel, propContent, debugLogsContainer) {

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x222222);

  // Defer initialization to first frame to ensure container has size
  let initialized = false;
  let renderer, domElement, disposeRenderer, camera, controller, axesHelper, dirLight, pointLight, toolbar;
  let currentRoot = null;
  let animationId;
  let sceneIndex = null;
  let propertyPanel = null;
  let heatmap = null;
  let sectionBox = null;
  let debugPanel = null;

  const init = () => {
    if (initialized || !previewContainer.clientWidth) return;
    initialized = true;

    const renderData = createRenderer(previewContainer);
    renderer = renderData.renderer;
    domElement = renderData.domElement;
    disposeRenderer = renderData.dispose;

    camera = new THREE.PerspectiveCamera(60, previewContainer.clientWidth / previewContainer.clientHeight, 0.1, 10000000);

    controller = createCameraController(camera, domElement);

    axesHelper = createAxisHelper(camera, domElement);
    // ViewHelper automatically attaches to camera, no need to add to scene

    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(100, 200, 50);
    scene.add(dirLight);

    pointLight = new THREE.PointLight(0xffffff, 0.5);
    camera.add(pointLight);
    scene.add(camera);

    toolbar = createToolbar(toolbarContainer, controller);
    toolbar.setFitHandler(() => {
       if (currentRoot) controller.fitScene(currentRoot);
    });

    propertyPanel = createPropertyPanel(propPanel, propContent);
    heatmap = createHeatmap(scene);
    sectionBox = createSectionBox(scene, renderer);

    debugPanel = createDebugPanel(debugLogsContainer);

    // Wire up marquee zoom (Shift + Drag)
    const marqueeZoom = createMarqueeZoom(camera, scene, domElement, controller);

    toolbar.setSectionHandler((enabled) => {
        if (enabled) {
            sectionBox.enable();
            if (currentRoot) sectionBox.fitToScene(currentRoot);
        } else {
            sectionBox.disable(currentRoot);
        }
    });

    const selection = createSelection(camera, scene, domElement);
    selection.onSelect((clickedObj) => {
        if (!clickedObj || !sceneIndex) {
            controller.resetTarget();
            propertyPanel.hide();
            return;
        }

        const id = clickedObj.userData.pcfId || clickedObj.name || clickedObj.uuid;
        const item = sceneIndex.byId.get(id);

        if (item) {
            controller.fitObject(item.object3D);
            propertyPanel.show(item);

            // Auto section fit to selection if enabled
            if (sectionBox && sectionBox.isEnabled()) {
                sectionBox.fitToSelection(item.object3D, currentRoot);
            }
        }
    });

    // Handle view helper clicks
    domElement.addEventListener('pointerup', (event) => {
      if (axesHelper && axesHelper.handleClick(event)) {
          // Handled by view helper
      }
    });

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      controller.update();
      renderer.autoClear = true;
      renderer.render(scene, camera);
      if (axesHelper) {
          renderer.autoClear = false;
          axesHelper.render(renderer);
      }
    };
    animate();
  };

  setTimeout(init, 100);

  return {
    loadGLB: async (url) => {
      init();
      const loader = new GLTFLoader();
      return new Promise((resolve, reject) => {
          loader.load(url, (gltf) => {
              if (currentRoot) {
                  scene.remove(currentRoot);
                  disposeScene(currentRoot);
              }
              currentRoot = gltf.scene;
              scene.add(currentRoot);

              sceneIndex = buildSceneIndex(currentRoot);

              // Pre-compute metrics before fit to ensure camera far clip handles large scenes
              const box = new THREE.Box3().setFromObject(currentRoot);
              const size = box.getSize(new THREE.Vector3());
              const maxDim = Math.sqrt(size.x*size.x + size.y*size.y + size.z*size.z);

              // ViewHelper sets its own scale, no need to scale it like axesHelper

              controller.fitScene(currentRoot);
              dirLight.position.copy(camera.position);

              debugPanel.log('system', 'info', `Loaded scene with ${sceneIndex.items.length} indexed objects`);

              // Inform toolbar of available properties
              const propSet = new Set();
              currentRoot.traverse(c => {
                  if (c.isMesh && c.userData) {
                      Object.keys(c.userData).forEach(k => {
                          if (k !== 'pcfId' && k !== 'pcfType') propSet.add(k);
                      });
                  }
              });
              toolbar.setProperties(Array.from(propSet).sort());

              toolbar.setHeatmapHandler((prop) => {
                  if (prop === 'default') {
                      heatmap.clearMetric();
                      toolbar.updateLegend(null);
                      return;
                  }

                  // For standalone meshes, we can adapt the heatmap signature
                  const valuesSet = new Set();
                  currentRoot.traverse(c => {
                      if (c.isMesh && c.userData && c.userData[prop] !== undefined) {
                          valuesSet.add(String(c.userData[prop]));
                      }
                  });
                  const uniqueValues = Array.from(valuesSet).sort();
                  const palettes = [
                      0xe6194b, 0x3cb44b, 0xffe119, 0x4363d8, 0xf58231, 0x911eb4, 0x46f0f0, 0xf032e6, 0xbcf60c, 0xfabebe,
                      0x008080, 0xe6beff, 0x9a6324, 0xfffac8, 0x800000, 0xaaffc3, 0x808000, 0xffd8b1, 0x000075, 0x808080,
                  ];
                  const colorMap = new Map();
                  uniqueValues.forEach((val, idx) => {
                      colorMap.set(val, palettes[idx % palettes.length]);
                  });

                  heatmap.clearMetric();
                  currentRoot.traverse(child => {
                      if (child.isMesh && child.userData) {
                          const mats = Array.isArray(child.material) ? child.material : [child.material];
                          mats.forEach(mat => {
                              if (!mat.userData.__baseColor) {
                                  mat.userData.__baseColor = mat.color.clone();
                              }
                              const val = String(child.userData[prop]);
                              if (child.userData[prop] !== undefined && colorMap.has(val)) {
                                  mat.color.setHex(colorMap.get(val));
                              } else {
                                  mat.color.set('#666666'); // Ghosted
                              }
                          });
                      }
                  });

                  let html = '';
                  uniqueValues.forEach(val => {
                      const colorHex = '#' + colorMap.get(val).toString(16).padStart(6, '0');
                      html += `<div style="display:flex; align-items:center; margin-bottom:4px;">
                          <span style="width:12px; height:12px; background:${colorHex}; display:inline-block; margin-right:6px; border:1px solid #fff;"></span>
                          <span>${val}</span>
                      </div>`;
                  });
                  toolbar.updateLegend(html);
              });

              resolve();
          }, undefined, reject);
      });
    },
    dispose: () => {
      if (animationId) cancelAnimationFrame(animationId);
      if (disposeRenderer) disposeRenderer();
      if (controller) controller.dispose();
    }
  };
}
