const { chromium } = require('playwright');
const http = require('http');
const handler = require('serve-handler');
const path = require('path');

const server = http.createServer((request, response) => {
  return handler(request, response, { public: path.join(__dirname, 'viewer') });
});

server.listen(3000, async () => {
  console.log('Running at http://localhost:3000');
  const browser = await chromium.launch({ args: ['--disable-web-security'] });
  const page = await browser.newPage();
  
  await page.goto('http://localhost:3000/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);
  
  await page.evaluate(() => { 
      const btn = document.querySelector('button[data-tab="pro-glb"]');
      if (btn) btn.click();
  });
  await page.waitForTimeout(1000);

  await page.screenshot({ path: 'Phase_UI_Update.png' });
  await browser.close();
  server.close();
  console.log('UI Update Screenshot taken');
});
