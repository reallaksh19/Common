# Files Changed
- `viewer/js/pcf2glb/ui/Proglb_ProGlbViewerPanel.js`: Rewrote template HTML definitions providing the primary IDE layout blocks. Shifted interactive button components and select toggles into appropriate bounded container IDs. Adapted binding query selectors effectively matching these HTML updates.
