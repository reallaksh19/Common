# Physics publication skill — approval summary

## Decision requested

Approve the Physics publication skill and its two matched Motion demonstrations as the baseline for the next subject stage. This approval does not certify a board-specific syllabus; the examples are source-mapped drafts pending the user's formal curriculum profile decision.

## Reviewed input

The attached Physics package was reviewed at file, content-master, validator, renderer, and rendered-page levels. Its original files are preserved unchanged in `Grade9_Physics_Publication_Original_Attachment_Backup.zip`.

## Demonstration scope

Both learner books use the same subtopics and canonical concepts:

1. Distance and displacement (`PHY-MOT-M01`)
2. Reading a velocity–time graph (`PHY-MOT-M02`)

The B30 book changes the scaffold: prerequisite checks, purpose anchors, explicit first moves, worked-to-faded examples, misconception checks, short practice, and repair records. The B80 book changes the challenge: compressed retrieval, one-feature near twins, boundary cases, unlabelled retrieval, transfer, and targeted repair. Concept claims and identifiers remain identical.

## What was adapted from the attachment

- Band-aware publication architecture rather than one undifferentiated book.
- Canonical JSON as the content source and PDF as a generated artifact.
- Instructional block vocabulary, badges, figure reserves, learner routes, source markers, and audit checkpoints.
- Separate low-prior-knowledge modelling and high-prior-knowledge discrimination/transfer.
- Page rendering as a mandatory release check.

These choices were retained because they materially improve teacher intent, learner routing, and production repeatability.

## What was changed or not carried forward

- Self-declared audit totals were replaced by computed audit JSON; the attachment's totals did not match its own content.
- Free-text route destinations were replaced by stable IDs that must resolve.
- The validator now binds the canonical JSON hash, publication ID, and band to PDF metadata and every footer; cross-paired B30/B80 files fail.
- Hard-coded system-font paths were replaced by bundled, licensed fonts.
- Unresolved source labels were replaced by a dated source ledger with URL, publisher, locator, scope status, and verification date.
- Every scored question now requires exactly one primary concept, an answer, marking guidance, and positive marks.
- High-grade previews must be explicitly `PREVIEW`, `NOT SCORED`, and excluded from mastery.
- Physics errors and ambiguities were rewritten: the equality condition for distance/displacement now includes a straight-line, one-direction path; the circular-track condition is stated; velocity–time axis crossings state direction; near-twin pairs change one declared feature; average-speed questions state time intervals.
- The attachment's overlapping band thresholds and exact percentage implications were not retained. B30/B80 are provisional placement hypotheses supported by diagnostic evidence and teacher override.
- The attachment's blanket ban on all high-band worked examples was not retained. Redundant novice reteaching is blocked, but a concise worked bridge is permitted when a new representation requires it and a rationale is recorded.
- Stale self-attestations, incorrect Physics statements, fragile layout tables, and the claim of a third canonical publisher were not adopted.

## Release evidence

| Check | B30 | B80 |
|---|---:|---:|
| Pages visually inspected | 11 | 9 |
| Instructional blocks | 18 | 13 |
| Scored questions | 4 | 6 |
| Resolved source references | 19 | 13 |
| Internal link annotations | 32 | 25 |
| PDF bookmarks | 18 | 16 |
| Automated audit | PASS | PASS |

The adversarial suite also passed: it rejected cross-band JSON/PDF pairing, a missing scored answer, an unjustified B80 worked example, a broken repair route, and a scored preview.

## Approval boundary

Approval authorizes this Physics publication baseline only. Mathematics work should begin only after the user approves or requests revisions. Board-specific release still requires a named, dated syllabus profile and source ledger review.
