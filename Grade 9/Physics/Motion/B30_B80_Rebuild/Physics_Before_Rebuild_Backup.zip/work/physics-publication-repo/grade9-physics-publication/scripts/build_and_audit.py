#!/usr/bin/env python3
"""Render a publication and immediately bind it to a generated audit."""

import argparse
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("master", type=Path)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("audit", type=Path)
    args = parser.parse_args()
    scripts = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(scripts / "render_physics_book.py"), str(args.master), str(args.pdf)], check=True)
    subprocess.run([sys.executable, str(scripts / "check_physics_publication.py"), str(args.master), str(args.pdf), "--audit", str(args.audit)], check=True)


if __name__ == "__main__":
    main()
