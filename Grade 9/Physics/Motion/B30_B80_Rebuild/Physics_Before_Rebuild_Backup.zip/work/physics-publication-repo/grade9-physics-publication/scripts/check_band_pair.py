#!/usr/bin/env python3
"""Check that differentiated masters retain the same concept truth and subtopic identity."""

import argparse
import json
import sys
from pathlib import Path


def indexed(items, key):
    return {item[key]: item for item in items}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("first", type=Path)
    parser.add_argument("second", type=Path)
    args = parser.parse_args()
    a = json.loads(args.first.read_text(encoding="utf-8"))
    b = json.loads(args.second.read_text(encoding="utf-8"))
    errors = []
    ca, cb = indexed(a["concepts"], "concept_id"), indexed(b["concepts"], "concept_id")
    if set(ca) != set(cb):
        errors.append("concept ID sets differ")
    for cid in sorted(set(ca) & set(cb)):
        if ca[cid]["canonical_claim"] != cb[cid]["canonical_claim"]:
            errors.append(f"canonical claim drift: {cid}")
    sa, sb = indexed(a["subtopics"], "subtopic_id"), indexed(b["subtopics"], "subtopic_id")
    if set(sa) != set(sb):
        errors.append("subtopic ID sets differ")
    for sid in sorted(set(sa) & set(sb)):
        if set(sa[sid]["concept_ids"]) != set(sb[sid]["concept_ids"]):
            errors.append(f"concept mapping drift: {sid}")
    result = {"status": "PASS" if not errors else "FAIL", "errors": errors, "bands": [a["band_profile"]["code"], b["band_profile"]["code"]], "matched_concepts": len(set(ca) & set(cb)), "matched_subtopics": len(set(sa) & set(sb))}
    print(json.dumps(result, indent=2))
    sys.exit(0 if not errors else 1)


if __name__ == "__main__":
    main()
