# Anti-drift and release gates

## Invariants

1. **Concept truth:** banding may not change definitions, laws, sign conventions, or correct answers.
2. **Scope:** every assessed concept is inside the declared curriculum/grade profile.
3. **Identity:** JSON, PDF, audit, and filenames agree on publication ID, band, version, and canonical hash.
4. **Source closure:** every source reference resolves to a dated ledger entry; author-created content is labelled.
5. **Assessment closure:** every scored question has one primary concept, answer, marking guide, and positive marks.
6. **Route closure:** every remediation target resolves.
7. **Preview fence:** a preview carries `PREVIEW` and `NOT SCORED`, has `scored: false`, and contributes zero mastery marks.
8. **Band integrity:** B30 contains explicit modelling and fading; B80 contains discrimination and transfer and does not repeat full novice instruction.
9. **Figure integrity:** text never relies on absent artwork; every placeholder has fixed reserve, alt text, caption, and semantic brief.
10. **Release evidence:** all audit claims are computed from the current files and every PDF page is visually inspected.

## Release gates

| Gate | Block release when |
|---|---|
| G1 Source/scope | curriculum profile is unnamed; a source is unresolved; assessed content exceeds scope |
| G2 Physics | any result, unit, sign, assumption, graph interpretation, or diagram is wrong/ambiguous |
| G3 Band | mandatory band blocks are missing; a nominal B80 publication is dominated by novice reteaching |
| G4 Assessment | answer/marking/primary concept is missing; near-twin pair changes more than one declared feature |
| G5 Routes | any route target does not resolve |
| G6 Build | clean rebuild fails; non-bundled font or undeclared dependency is required |
| G7 PDF identity | master hash or publication identity differs between JSON and PDF |
| G8 Visual | overlap, clipping, illegible graph/table, orphaned heading, broken link, or missing badge changes meaning |

Warnings that do not by themselves block release—such as a sparse page, unusually dense page, or optional accessibility enhancement—must still be reported with a human decision.

## Required negative tests

- Pair a B30 JSON with the B80 PDF: identity gate must fail.
- Delete an answer from a scored question: assessment gate must fail.
- Add a worked-example block to B80 without a `bridge_rationale`: band gate must fail.
- Break a route target: route gate must fail.
- Mark a preview scored or remove `NOT SCORED`: preview gate must fail.

## Versioning

Any change to a Physics claim, concept mapping, answer, source locator, band contract, schema, or renderer increments the skill/package version. Pure spelling corrections may retain the version only if the canonical master hash changes and a new artifact is issued. Never replace a released PDF while preserving its identity hash.
