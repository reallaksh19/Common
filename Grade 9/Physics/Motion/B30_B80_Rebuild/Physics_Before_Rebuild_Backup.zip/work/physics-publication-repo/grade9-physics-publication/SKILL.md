---
name: grade9-physics-publication
description: Create, differentiate, render, and audit Grade 9–11 Physics learning publications from source-grounded content masters. Use for learner books, differentiated bands, worked examples, question sets, answer keys, or PDF release QA; do not use to certify an unnamed syllabus or infer psychometric mastery from a percentage alone.
---

# Grade 9–11 Physics Publication

Produce Physics-correct learning material whose scaffolding changes with prior knowledge while the underlying concept truth, notation, and assessed target remain stable.

## Route the work

1. Confirm grade, topic, curriculum/board profile, language, output type, and intended knowledge band. If the board is absent, label the result `CURRICULUM_NEUTRAL_DEMO`; never imply syllabus certification.
2. Read [band-teaching.md](references/band-teaching.md) before differentiating or reviewing learner material.
3. Read [publication-schema.md](references/publication-schema.md) and validate the content master against [physics-publication.schema.json](references/physics-publication.schema.json) before rendering.
4. Read [anti-drift-and-release-gates.md](references/anti-drift-and-release-gates.md) for any release, revision, or migration.
5. Use [render_physics_book.py](scripts/render_physics_book.py) to render; then use [check_physics_publication.py](scripts/check_physics_publication.py) against the same JSON and source ledger. Run [negative_tests.py](scripts/negative_tests.py) after changing renderer or validator logic.

## Non-negotiable teaching contract

- Teach the same canonical concept IDs across bands. Change support, pacing, examples, and discrimination—not the Physics.
- Treat `nominal_prior_knowledge_percent` as a placement hypothesis supported by diagnostic evidence, not a psychometric score.
- Keep assessed questions within the declared grade/curriculum scope. Fence optional Grade 10–11 bridges with `PREVIEW` and `NOT SCORED` badges and `scored: false`.
- Every scored question has one primary concept ID, an answer, a marking guide, and a resolved source/provenance record.
- A B30 learner gets prerequisites, purpose, explicit first moves, worked-to-faded support, short checks, and named repair routes.
- A B80 learner gets compression, close discrimination, boundary cases, unlabelled retrieval, and transfer; avoid redundant reteaching. A concise bridge is allowed when a new representation genuinely requires it.
- Do not place full answers beside learner practice. Put answers and marking guidance in a separate keyed appendix.

## Required review passes

Run these passes in order and record evidence, changes, or a blocking issue for each:

1. **Source and scope:** map each concept to the dated source ledger; distinguish curriculum scope from author-created enrichment.
2. **Physics teacher:** recompute every result, check sign conventions, units, graph semantics, boundary conditions, and whether figures match text.
3. **B30 student simulation:** identify any point where a learner with weak prerequisites cannot choose the first move, decode notation, or recover after an error.
4. **B80 student simulation:** identify redundant explanation, weak distractors, unlabelled cues, or tasks that do not require selection and transfer.
5. **Cross-band invariance:** compare matched subtopics and verify identical concept truth, declared symbols, and core assessment targets.
6. **Assessment and routes:** verify one-variable discrimination pairs, answers, marks, scoring exclusions, and resolvable gap-map destinations.
7. **Publication QA:** verify PDF identity/hash binding, A4 geometry, links/bookmarks, badges, figure placeholders, no overlaps/cutoffs, legibility, and page-by-page visual inspection.

Stop release on any Physics error, unresolved source, mismatched JSON/PDF identity, missing scored answer, broken route, hidden scored preview, layout defect affecting meaning, or failed rebuild.

## Output contract

Deliver:

- canonical JSON master;
- source ledger;
- learner PDF with cover status, publication ID, band, master hash, source markers, badges, answer appendix, bookmarks, and internal links;
- generated audit JSON;
- review log naming the seven passes and any human decisions still required.

Never accept an audit summary written inside the content master as evidence. Generate audit counts from the current master and PDF.
