# Band-aware Physics teaching

## Placement is provisional

`B30` and `B80` describe an authoring response to current diagnostic evidence. They are not claims that learning is exactly 30% or 80%, and they are not interchangeable with marks. Record the diagnostic items, observed misconceptions, and teacher override. Re-evaluate after the publication's checkpoint questions.

| Profile | Working evidence | Authoring response | Avoid |
|---|---|---|---|
| B30 | Typically succeeds on fewer than 4 of 10 aligned diagnostic decisions, or shows missing prerequisite/first-move knowledge | prerequisite check; concrete purpose; one representation at a time; explicit first move; worked then faded examples; short practice; immediate repair route | unexplained symbols; multi-step jumps; distractors based on tricks; dense summaries before sense-making |
| B50 | Partial procedures but unstable concept selection | brief retrieval; worked comparison; faded support; mixed practice with feedback | full novice reteach; long unguided sets |
| B80 | Typically succeeds on 7–8 of 10 aligned decisions but errors on close cases, signs, or representation transfer | compact retrieval; near-twin discrimination; boundary cases; unlabelled graphs; transfer; error analysis | repeated definitions; fully cued routine sets; changing several variables in a claimed discrimination pair |
| B90 | Consistent routine and close-case success | synthesis, modelling choices, counterexamples, evaluation of assumptions, multi-representation transfer | unscaffolded scope expansion beyond the declared grade/curriculum |

These ranges are editorial heuristics, not validated cut scores. If diagnostic evidence conflicts with the nominal label, teach to the evidence and record the override.

## Same concept, different support

For a matched publication pair:

- reuse `subtopic_id`, `concept_id`, symbol definitions, sign convention, and core claim;
- change block sequence, explanation density, cueing, example completion, distractor proximity, and transfer distance;
- keep any higher-grade bridge explicitly optional, unscored, and outside mastery calculations.

## Teacher pass

For every claim and question, independently solve or derive it. Check:

- frame of reference and coordinate/sign convention;
- scalar/vector distinction and whether a path assumption is stated;
- graph axes, units, intervals, slopes, signed areas, and direction of crossing;
- significant information, determinacy, and alternative valid answers;
- diagram-to-text consistency;
- whether the requested reasoning matches the declared grade.

## B30 student simulation

Read as a learner who remembers fragments but cannot reliably select a method. At every task ask:

1. Do I know what the quantities mean and which are signed?
2. Is the first move visible without revealing the final answer?
3. Is only one new decision introduced at a time?
4. Can I tell why an attractive wrong answer is wrong?
5. Does an error point to a small, named repair block?

Repair the publication, not the learner label. Prefer a visual model, a single complete example, a faded next example, and short retrieval over more prose.

## B80 student simulation

Read as a learner who knows formulas but may apply them mechanically. At every task ask:

1. Must I select a concept, or is the method named for me?
2. Does a near-twin change exactly one relevant feature?
3. Are signs and units meaningful rather than decorative?
4. Is at least one representation unlabelled or translated?
5. Does transfer require explaining an assumption or rejecting an invalid claim?

If the learner can succeed by pattern matching, increase conceptual contrast before increasing arithmetic.
