#!/usr/bin/env python3
"""Render a Grade 9–11 Physics publication master to an auditable A4 PDF."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfdoc import PDFString
from reportlab.platypus import (
    Flowable,
    CondPageBreak,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


INK = colors.HexColor("#173F5F")
TEAL = colors.HexColor("#1D7874")
GOLD = colors.HexColor("#E5A93D")
PALE_BLUE = colors.HexColor("#EAF3F7")
PALE_GOLD = colors.HexColor("#FFF4D8")
PALE_RED = colors.HexColor("#FDEBE8")
MUTED = colors.HexColor("#536471")
LIGHT = colors.HexColor("#E3E8EC")
WHITE = colors.white


def canonical_bytes(data: dict) -> bytes:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def master_hash(data: dict) -> str:
    return hashlib.sha256(canonical_bytes(data)).hexdigest()


def register_fonts(skill_dir: Path) -> None:
    font_dir = skill_dir / "assets" / "fonts"
    fonts = {
        "DV": "DejaVuSans.ttf",
        "DV-Bold": "DejaVuSans-Bold.ttf",
        "DV-Oblique": "DejaVuSans-Oblique.ttf",
        "DV-BoldOblique": "DejaVuSans-BoldOblique.ttf",
    }
    for name, filename in fonts.items():
        path = font_dir / filename
        if not path.is_file():
            raise FileNotFoundError(f"Bundled font missing: {path}")
        pdfmetrics.registerFont(TTFont(name, str(path)))
    pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-Bold", italic="DV-Oblique", boldItalic="DV-BoldOblique")


def safe_id(value: str) -> str:
    return "id-" + "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in value)


class Bookmark(Flowable):
    def __init__(self, key: str, title: str, level: int = 0, closed: bool = False):
        super().__init__()
        self.key, self.title, self.level, self.closed = safe_id(key), title, level, closed
        self.width = self.height = 0

    def draw(self):
        self.canv.bookmarkPage(self.key)
        self.canv.addOutlineEntry(self.title, self.key, self.level, self.closed)


class FigurePlaceholder(Flowable):
    def __init__(self, spec: dict, style: ParagraphStyle):
        super().__init__()
        self.spec = spec
        self.width = min(float(spec["width_mm"]) * mm, 166 * mm)
        self.height = float(spec["height_mm"]) * mm
        self.style = style

    def wrap(self, avail_width, avail_height):
        self.width = min(self.width, avail_width)
        return self.width, self.height + 12 * mm

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(colors.HexColor("#F7FAFC"))
        c.setStrokeColor(TEAL)
        c.setDash(4, 3)
        c.roundRect(0, 10 * mm, self.width, self.height, 3 * mm, stroke=1, fill=1)
        c.setDash()
        c.setFillColor(TEAL)
        c.setFont("DV-Bold", 8.5)
        c.drawString(5 * mm, self.height + 3 * mm, f"{self.spec['status']} • {self.spec['figure_id']}")
        c.setFillColor(MUTED)
        c.setFont("DV", 7.5)
        text = c.beginText(5 * mm, self.height - 2 * mm)
        text.setLeading(10)
        words = self.spec["semantic_spec"].split()
        line = ""
        max_chars = max(36, int(self.width / 4.3))
        for word in words:
            candidate = f"{line} {word}".strip()
            if len(candidate) > max_chars:
                text.textLine(line)
                line = word
            else:
                line = candidate
        if line:
            text.textLine(line)
        c.drawText(text)
        c.setFillColor(INK)
        c.setFont("DV-Oblique", 7.2)
        caption = self.spec["caption"]
        c.drawString(0, 4 * mm, caption[:150])
        c.restoreState()


class AnswerSpace(Flowable):
    def __init__(self, marks: int):
        super().__init__()
        self.height = min(16 * mm, (6 + marks * 2) * mm)

    def wrap(self, avail_width, avail_height):
        self.width = avail_width
        return self.width, self.height

    def draw(self):
        self.canv.saveState()
        self.canv.setStrokeColor(colors.HexColor("#D9E2E7"))
        self.canv.setFillColor(MUTED)
        self.canv.setFont("DV-Oblique", 6.4)
        self.canv.drawString(0, self.height - 3 * mm, "Working space")
        y = self.height - 6 * mm
        while y > 0:
            self.canv.line(0, y, self.width, y)
            y -= 4.5 * mm
        self.canv.restoreState()


class RepairReflection(Flowable):
    def __init__(self):
        super().__init__()
        self.height = 48 * mm

    def wrap(self, avail_width, avail_height):
        self.width = avail_width
        return self.width, self.height

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(colors.HexColor("#F7FAFC"))
        c.setStrokeColor(TEAL)
        c.roundRect(0, 0, self.width, self.height, 2.5 * mm, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont("DV-Bold", 8.2)
        c.drawString(4 * mm, self.height - 6 * mm, "Repair record")
        c.setFont("DV", 7.4)
        prompts = [
            "My error type (circle): path total / endpoint change / sign / time interval / graph area",
            "Block I revisited:",
            "My corrected first move:",
            "One sentence explaining why the correction works:",
        ]
        y = self.height - 12 * mm
        for prompt in prompts:
            c.drawString(4 * mm, y, prompt)
            y -= 6 * mm
            c.setStrokeColor(colors.HexColor("#D9E2E7"))
            c.line(4 * mm, y, self.width - 4 * mm, y)
            y -= 5 * mm
        c.restoreState()


def build_styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("TitleDV", parent=base["Title"], fontName="DV-Bold", fontSize=25, leading=31, textColor=INK, alignment=TA_LEFT, spaceAfter=7 * mm),
        "subtitle": ParagraphStyle("SubtitleDV", parent=base["Normal"], fontName="DV", fontSize=12, leading=17, textColor=MUTED, spaceAfter=5 * mm),
        "h1": ParagraphStyle("H1DV", parent=base["Heading1"], fontName="DV-Bold", fontSize=19, leading=24, textColor=INK, spaceBefore=2 * mm, spaceAfter=4 * mm),
        "h2": ParagraphStyle("H2DV", parent=base["Heading2"], fontName="DV-Bold", fontSize=12, leading=15, textColor=INK, spaceBefore=2 * mm, spaceAfter=2 * mm),
        "body": ParagraphStyle("BodyDV", parent=base["BodyText"], fontName="DV", fontSize=9.3, leading=13.2, textColor=colors.HexColor("#1E2B32"), spaceAfter=1.8 * mm),
        "small": ParagraphStyle("SmallDV", parent=base["BodyText"], fontName="DV", fontSize=7.2, leading=9.5, textColor=MUTED),
        "question": ParagraphStyle("QuestionDV", parent=base["BodyText"], fontName="DV-Bold", fontSize=9.4, leading=13.2, textColor=INK),
        "answer": ParagraphStyle("AnswerDV", parent=base["BodyText"], fontName="DV", fontSize=8.0, leading=10.4, textColor=colors.HexColor("#1E2B32"), spaceAfter=1 * mm),
        "answer_title": ParagraphStyle("AnswerTitleDV", parent=base["Heading2"], fontName="DV-Bold", fontSize=9.0, leading=10.6, textColor=INK, spaceBefore=0.8 * mm, spaceAfter=0.8 * mm),
        "badge": ParagraphStyle("BadgeDV", parent=base["BodyText"], fontName="DV-Bold", fontSize=6.6, leading=8, textColor=WHITE, alignment=TA_CENTER),
        "cover_meta": ParagraphStyle("CoverMetaDV", parent=base["BodyText"], fontName="DV-Bold", fontSize=9, leading=13, textColor=INK, alignment=TA_CENTER),
        "toc": ParagraphStyle("TocDV", parent=base["BodyText"], fontName="DV", fontSize=9.4, leading=14, textColor=INK, leftIndent=2 * mm),
    }


def badge_table(badges: list[str], styles: dict) -> Table:
    badges = badges or ["LEARNING BLOCK"]
    cells = [Paragraph(escape(b), styles["badge"]) for b in badges]
    width = min(38 * mm, 66 * mm / max(1, len(cells)))
    table = Table([cells], colWidths=[width] * len(cells), hAlign="RIGHT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), TEAL), ("BOX", (0, 0), (-1, -1), 0.4, WHITE),
        ("LEFTPADDING", (0, 0), (-1, -1), 2 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 2 * mm),
        ("TOPPADDING", (0, 0), (-1, -1), 1.3 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.3 * mm),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table


def block_header(block: dict, styles: dict) -> Table:
    title = Paragraph(f"<a name='{safe_id(block['block_id'])}'/><b>{escape(block['title'])}</b>", styles["h2"])
    table = Table([[title, badge_table(block.get("badges", []), styles)]], colWidths=[92 * mm, 66 * mm], hAlign="LEFT")
    bg = PALE_RED if block["block_type"] == "misconception_check" else PALE_GOLD if block["block_type"] == "preview" else PALE_BLUE
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBELOW", (0, 0), (-1, -1), 0.8, INK),
        ("LEFTPADDING", (0, 0), (-1, -1), 3 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 3 * mm),
        ("TOPPADDING", (0, 0), (-1, -1), 1.8 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.8 * mm),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table


def source_line(block: dict, styles: dict) -> Paragraph:
    links = []
    for source_id in block["source_refs"]:
        links.append(f"<link href='#{safe_id('source-' + source_id)}' color='#1D7874'>{escape(source_id)}</link>")
    txt = f"ID {escape(block['block_id'])} • {escape(block['provenance_class'])} • Sources: " + ", ".join(links)
    return Paragraph(txt, styles["small"])


def add_block(story: list, block: dict, styles: dict, answer_rows: list) -> None:
    outer_story = story
    if block["block_type"] in {"worked_example", "faded_example", "preview", "repair_route"}:
        outer_story.append(CondPageBreak(40 * mm))
    story = []
    story.append(Spacer(1, 2.5 * mm))
    story.append(block_header(block, styles))
    story.append(Spacer(1, 1.8 * mm))
    for paragraph in block["body"]:
        story.append(Paragraph(escape(paragraph), styles["body"]))
    if block.get("figure"):
        story.append(Spacer(1, 1.5 * mm))
        story.append(FigurePlaceholder(block["figure"], styles["small"]))
    question = block.get("question")
    if question:
        q = Paragraph(f"{escape(question['question_id'])}: {escape(question['prompt'])}", styles["question"])
        qtable = Table([[q]], colWidths=[158 * mm])
        qtable.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.white), ("BOX", (0, 0), (-1, -1), 0.7, GOLD),
            ("LEFTPADDING", (0, 0), (-1, -1), 3 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 3 * mm),
            ("TOPPADDING", (0, 0), (-1, -1), 2.5 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5 * mm),
        ]))
        story.append(qtable)
        if question["marks"] > 0:
            story.append(AnswerSpace(question["marks"]))
        answer_rows.append((question, block["scored"]))
    if block.get("route_to"):
        route_links = [f"<link href='#{safe_id(target)}' color='#1D7874'>{escape(target)}</link>" for target in block["route_to"]]
        story.append(Paragraph("Routes: " + " • ".join(route_links), styles["small"]))
    if block["block_type"] == "repair_route":
        story.append(Spacer(1, 3 * mm))
        story.append(RepairReflection())
    story.append(source_line(block, styles))
    if block["block_type"] in {"worked_example", "faded_example", "preview", "repair_route"}:
        outer_story.append(KeepTogether(story))
    else:
        outer_story.extend(story)


def make_canvas_class(data: dict, full_hash: str):
    class MetadataCanvas(canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.setTitle(data["title"])
            self.setAuthor("Grade 9–11 Physics Publication skill")
            self.setSubject(f"{data['publication_id']} | {data['band_profile']['code']} | master-sha256:{full_hash}")
            self.setKeywords(f"Physics, Grade {data['grade']}, {data['band_profile']['code']}, {data['release_status']}")
            self._doc.Catalog.Lang = PDFString("en-GB")
    return MetadataCanvas


def page_decorator(data: dict, short_hash: str, full_hash: str, first: bool = False):
    def draw(c, doc):
        c.saveState()
        # BaseDocTemplate applies its defaults after Canvas construction, so bind
        # identity here as well. The validator treats this metadata as mandatory.
        c.setSubject(f"{data['publication_id']} | {data['band_profile']['code']} | master-sha256:{full_hash}")
        c.setKeywords(f"Physics, Grade {data['grade']}, {data['band_profile']['code']}, {data['release_status']}")
        if not first:
            c.setFont("DV-Bold", 7.2)
            c.setFillColor(INK)
            c.drawString(22 * mm, 286 * mm, data["title"][:70])
            c.setFont("DV", 7.2)
            c.setFillColor(MUTED)
            c.drawRightString(188 * mm, 286 * mm, f"{data['band_profile']['code']} • {data['release_status'].replace('_', ' ')}")
            c.setStrokeColor(LIGHT)
            c.line(22 * mm, 283 * mm, 188 * mm, 283 * mm)
        c.setStrokeColor(LIGHT)
        c.line(22 * mm, 14 * mm, 188 * mm, 14 * mm)
        c.setFont("DV", 6.8)
        c.setFillColor(MUTED)
        c.drawString(22 * mm, 9 * mm, f"{data['publication_id']} • master {short_hash}")
        c.drawRightString(188 * mm, 9 * mm, f"Page {doc.page}")
        c.restoreState()
    return draw


def render(master_path: Path, output_path: Path) -> None:
    data = json.loads(master_path.read_text(encoding="utf-8"))
    skill_dir = Path(__file__).resolve().parents[1]
    register_fonts(skill_dir)
    full_hash = master_hash(data)
    short_hash = full_hash[:16]
    styles = build_styles()
    ledger_path = (master_path.parent / data["source_ledger"]).resolve()
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4, leftMargin=22 * mm, rightMargin=22 * mm,
        topMargin=20 * mm, bottomMargin=18 * mm, title=data["title"], author="Grade 9–11 Physics Publication skill",
    )
    story: list = []
    answers: list = []

    story.append(Bookmark("cover", data["title"], 0))
    story.append(Spacer(1, 18 * mm))
    story.append(Paragraph(escape(data["title"]), styles["title"]))
    story.append(Paragraph(escape(data.get("subtitle", "")), styles["subtitle"]))
    status = Table([
        [Paragraph(escape(data["release_status"].replace("_", " ")), styles["cover_meta"])],
        [Paragraph(f"Grade {data['grade']} Physics • {escape(data['band_profile']['code'])} • nominal {data['band_profile']['nominal_prior_knowledge_percent']}% placement hypothesis", styles["cover_meta"])],
        [Paragraph(f"Curriculum profile: {escape(data['curriculum_profile']['name'])}<br/>Status: {escape(data['curriculum_profile']['status'])} • as of {escape(data['curriculum_profile']['as_of_date'])}", styles["body"])],
    ], colWidths=[160 * mm])
    status.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PALE_GOLD), ("BACKGROUND", (0, 1), (-1, 1), PALE_BLUE),
        ("BOX", (0, 0), (-1, -1), 1, INK), ("INNERGRID", (0, 0), (-1, -1), 0.4, LIGHT),
        ("LEFTPADDING", (0, 0), (-1, -1), 5 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 5 * mm),
        ("TOPPADDING", (0, 0), (-1, -1), 4 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 4 * mm),
    ]))
    story.append(status)
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph("Placement note", styles["h2"]))
    story.append(Paragraph(escape(data["band_profile"]["placement_basis"]), styles["body"]))
    story.append(Paragraph("The percentage is an editorial placement hypothesis, not a validated psychometric score. A teacher may override it using diagnostic evidence.", styles["body"]))
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(f"Publication ID: {escape(data['publication_id'])}<br/>Version: {escape(data['version'])}<br/>Canonical master SHA-256: {full_hash}", styles["small"]))
    story.append(PageBreak())

    story.append(Bookmark("contents", "Contents", 0))
    story.append(Paragraph("Contents", styles["h1"]))
    for index, subtopic in enumerate(data["subtopics"], 1):
        story.append(Paragraph(f"{index}. <link href='#{safe_id(subtopic['subtopic_id'])}' color='#173F5F'>{escape(subtopic['title'])}</link>", styles["toc"]))
    story.append(Paragraph(f"<link href='#{safe_id('answer-key')}' color='#173F5F'>Answer and marking appendix</link>", styles["toc"]))
    story.append(Paragraph(f"<link href='#{safe_id('source-ledger')}' color='#173F5F'>Source ledger</link>", styles["toc"]))
    story.append(Paragraph(f"<link href='#{safe_id('review-record')}' color='#173F5F'>Review record and release status</link>", styles["toc"]))
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph("How to use this book", styles["h2"]))
    if data["band_profile"]["code"] == "B30":
        story.append(Paragraph("Attempt each CHECK FIRST item, study the MODEL, complete the faded example, and use the REPAIR MAP immediately when a checkpoint exposes a gap.", styles["body"]))
    else:
        story.append(Paragraph("Retrieve before reading, compare the near-twin cases, attempt unlabelled and transfer questions without method cues, then use the targeted repair route only where an error occurs.", styles["body"]))

    for index, subtopic in enumerate(data["subtopics"], 1):
        story.append(PageBreak())
        story.append(Bookmark(subtopic["subtopic_id"], f"{index}. {subtopic['title']}", 0))
        story.append(Paragraph(f"{index}. {escape(subtopic['title'])}", styles["h1"]))
        story.append(Paragraph(f"<b>Learning goal:</b> {escape(subtopic['learning_goal'])}", styles["body"]))
        story.append(Paragraph("Concept IDs: " + ", ".join(escape(x) for x in subtopic["concept_ids"]), styles["small"]))
        for block in subtopic["blocks"]:
            add_block(story, block, styles, answers)

    story.append(PageBreak())
    story.append(Bookmark("answer-key", "Answer and marking appendix", 0))
    story.append(Paragraph("Answer and marking appendix", styles["h1"]))
    story.append(Paragraph("Keep this appendix separate during independent learner practice. Diagnostic questions carry zero marks but retain answers so feedback is complete.", styles["body"]))
    for question, scored in answers:
        story.append(Bookmark(question["question_id"], question["question_id"], 1))
        label = "SCORED" if scored else "DIAGNOSTIC • NOT SCORED"
        story.append(Paragraph(f"<a name='{safe_id(question['question_id'])}'/><b>{escape(question['question_id'])}</b> • {label} • {question['marks']} marks", styles["answer_title"]))
        story.append(Paragraph(f"<b>Prompt:</b> {escape(question['prompt'])}", styles["answer"]))
        story.append(Paragraph(f"<b>Answer:</b> {escape(question['answer'])}", styles["answer"]))
        story.append(Paragraph(f"<b>Marking:</b> {escape(question['marking_guide'])}", styles["answer"]))
        story.append(Paragraph(f"Primary concept: {escape(question['primary_concept_id'])}", styles["small"]))

    story.append(PageBreak())
    story.append(Bookmark("source-ledger", "Source ledger", 0))
    story.append(Paragraph("Source ledger", styles["h1"]))
    story.append(Paragraph("Source mapping supports traceability. It does not by itself constitute board approval.", styles["body"]))
    for entry in ledger["entries"]:
        story.append(Bookmark("source-" + entry["source_id"], entry["source_id"], 1))
        story.append(Paragraph(f"<a name='{safe_id('source-' + entry['source_id'])}'/><b>{escape(entry['source_id'])}</b>", styles["h2"]))
        url = escape(entry["url"])
        display_url = url if len(url) < 105 else url[:102] + "…"
        if entry["url"].startswith("http"):
            display_url = f"<link href='{url}' color='#1D7874'>{display_url}</link>"
        story.append(Paragraph(f"{escape(entry['title'])}<br/>{escape(entry['publisher'])} • {escape(entry['version_or_date'])}<br/>Locator: {escape(entry['locator'])}<br/>Status: {escape(entry['scope_status'])}<br/>{display_url}", styles["body"]))

    story.append(PageBreak())
    story.append(Bookmark("review-record", "Review record", 0))
    story.append(Paragraph("Review record and release status", styles["h1"]))
    story.append(Paragraph("These entries record editorial evidence. The separate audit JSON contains all computed PDF and content counts.", styles["body"]))
    rows = [[Paragraph("Pass", styles["small"]), Paragraph("Status", styles["small"]), Paragraph("Evidence", styles["small"])]]
    for item in data["review_record"]["passes"]:
        rows.append([Paragraph(escape(item["pass_id"]), styles["small"]), Paragraph(escape(item["status"]), styles["small"]), Paragraph(escape(item["evidence"]), styles["small"])])
    table = Table(rows, colWidths=[35 * mm, 18 * mm, 105 * mm], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), INK), ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("GRID", (0, 0), (-1, -1), 0.4, LIGHT), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 2 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 2 * mm),
        ("TOPPADDING", (0, 0), (-1, -1), 2 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 2 * mm),
    ]))
    story.append(table)
    story.append(Spacer(1, 5 * mm))
    for decision in data["review_record"]["human_decisions"]:
        story.append(Paragraph("Human decision pending: " + escape(decision), styles["body"]))

    doc.build(
        story,
        onFirstPage=page_decorator(data, short_hash, full_hash, first=True),
        onLaterPages=page_decorator(data, short_hash, full_hash, first=False),
        canvasmaker=make_canvas_class(data, full_hash),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("master", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    render(args.master.resolve(), args.output.resolve())
    print(args.output.resolve())


if __name__ == "__main__":
    main()
