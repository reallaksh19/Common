#!/usr/bin/env python3
"""Validate a Physics master/PDF pair and emit computed release evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from pypdf import PdfReader


A4_POINTS = (595.2756, 841.8898)
EXPECTED_PASSES = {
    "P1-SOURCE-SCOPE", "P2-PHYSICS-TEACHER", "P3-B30-STUDENT", "P4-B80-STUDENT",
    "P5-CROSS-BAND", "P6-ASSESSMENT-ROUTES", "P7-PUBLICATION-QA",
}
BLOCK_TYPES = {
    "prerequisite_check", "purpose_anchor", "concept_explanation", "worked_example", "faded_example",
    "misconception_check", "quick_check", "practice", "repair_route", "compression", "discrimination_pair",
    "boundary_case", "unlabelled_stress", "transfer", "preview", "summary",
}


def canonical_hash(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def outline_count(items) -> int:
    count = 0
    for item in items or []:
        if isinstance(item, list):
            count += outline_count(item)
        else:
            count += 1
    return count


def annotation_count(reader: PdfReader) -> int:
    total = 0
    for page in reader.pages:
        annots = page.get("/Annots")
        if annots:
            try:
                total += len(annots.get_object())
            except Exception:
                total += len(annots)
    return total


def validate(master_path: Path, pdf_path: Path) -> dict:
    failures: list[str] = []
    warnings: list[str] = []
    data = json.loads(master_path.read_text(encoding="utf-8"))
    full_hash = canonical_hash(data)
    short_hash = full_hash[:16]

    def require(condition: bool, code: str, message: str) -> None:
        if not condition:
            failures.append(f"{code}: {message}")

    required_top = {
        "schema_version", "publication_id", "version", "title", "subject", "grade", "grade_span",
        "curriculum_profile", "release_status", "band_profile", "source_ledger", "concepts", "subtopics", "review_record",
    }
    require(required_top <= set(data), "SCHEMA-TOP", f"missing keys {sorted(required_top - set(data))}")
    require(data.get("schema_version") == "1.0", "SCHEMA-VERSION", "schema_version must be 1.0")
    require(data.get("subject") == "Physics", "SCOPE-SUBJECT", "subject must be Physics")
    require(isinstance(data.get("grade"), int) and 9 <= data.get("grade", 0) <= 11, "SCOPE-GRADE", "grade must be 9–11")
    require(data.get("grade_span") == [9, 11], "SCOPE-SPAN", "grade_span must be [9, 11]")
    require(data.get("release_status") in {"DRAFT_FOR_APPROVAL", "APPROVED", "RELEASED"}, "SCHEMA-RELEASE", "invalid release_status")
    require(data.get("curriculum_profile", {}).get("status") in {"CURRICULUM_NEUTRAL_DEMO", "SOURCE_MAPPED", "APPROVED"}, "SCOPE-PROFILE", "curriculum profile status missing or invalid")

    band = data.get("band_profile", {}).get("code")
    nominal = data.get("band_profile", {}).get("nominal_prior_knowledge_percent")
    require(band in {"B30", "B50", "B80", "B90"}, "BAND-CODE", "unsupported band")
    require(isinstance(nominal, int) and 0 <= nominal <= 100, "BAND-NOMINAL", "nominal prior knowledge must be 0–100")
    require(data.get("band_profile", {}).get("teacher_override_allowed") is True, "BAND-OVERRIDE", "teacher override must remain available")
    require(len(data.get("band_profile", {}).get("placement_basis", "")) >= 10, "BAND-EVIDENCE", "placement_basis is too short")

    ledger_path = (master_path.parent / data.get("source_ledger", "")).resolve()
    require(ledger_path.is_file(), "SOURCE-LEDGER", f"ledger not found: {ledger_path}")
    ledger = json.loads(ledger_path.read_text(encoding="utf-8")) if ledger_path.is_file() else {"entries": []}
    source_entries = {entry.get("source_id"): entry for entry in ledger.get("entries", [])}
    require(len(source_entries) == len(ledger.get("entries", [])), "SOURCE-ID", "duplicate or missing source_id")
    for source_id, entry in source_entries.items():
        for field in ("title", "publisher", "version_or_date", "url", "locator", "scope_status"):
            require(bool(entry.get(field)), "SOURCE-FIELD", f"{source_id} missing {field}")

    concepts = {item.get("concept_id"): item for item in data.get("concepts", [])}
    require(len(concepts) == len(data.get("concepts", [])), "CONCEPT-ID", "duplicate or missing concept_id")
    for cid, concept in concepts.items():
        require(bool(concept.get("canonical_claim")), "CONCEPT-CLAIM", f"{cid} missing canonical claim")

    seen_ids: set[str] = set(concepts)
    block_ids: set[str] = set()
    question_ids: set[str] = set()
    question_rows: list[dict] = []
    source_refs_used: list[str] = []
    previews = []
    block_type_counts = Counter()
    routes: list[tuple[str, str]] = []
    figure_count = 0

    subtopic_ids = [item.get("subtopic_id") for item in data.get("subtopics", [])]
    require(len(subtopic_ids) == len(set(subtopic_ids)), "SUBTOPIC-ID", "duplicate subtopic_id")
    seen_ids.update(x for x in subtopic_ids if x)
    require(len(data.get("subtopics", [])) >= 2, "SCOPE-SUBTOPICS", "at least two subtopics required")

    required_by_band = {
        "B30": {"prerequisite_check", "purpose_anchor", "concept_explanation", "worked_example", "faded_example", "misconception_check", "practice", "repair_route"},
        "B80": {"compression", "discrimination_pair", "boundary_case", "unlabelled_stress", "transfer", "repair_route"},
    }

    for subtopic in data.get("subtopics", []):
        sid = subtopic.get("subtopic_id", "<missing>")
        for cid in subtopic.get("concept_ids", []):
            require(cid in concepts, "CONCEPT-REF", f"{sid} references unknown concept {cid}")
        local_types = set()
        for block in subtopic.get("blocks", []):
            bid = block.get("block_id")
            require(bool(bid) and bid not in block_ids, "BLOCK-ID", f"duplicate or missing block ID {bid}")
            if bid:
                block_ids.add(bid)
                seen_ids.add(bid)
            btype = block.get("block_type")
            require(btype in BLOCK_TYPES, "BLOCK-TYPE", f"{bid} has invalid type {btype}")
            local_types.add(btype)
            block_type_counts[btype] += 1
            require(bool(block.get("title")) and bool(block.get("body")), "BLOCK-CONTENT", f"{bid} missing title/body")
            require(isinstance(block.get("scored"), bool), "BLOCK-SCORED", f"{bid} must declare scored boolean")
            refs = block.get("source_refs", [])
            require(bool(refs), "SOURCE-REF", f"{bid} has no source reference")
            for ref in refs:
                source_refs_used.append(ref)
                require(ref in source_entries, "SOURCE-UNRESOLVED", f"{bid} references unknown source {ref}")
            provenance = block.get("provenance_class")
            require(provenance in {"CURRICULUM_SOURCE", "ADAPTED", "AUTHOR_CREATED", "ENRICHMENT", "PREVIEW"}, "PROVENANCE", f"{bid} has invalid provenance")
            question = block.get("question")
            if block.get("scored"):
                require(question is not None, "ASSESSMENT-MISSING", f"scored block {bid} has no question")
            if question:
                qid = question.get("question_id")
                require(bool(qid) and qid not in question_ids, "QUESTION-ID", f"duplicate or missing question ID {qid}")
                if qid:
                    question_ids.add(qid)
                    seen_ids.add(qid)
                for field in ("prompt", "primary_concept_id", "answer", "marking_guide"):
                    require(bool(question.get(field)), "ASSESSMENT-FIELD", f"{qid} missing {field}")
                require(question.get("primary_concept_id") in concepts, "ASSESSMENT-CONCEPT", f"{qid} primary concept does not resolve")
                require(isinstance(question.get("marks"), int) and question.get("marks", -1) >= 0, "ASSESSMENT-MARKS", f"{qid} marks invalid")
                if block.get("scored"):
                    require(question.get("marks", 0) > 0, "ASSESSMENT-MARKS", f"scored question {qid} must have positive marks")
                else:
                    require(question.get("marks") == 0, "ASSESSMENT-EXCLUSION", f"unscored question {qid} must have 0 marks")
                question_rows.append({"question_id": qid, "scored": block.get("scored"), "marks": question.get("marks", 0)})
            if block.get("route_to"):
                for target in block["route_to"]:
                    routes.append((bid, target))
            if block.get("figure"):
                figure_count += 1
                fig = block["figure"]
                for field in ("figure_id", "status", "width_mm", "height_mm", "semantic_spec", "caption", "alt_text"):
                    require(fig.get(field) not in (None, ""), "FIGURE-FIELD", f"{bid} figure missing {field}")
                require(fig.get("status") in {"PLACEHOLDER", "FINAL"}, "FIGURE-STATUS", f"{bid} figure status invalid")
                require(fig.get("width_mm", 0) >= 40 and fig.get("height_mm", 0) >= 25, "FIGURE-RESERVE", f"{bid} figure reserve too small")
            if btype == "discrimination_pair":
                contract = block.get("pair_contract", {})
                require(bool(contract.get("changed_feature")), "PAIR-FEATURE", f"{bid} missing one changed feature")
                require(len(contract.get("held_constant", [])) >= 2, "PAIR-CONTROL", f"{bid} must name at least two held-constant features")
            if btype == "preview":
                previews.append(block)
                joined_badges = " | ".join(block.get("badges", [])).upper()
                require(block.get("scored") is False, "PREVIEW-SCORE", f"{bid} preview must be unscored")
                require("PREVIEW" in joined_badges and "NOT SCORED" in joined_badges, "PREVIEW-BADGE", f"{bid} missing preview/not-scored badges")
                require(provenance == "PREVIEW", "PREVIEW-PROVENANCE", f"{bid} preview provenance must be PREVIEW")
            if band == "B80" and btype == "worked_example":
                require(bool(block.get("bridge_rationale")), "BAND-RETEACH", f"{bid} B80 worked example needs bridge_rationale")
        if band in required_by_band:
            missing = required_by_band[band] - local_types
            require(not missing, "BAND-BLOCKS", f"{sid} missing {sorted(missing)} for {band}")

    for source, target in routes:
        require(target in seen_ids or target in source_entries, "ROUTE-UNRESOLVED", f"{source} routes to unknown {target}")

    passes = data.get("review_record", {}).get("passes", [])
    pass_ids = {item.get("pass_id") for item in passes}
    require(pass_ids == EXPECTED_PASSES, "REVIEW-PASSES", f"review passes must be exactly {sorted(EXPECTED_PASSES)}")
    require(not any(item.get("status") == "BLOCK" for item in passes), "REVIEW-BLOCK", "review record contains a blocking pass")
    if data.get("release_status") in {"APPROVED", "RELEASED"}:
        require(all(item.get("status") == "PASS" for item in passes), "REVIEW-STATUS", "approved/released files require all passes PASS")

    require(pdf_path.is_file(), "PDF-MISSING", f"PDF not found: {pdf_path}")
    page_count = 0
    annots = 0
    bookmarks = 0
    page_texts: list[str] = []
    if pdf_path.is_file():
        reader = PdfReader(str(pdf_path))
        page_count = len(reader.pages)
        meta = reader.metadata or {}
        subject = str(meta.get("/Subject", ""))
        require(data.get("publication_id", "") in subject, "PDF-ID", "publication_id absent from PDF metadata")
        require(band in subject, "PDF-BAND", "band absent from PDF metadata")
        require(full_hash in subject, "PDF-HASH", "master hash absent or mismatched in PDF metadata")
        root = reader.trailer["/Root"].get_object()
        lang = root.get("/Lang")
        require(lang is not None and "en" in str(lang).lower(), "PDF-LANG", "PDF language metadata missing")
        for idx, page in enumerate(reader.pages, 1):
            width = float(page.mediabox.width)
            height = float(page.mediabox.height)
            require(abs(width - A4_POINTS[0]) < 1.0 and abs(height - A4_POINTS[1]) < 1.0, "PDF-A4", f"page {idx} is not A4")
            text = page.extract_text() or ""
            page_texts.append(text)
            require(bool(text.strip()), "PDF-EMPTY", f"page {idx} has no extractable text")
            if len(text.strip()) < 180:
                warnings.append(f"DENSITY-LOW: page {idx} has {len(text.strip())} extractable characters")
            if len(text.strip()) > 4200:
                warnings.append(f"DENSITY-HIGH: page {idx} has {len(text.strip())} extractable characters")
        combined = "\n".join(page_texts)
        require(data.get("publication_id", "") in combined, "PDF-ID-VISIBLE", "publication_id not visible")
        require(data.get("release_status", "").replace("_", " ") in combined, "PDF-STATUS-VISIBLE", "release status not visible")
        require(short_hash in combined, "PDF-HASH-VISIBLE", "short master hash not visible")
        require(combined.count(short_hash) >= page_count, "PDF-HASH-FOOTER", "master hash not present on every page")
        for bid in block_ids:
            require(bid in combined, "PDF-BLOCK", f"block ID {bid} missing from PDF text")
        for preview in previews:
            require("NOT SCORED" in combined and "PREVIEW" in combined, "PDF-PREVIEW", f"preview badge not visible for {preview.get('block_id')}")
        annots = annotation_count(reader)
        try:
            bookmarks = outline_count(reader.outline)
        except Exception as exc:
            warnings.append(f"BOOKMARK-READ: could not count outline ({exc})")
        require(annots >= len(data.get("subtopics", [])) + 2, "PDF-LINKS", "too few link annotations for contents/source routes")
        require(bookmarks >= len(data.get("subtopics", [])) + 3, "PDF-BOOKMARKS", "too few bookmarks")

    score_total = sum(item["marks"] for item in question_rows if item["scored"])
    audit = {
        "audit_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "publication_id": data.get("publication_id"),
        "band": band,
        "master_sha256": full_hash,
        "pdf": str(pdf_path),
        "status": "PASS" if not failures else "FAIL",
        "metrics": {
            "pages": page_count,
            "subtopics": len(data.get("subtopics", [])),
            "concepts": len(concepts),
            "blocks": len(block_ids),
            "block_types": dict(sorted(block_type_counts.items())),
            "questions": len(question_rows),
            "scored_questions": sum(1 for item in question_rows if item["scored"]),
            "score_total": score_total,
            "previews_excluded": len(previews),
            "source_entries": len(source_entries),
            "source_refs_used": len(source_refs_used),
            "routes": len(routes),
            "figures": figure_count,
            "link_annotations": annots,
            "bookmarks": bookmarks,
        },
        "failures": failures,
        "warnings": warnings,
        "human_gate": "Page-by-page visual inspection remains required even when status is PASS.",
    }
    return audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("master", type=Path)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--audit", type=Path)
    args = parser.parse_args()
    audit = validate(args.master.resolve(), args.pdf.resolve())
    rendered = json.dumps(audit, indent=2, ensure_ascii=False)
    if args.audit:
        args.audit.parent.mkdir(parents=True, exist_ok=True)
        args.audit.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    sys.exit(0 if audit["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
