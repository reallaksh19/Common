#!/usr/bin/env python3
"""Adversarial tests for identity, assessment, band, route, and preview gates."""

import argparse
import copy
import json
import tempfile
from pathlib import Path

from check_physics_publication import validate


def first_block(master, predicate):
    for subtopic in master["subtopics"]:
        for block in subtopic["blocks"]:
            if predicate(block):
                return block
    raise AssertionError("requested test block not found")


def save(folder: Path, name: str, data: dict, ledger: Path) -> Path:
    path = folder / name
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    target_ledger = folder / data["source_ledger"]
    if not target_ledger.exists():
        target_ledger.write_bytes(ledger.read_bytes())
    return path


def has_code(audit: dict, code: str) -> bool:
    return any(item.startswith(code + ":") for item in audit["failures"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("b30_master", type=Path)
    parser.add_argument("b30_pdf", type=Path)
    parser.add_argument("b80_master", type=Path)
    parser.add_argument("b80_pdf", type=Path)
    args = parser.parse_args()
    b30 = json.loads(args.b30_master.read_text(encoding="utf-8"))
    b80 = json.loads(args.b80_master.read_text(encoding="utf-8"))
    ledger = args.b30_master.parent / b30["source_ledger"]
    results = []

    cross_a = validate(args.b30_master.resolve(), args.b80_pdf.resolve())
    cross_b = validate(args.b80_master.resolve(), args.b30_pdf.resolve())
    assert has_code(cross_a, "PDF-ID") and has_code(cross_a, "PDF-HASH")
    assert has_code(cross_b, "PDF-ID") and has_code(cross_b, "PDF-HASH")
    results.append("cross-band JSON/PDF pairing rejected")

    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)

        missing_answer = copy.deepcopy(b30)
        first_block(missing_answer, lambda x: x.get("scored"))["question"]["answer"] = ""
        path = save(folder, "missing-answer.json", missing_answer, ledger)
        audit = validate(path, args.b30_pdf.resolve())
        assert has_code(audit, "ASSESSMENT-FIELD")
        results.append("missing scored answer rejected")

        reteach = copy.deepcopy(b80)
        first_block(reteach, lambda x: x["block_type"] == "compression")["block_type"] = "worked_example"
        path = save(folder, "b80-reteach.json", reteach, ledger)
        audit = validate(path, args.b80_pdf.resolve())
        assert has_code(audit, "BAND-RETEACH")
        results.append("unjustified B80 worked example rejected")

        broken_route = copy.deepcopy(b30)
        first_block(broken_route, lambda x: x["block_type"] == "repair_route")["route_to"] = ["DOES-NOT-EXIST"]
        path = save(folder, "broken-route.json", broken_route, ledger)
        audit = validate(path, args.b30_pdf.resolve())
        assert has_code(audit, "ROUTE-UNRESOLVED")
        results.append("broken repair route rejected")

        scored_preview = copy.deepcopy(b80)
        preview = first_block(scored_preview, lambda x: x["block_type"] == "preview")
        preview["scored"] = True
        path = save(folder, "scored-preview.json", scored_preview, ledger)
        audit = validate(path, args.b80_pdf.resolve())
        assert has_code(audit, "PREVIEW-SCORE")
        results.append("scored preview rejected")

    print(json.dumps({"status": "PASS", "tests": results}, indent=2))


if __name__ == "__main__":
    main()
