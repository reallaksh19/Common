# Publication content contract

The normative machine-readable contract is [physics-publication.schema.json](physics-publication.schema.json). This note explains authoring decisions that a JSON Schema cannot fully express.

## Stable identifiers

- `publication_id`: unique release identity, such as `PHY-G9-MOTION-B30-DEMO-v1`.
- `subtopic_id`: stable across matched bands.
- `concept_id`: stable, atomic Physics meaning.
- `block_id`: unique instructional block and PDF anchor.
- `question_id`: unique scored or unscored prompt.
- `source_id`: resolved by the separate source ledger.

Never recycle an identifier for a changed meaning. Increment the version or mint a new ID.

## Provenance

Each content block declares `source_refs` and one of:

- `CURRICULUM_SOURCE`: traceable to a dated board/curriculum source;
- `ADAPTED`: editorial transformation of a cited source;
- `AUTHOR_CREATED`: original explanation or question, still checked for scope and Physics correctness;
- `ENRICHMENT`: outside core curriculum but permitted by the profile;
- `PREVIEW`: explicitly higher-grade, optional, and unscored.

The source ledger records title, publisher, date/version, URL or attachment name, locator, scope status, and verification date. A bare label such as `NCERT` is not a citation.

## Content blocks

Every block contains title, learner-facing body, badges, provenance, and source references. `question` blocks also contain prompt, answer, marking guide, marks, and exactly one `primary_concept_id`. Optional secondary concepts do not replace the primary diagnostic target.

`route_to` contains stable target IDs. Targets must resolve to a block, question, concept, or source-ledger entry. If the repair is not included, use a source-ledger entry whose `scope_status` is `EXTERNAL_REPAIR_REQUIRED`; do not write an unresolvable sentence.

`figure` reserves a physical width and height and gives a semantic specification, caption, alt text, and production status (`PLACEHOLDER` or `FINAL`). The renderer must preserve the reserve even when artwork is missing.

## PDF identity

Render from canonical UTF-8 JSON (sorted keys, compact separators). Compute SHA-256 and print the first 16 hexadecimal characters on the cover and every footer. Store the full hash in PDF metadata. The checker compares the supplied JSON hash with metadata and visible text, which prevents a B30 master from validating a B80 PDF.

## Generated audit

The checker generates counts from the current inputs: pages, blocks, scored questions, answer coverage, source coverage, preview exclusions, route closure, internal links, bookmarks, and page geometry. Do not store those counts as claims in the content master.
