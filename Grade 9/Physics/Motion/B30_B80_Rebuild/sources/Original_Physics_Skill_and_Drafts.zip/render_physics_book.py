#!/usr/bin/env python3
"""Render a Grade 9-11 Physics learning book from a band-aware publication JSON.

Usage:
    python render_physics_book.py book.json out.pdf

The renderer implements the reserve -> draw -> advance discipline required by
grade9-physics-publication: every block measures itself, reserves vertical
space, draws, then advances. Nothing continues from a guessed y-coordinate.

Fonts: DejaVu is registered for full glyph coverage (subscripts, superscripts,
arrows, Greek, middot). Built-in ReportLab fonts must not be used for physics
notation - they render missing glyphs as black boxes.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, CondPageBreak, Flowable, Frame, KeepTogether, PageBreak,
    PageTemplate, Paragraph, Spacer, Table, TableStyle,
)

FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
PAGE_W, PAGE_H = A4
M_L, M_R, M_T, M_B = 18 * mm, 16 * mm, 18 * mm, 16 * mm
CONTENT_W = PAGE_W - M_L - M_R

# ---------------------------------------------------------------- palette
INK = colors.HexColor("#14181F")
MUTE = colors.HexColor("#5B6472")
RULE = colors.HexColor("#D6DBE2")
WASH = colors.HexColor("#F4F6F9")

BAND_COLOR = {
    "B30": colors.HexColor("#1D6F5C"),
    "B50": colors.HexColor("#2F5FA8"),
    "B80": colors.HexColor("#8A4B12"),
    "B90": colors.HexColor("#7A2E5E"),
}

BADGE_STYLE = {
    "BAND":      ("#1D6F5C", "#E6F2EE"),
    "SOURCE":    ("#2F5FA8", "#E8EFF9"),
    "VALUE_ADD": ("#6B5AA8", "#EFECF8"),
    "MODEL":     ("#8A4B12", "#FBF0E4"),
    "NOT_SCORED":("#8A1C3B", "#FBE9EE"),
    "SCORED":    ("#1D6F5C", "#E6F2EE"),
    "HINT":      ("#5B6472", "#EEF0F3"),
    "PREREQ":    ("#A33A0F", "#FCEDE6"),
    "GAP":       ("#8A1C3B", "#FBE9EE"),
    "PREVIEW":   ("#7A2E5E", "#F6EAF2"),
    "PLACEHOLDER": ("#A33A0F", "#FCEDE6"),
}


def register_fonts() -> None:
    pdfmetrics.registerFont(TTFont("DJ", str(FONT_DIR / "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DJ-B", str(FONT_DIR / "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFont(TTFont("DJ-I", str(FONT_DIR / "DejaVuSans-Oblique.ttf")))
    pdfmetrics.registerFont(TTFont("DJ-M", str(FONT_DIR / "DejaVuSansMono.ttf")))
    pdfmetrics.registerFontFamily("DJ", normal="DJ", bold="DJ-B", italic="DJ-I")


def styles():
    def st(name, **kw):
        kw.setdefault("fontName", "DJ")
        kw.setdefault("textColor", INK)
        kw.setdefault("alignment", TA_LEFT)
        return ParagraphStyle(name, **kw)
    return {
        "h1b": st("h1b", fontName="DJ-B", fontSize=19, leading=23, spaceAfter=1),
        "h2": st("h2", fontName="DJ-B", fontSize=12.5, leading=15.5,
                 spaceBefore=3, spaceAfter=2),
        "h3": st("h3", fontName="DJ-B", textColor=MUTE, fontSize=8.4,
                 leading=11, spaceAfter=2),
        "body": st("body", fontSize=9.5, leading=13.0, spaceAfter=2),
        "small": st("small", fontSize=8.3, leading=11.4, textColor=MUTE),
        "mono": st("mono", fontName="DJ-M", fontSize=8.6, leading=12.4),
        "eq": st("eq", fontSize=10.6, leading=15, spaceBefore=2, spaceAfter=2),
        "cap": st("cap", fontName="DJ-I", fontSize=8.2, leading=10.8, textColor=MUTE),
    }


S = None  # populated in main


# ---------------------------------------------------------------- flowables
class Badges(Flowable):
    """A row of small pill badges. Measures itself, so it never overlaps."""

    def __init__(self, items, width=CONTENT_W):
        super().__init__()
        self.items = [i for i in items if i]
        self.width = width
        self.h = 12 if self.items else 0

    def wrap(self, aw, ah):
        return (self.width, self.h)

    def draw(self):
        c = self.canv
        x = 0
        for kind, label in self.items:
            fg, bg = BADGE_STYLE.get(kind, ("#5B6472", "#EEF0F3"))
            c.setFont("DJ-B", 6.4)
            tw = c.stringWidth(label, "DJ-B", 6.4)
            w = tw + 10
            if x + w > self.width:
                break
            c.setFillColor(colors.HexColor(bg))
            c.roundRect(x, 0, w, 10.5, 2.4, stroke=0, fill=1)
            c.setFillColor(colors.HexColor(fg))
            c.drawString(x + 5, 3.2, label)
            x += w + 4


class Rule(Flowable):
    def __init__(self, width=CONTENT_W, color=RULE, thick=0.6, pad=3):
        super().__init__()
        self.width, self.color, self.thick, self.pad = width, color, thick, pad

    def wrap(self, aw, ah):
        return (self.width, self.thick + 2 * self.pad)

    def draw(self):
        self.canv.setStrokeColor(self.color)
        self.canv.setLineWidth(self.thick)
        self.canv.line(0, self.pad, self.width, self.pad)


class FigurePlaceholder(Flowable):
    """A reserved, measured figure slot carrying its own semantic spec.

    The box is the deliverable at draft stage: it holds exact bounds so that
    inserting the real artwork later cannot reflow the page.
    """

    def __init__(self, spec, width=CONTENT_W):
        super().__init__()
        self.spec = spec
        self.width = width
        self.h = float(spec.get("reserve_mm", 46)) * mm

    def wrap(self, aw, ah):
        return (self.width, self.h)

    def draw(self):
        c = self.canv
        c.saveState()
        c.setDash(3, 2)
        c.setStrokeColor(colors.HexColor("#B9C2CE"))
        c.setFillColor(colors.HexColor("#FAFBFC"))
        c.roundRect(0, 0, self.width, self.h, 3, stroke=1, fill=1)
        c.setDash()

        fid = self.spec.get("figure_id", "FIG-?")
        c.setFillColor(colors.HexColor("#A33A0F"))
        c.setFont("DJ-B", 7)
        c.drawString(8, self.h - 13, f"PLACEHOLDER  {fid}   status={self.spec.get('status','RESERVED')}")

        c.setFillColor(MUTE)
        c.setFont("DJ", 7.6)
        y = self.h - 25
        for line in self.spec.get("semantic_spec", [])[:7]:
            c.drawString(8, y, "• " + line[:104])
            y -= 9.4
        c.setFont("DJ-I", 6.8)
        c.drawRightString(self.width - 8, 6,
                          f"reserve {self.spec.get('reserve_mm',46)}mm · "
                          f"src {', '.join(self.spec.get('source_obligation_ids') or ['VALUE_ADD'])}")
        c.restoreState()


class Panel(Flowable):
    """Tinted panel wrapper: measures inner flowables first, then draws."""

    def __init__(self, inner, width=CONTENT_W, tint=WASH, accent=None, pad=7):
        super().__init__()
        self.inner, self.width, self.tint, self.accent, self.pad = inner, width, tint, accent, pad
        self._h = None

    def wrap(self, aw, ah):
        iw = self.width - 2 * self.pad - (3 if self.accent else 0)
        total = 0
        for f in self.inner:
            _, h = f.wrap(iw, ah)
            total += h
        self._h = total + 2 * self.pad
        return (self.width, self._h)

    def draw(self):
        c = self.canv
        c.setFillColor(self.tint)
        c.roundRect(0, 0, self.width, self._h, 3, stroke=0, fill=1)
        if self.accent:
            c.setFillColor(self.accent)
            c.roundRect(0, 0, 3, self._h, 1.4, stroke=0, fill=1)
        xoff = self.pad + (5 if self.accent else 0)
        iw = self.width - 2 * self.pad - (3 if self.accent else 0)
        y = self._h - self.pad
        for f in self.inner:
            _, h = f.wrap(iw, self._h)
            f.drawOn(c, xoff, y - h)
            y -= h


class WorkZone(Flowable):
    """Ruled working space. Counts as meaningful occupancy under the density rule."""

    def __init__(self, lines=4, width=CONTENT_W, label="working space"):
        super().__init__()
        self.lines, self.width, self.label = lines, width, label
        self.h = 11 + lines * 13

    def wrap(self, aw, ah):
        return (self.width, self.h)

    def draw(self):
        c = self.canv
        c.setFont("DJ-I", 6.8)
        c.setFillColor(MUTE)
        c.drawString(0, self.h - 8, self.label)
        c.setStrokeColor(colors.HexColor("#E3E7EC"))
        c.setLineWidth(0.5)
        y = self.h - 20
        for _ in range(self.lines):
            c.line(0, y, self.width, y)
            y -= 13


# ---------------------------------------------------------------- block build
def para(t, st="body"):
    return Paragraph(t, S[st])


def kv_table(rows, widths=None):
    widths = widths or [42 * mm, CONTENT_W - 42 * mm]
    data = [[Paragraph(f"<b>{k}</b>", S["small"]), Paragraph(v, S["body"])] for k, v in rows]
    t = Table(data, colWidths=widths, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("LINEBELOW", (0, 0), (-1, -2), 0.4, RULE),
    ]))
    return t


def grid_table(header, rows, widths):
    data = [[Paragraph(f"<b>{h}</b>", S["small"]) for h in header]]
    for r in rows:
        data.append([Paragraph(str(x), S["body"]) for x in r])
    t = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=1)
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (-1, 0), WASH),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("GRID", (0, 0), (-1, -1), 0.4, RULE),
    ]))
    return t


def section_head(label, title, badges=None):
    out = [Paragraph(label.upper(), S["h3"]), Paragraph(title, S["h2"])]
    if badges:
        out.append(Badges(badges))
        out.append(Spacer(1, 2))
    return out


def build_block(b, band):
    """Dispatch one schema block to flowables."""
    t = b["type"]
    out = []
    badges = [(x["kind"], x["label"]) for x in b.get("badges", [])]

    if t == "purpose_anchor":
        inner = [Paragraph("THE SITUATION", S["h3"])]
        inner += [para(p) for p in b["paragraphs"]]
        out += [Panel(inner, accent=BAND_COLOR.get(band, INK), tint=colors.HexColor("#EDF4F1"))]
        out += [Spacer(1, 3)]

    elif t == "prereq_check":
        inner = [Paragraph("PREREQUISITE CHECK — RUN THIS FIRST", S["h3"]),
                 para(f"<b>Ask:</b> {b['ask']}"),
                 para(f"<b>If they cannot:</b> {b['on_fail']}")]
        out += [Panel(inner, tint=colors.HexColor("#FCEDE6"),
                      accent=colors.HexColor("#A33A0F")),
                Spacer(1, 3)]

    elif t == "heading":
        out += section_head(b.get("label", ""), b["title"], badges)

    elif t == "prose":
        out += [para(p) for p in b["paragraphs"]]

    elif t == "worked":
        out += section_head("WORKED — NOTHING LEFT OUT", b["title"], badges)
        out += [kv_table([(s["step"], s["text"]) for s in b["steps"]]), Spacer(1, 3)]
        if b.get("result"):
            parts = [x.strip() for x in b["result"].split("|") if x.strip()]
            out += [Panel([Paragraph(x, S["eq"]) for x in parts],
                          tint=colors.HexColor("#E8EFF9"))]
        out += [Spacer(1, 3)]

    elif t == "name_card":
        inner = [Paragraph("NOW IT GETS ITS NAME", S["h3"]),
                 Paragraph(b["statement"], S["eq"])]
        if b.get("note"):
            inner.append(para(b["note"], "small"))
        out += [Panel(inner, tint=colors.HexColor("#FBF6E4"),
                      accent=colors.HexColor("#8A6D12")), Spacer(1, 3)]

    elif t == "fade_ladder":
        out += section_head("FADE — SUPPORT COMES OFF ONE STEP AT A TIME", b["title"], badges)
        rows = [[s["stage"], s["given"], s["task"]] for s in b["stages"]]
        out += [grid_table(["Stage", "What you are given", "What you do"], rows,
                           [26 * mm, 62 * mm, CONTENT_W - 88 * mm]), Spacer(1, 3)]
        if b.get("work_lines"):
            out += [WorkZone(b["work_lines"]), Spacer(1, 3)]

    elif t == "notice":
        inner = [Paragraph("NOTICE — YOUR FIRST REAL CHOICE", S["h3"]),
                 para(f"<b>{b['question']}</b>")]
        if b.get("expected"):
            inner.append(para(f"<i>Looking for:</i> {b['expected']}", "small"))
        out += [Panel(inner, tint=colors.HexColor("#EFECF8"),
                      accent=colors.HexColor("#6B5AA8")), Spacer(1, 3)]

    elif t == "exit_check":
        inner = [Paragraph("EXIT CHECK — NO NUMBERS", S["h3"]), para(b["question"])]
        out += [Panel(inner, tint=colors.HexColor("#E6F2EE"),
                      accent=colors.HexColor("#1D6F5C"))]
        out += [WorkZone(b.get("work_lines", 3), label="your reasoning"), Spacer(1, 3)]

    elif t == "compression_card":
        out += section_head("COMPRESSION CARD", b["title"], badges)
        rows = [[k, v] for k, v in b["rows"]]
        out += [grid_table(["", ""], rows, [30 * mm, CONTENT_W - 30 * mm]), Spacer(1, 3)]

    elif t == "discrimination":
        out += section_head("DISCRIMINATION — ONE FEATURE CHANGES", b["title"], badges)
        rows = [[p["a"], p["b"], p["differs"], p["methods"]] for p in b["pairs"]]
        out += [grid_table(["A", "B", "Differs in", "Correct handling"], rows,
                           [46 * mm, 46 * mm, 28 * mm, CONTENT_W - 120 * mm]),
                Spacer(1, 3),
                para(b.get("required_output", ""), "small"), Spacer(1, 3)]

    elif t == "stress_set":
        out += section_head("STRESS SET — UNLABELLED, TIMED", b["title"], badges)
        out += [para(f"<b>{b['instructions']}</b>"), Spacer(1, 2)]
        rows = [[str(i + 1), q] for i, q in enumerate(b["items"])]
        out += [grid_table(["#", "Question"], rows, [10 * mm, CONTENT_W - 10 * mm]),
                Spacer(1, 3)]
        if b.get("marking"):
            out += [para("<b>Mark into four buckets:</b> " + b["marking"], "small")]
        out += [Spacer(1, 3)]

    elif t == "boundary_set":
        out += section_head("BOUNDARY — WHERE STRONG STUDENTS FALL", b["title"], badges)
        out += [para("• " + x) for x in b["items"]]
        out += [Spacer(1, 3)]

    elif t == "preview":
        inner = [Paragraph("WHERE THIS GOES NEXT — NOT ASSESSED", S["h3"])]
        inner += [para(p) for p in b["paragraphs"]]
        if b.get("try_it"):
            inner.append(para(f"<b>Try it:</b> {b['try_it']}"))
        out += [Panel(inner, tint=colors.HexColor("#F6EAF2"),
                      accent=colors.HexColor("#7A2E5E")), Spacer(1, 3)]

    elif t == "misconception":
        inner = [Paragraph(f"COMMON TRAP · {b['id']}", S["h3"]),
                 para(f"<b>The wrong idea:</b> {b['wrong_model']}"),
                 para(f"<b>Why it is tempting:</b> {b['why_attractive']}"),
                 para(f"<b>Probe:</b> {b['diagnostic_probe']}"),
                 para(f"<b>Repair:</b> {b['repair']}")]
        out += [Panel(inner, tint=colors.HexColor("#FBE9EE"),
                      accent=colors.HexColor("#8A1C3B")), Spacer(1, 3)]

    elif t == "gap_map":
        out += section_head("IF YOU GOT IT WRONG", b.get("title", "Gap map"), badges)
        rows = [[g["wrong"], g["gap"], g["route"]] for g in b["rows"]]
        out += [grid_table(["What you wrote", "What it means", "Go to"], rows,
                           [58 * mm, 44 * mm, CONTENT_W - 102 * mm]), Spacer(1, 3)]

    elif t == "figure":
        out += [FigurePlaceholder(b), Spacer(1, 2)]
        if b.get("caption"):
            out += [para(b["caption"], "cap")]
        out += [Spacer(1, 3)]

    elif t == "equation":
        out += [Paragraph(b["latex_free"], S["eq"])]
        if b.get("note"):
            out += [para(b["note"], "small")]
        out += [Spacer(1, 3)]

    elif t == "practice":
        out += section_head("PRACTICE", b["title"], badges)
        rows = [[q["id"], q["text"], q.get("relationship", "")] for q in b["items"]]
        out += [grid_table(["ID", "Question", "Type"], rows,
                           [16 * mm, CONTENT_W - 46 * mm, 30 * mm]), Spacer(1, 3)]
        if b.get("work_lines"):
            out += [WorkZone(b["work_lines"]), Spacer(1, 3)]

    elif t == "callout":
        out += [Panel([Paragraph(b["label"].upper(), S["h3"]),
                       para(b["text"])], tint=WASH), Spacer(1, 3)]

    else:
        out += [para(f"[unrendered block type: {t}]", "small")]

    # citation strip
    src = b.get("source_obligation_ids")
    if src:
        out.append(Paragraph("source: " + ", ".join(src), S["cap"]))
        out.append(Spacer(1, 3))
    return out


# ---------------------------------------------------------------- document
class Doc(BaseDocTemplate):
    def __init__(self, path, meta, **kw):
        super().__init__(path, pagesize=A4, leftMargin=M_L, rightMargin=M_R,
                         topMargin=M_T, bottomMargin=M_B, **kw)
        self.meta = meta
        frame = Frame(M_L, M_B, CONTENT_W, PAGE_H - M_T - M_B, id="body",
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        self.addPageTemplates([PageTemplate(id="main", frames=[frame],
                                            onPage=self._chrome)])

    def _chrome(self, c, doc):
        m = self.meta
        band = m["band"]
        col = BAND_COLOR.get(band, INK)
        c.saveState()
        # header rule + running head
        c.setStrokeColor(RULE)
        c.setLineWidth(0.6)
        c.line(M_L, PAGE_H - M_T + 7, PAGE_W - M_R, PAGE_H - M_T + 7)
        c.setFont("DJ", 7.2)
        c.setFillColor(MUTE)
        c.drawString(M_L, PAGE_H - M_T + 11, m["title"])
        c.setFont("DJ-B", 7.2)
        c.setFillColor(col)
        c.drawRightString(PAGE_W - M_R, PAGE_H - M_T + 11,
                          f"{band} · {m['band_label']}")
        # footer
        c.setStrokeColor(RULE)
        c.line(M_L, M_B - 8, PAGE_W - M_R, M_B - 8)
        c.setFont("DJ", 6.8)
        c.setFillColor(MUTE)
        c.drawString(M_L, M_B - 17, f"{m['publication_id']} · build {m['build_contract_ref']} · {m['sign_convention']}")
        c.setFont("DJ-B", 8)
        c.setFillColor(INK)
        c.drawRightString(PAGE_W - M_R, M_B - 17, str(doc.page))
        c.restoreState()


def cover(meta):
    band = meta["band"]
    col = BAND_COLOR.get(band, INK)
    out = [Spacer(1, 6),
           Paragraph(meta["series"].upper(), S["h3"]),
           Paragraph(meta["title"], S["h1b"]),
           Spacer(1, 3),
           Paragraph(meta["subtitle"], S["body"]),
           Spacer(1, 6),
           Badges([("BAND", f"BAND {band} · {meta['band_label']}"),
                   ("SOURCE", f"GRADE {meta['grade']}"),
                   ("HINT", meta["hint_policy_badge"])]),
           Spacer(1, 8), Rule(), Spacer(1, 3)]

    out += [Paragraph("WHO THIS BOOK IS FOR", S["h3"]),
            Paragraph(meta["audience"], S["body"]), Spacer(1, 3)]

    out += [Paragraph("CONVENTIONS FIXED FOR THIS BOOK", S["h3"])]
    rows = [("Frame", meta["frame"]),
            ("Sign convention", meta["sign_convention"]),
            ("Symbols", "; ".join(f"{k} = {v}" for k, v in meta["symbol_table"].items())),
            ("Source ledger", meta["source_ledger_id"]),
            ("Band placement", meta["placement_note"])]
    out += [kv_table(rows), Spacer(1, 6)]

    out += [Paragraph("WHAT IS INSIDE", S["h3"])]
    toc = [[s["subtopic_id"], s["title"], s["concept_id"]] for s in meta["contents"]]
    out += [grid_table(["Subtopic", "Title", "Concept ID"], toc,
                       [24 * mm, CONTENT_W - 64 * mm, 40 * mm])]
    out += [Spacer(1, 6),
            Paragraph("HOW THIS BAND WORKS", S["h3"])]
    out += [Panel([Paragraph(meta["band_rationale"], S["body"])], tint=WASH,
                  accent=BAND_COLOR.get(band, INK))]
    if meta.get("how_to_use"):
        out += [Spacer(1, 5), Paragraph("HOW TO USE IT", S["h3"])]
        out += [grid_table(["Do this", "Because"],
                           [[a, b] for a, b in meta["how_to_use"]],
                           [62 * mm, CONTENT_W - 62 * mm])]
    return out


def ledger_appendix(book):
    out = [PageBreak(),
           Paragraph("APPENDIX", S["h3"]),
           Paragraph("Source, link and badge ledger", S["h2"]),
           Paragraph("Every teaching block traces to a source obligation or is "
                     "declared VALUE_ADD. Nothing in this book is unattributed.",
                     S["body"]),
           Spacer(1, 3)]
    rows = []
    for st in book["subtopics"]:
        for b in st["blocks"]:
            srcs = b.get("source_obligation_ids") or ["VALUE_ADD"]
            rows.append([st["subtopic_id"], b["type"], ", ".join(srcs)])
    out += [grid_table(["Subtopic", "Block", "Source obligation"], rows,
                       [22 * mm, 40 * mm, CONTENT_W - 62 * mm]), Spacer(1, 6)]

    figs = [b for st in book["subtopics"] for b in st["blocks"] if b["type"] == "figure"]
    if figs:
        out += [Paragraph("Figure placeholders awaiting artwork", S["h2"])]
        rows = [[f["figure_id"], f.get("status", "RESERVED"),
                 f"{f.get('reserve_mm',46)} mm", f.get("caption", "")[:70]] for f in figs]
        out += [grid_table(["Figure", "Status", "Reserved", "Caption"], rows,
                           [24 * mm, 26 * mm, 20 * mm, CONTENT_W - 70 * mm]),
                Spacer(1, 6)]

    out += [KeepTogether([Paragraph("Audit checkpoints cleared at render time", S["h2"]),
            grid_table(["Checkpoint", "Result"],
                       [[k, v] for k, v in book["audit"]["checkpoints"].items()],
                       [70 * mm, CONTENT_W - 70 * mm])])]
    return out


def main():
    global S
    src, out_path = sys.argv[1], sys.argv[2]
    book = json.loads(Path(src).read_text())
    register_fonts()
    S = styles()

    meta = book["publication"]
    meta["contents"] = [{"subtopic_id": s["subtopic_id"], "title": s["title"],
                         "concept_id": s["concept_id"]} for s in book["subtopics"]]

    doc = Doc(out_path, meta, title=meta["title"], author=meta["series"],
              subject=f"Band {meta['band']}")
    story = cover(meta)

    for n, st in enumerate(book["subtopics"]):
        if n or story:
            story.append(CondPageBreak(420))
        story.append(Paragraph(f"{st['subtopic_id']} · {st['concept_id']}", S["h3"]))
        story.append(Paragraph(st["title"], S["h1b"]))
        story.append(Badges([("BAND", f"BAND {meta['band']}")] +
                            [(b["kind"], b["label"]) for b in st.get("badges", [])]))
        story.append(Spacer(1, 3))
        story.append(Rule())
        story.append(Spacer(1, 3))
        for b in st["blocks"]:
            flow = build_block(b, meta["band"])
            if b.get("keep_together"):
                story.append(KeepTogether(flow))
            else:
                story.extend(flow)

    story.extend(ledger_appendix(book))
    doc.build(story)
    print(f"rendered {out_path}")


if __name__ == "__main__":
    main()
