#!/usr/bin/env python3
"""Audit a rendered physics book against grade9-physics-publication gates.

Usage:
    python check_physics_publication.py book.json book.pdf

Exits non-zero on any BLOCK-level failure. WARN rows do not block release but
must be acknowledged in the drift register.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pdfplumber

# Which block types are legal in which band. A B90 block in a B30 book is not a
# style problem - it means the book is teaching two different students at once.
BAND_BLOCKS = {
    "B30": {"prereq_check", "purpose_anchor", "figure", "worked", "name_card",
            "fade_ladder", "notice", "exit_check", "misconception", "gap_map",
            "prose", "equation", "practice", "callout", "heading"},
    "B50": {"prereq_check", "purpose_anchor", "figure", "worked", "name_card",
            "notice", "exit_check", "misconception", "gap_map", "prose",
            "equation", "practice", "callout", "heading", "discrimination",
            "boundary_set"},
    "B80": {"compression_card", "discrimination", "stress_set", "boundary_set",
            "preview", "gap_map", "figure", "prose", "equation", "callout",
            "heading", "misconception", "practice"},
    "B90": {"compression_card", "discrimination", "stress_set", "boundary_set",
            "preview", "gap_map", "figure", "prose", "equation", "callout",
            "heading", "misconception", "practice"},
}

# Blocks that re-teach. Their presence in a high-band book is a band-drift failure.
RETEACH_BLOCKS = {"worked", "name_card", "fade_ladder", "purpose_anchor"}

# Blocks that can generate a wrong answer, and therefore need gap routing.
ANSWERABLE = {"fade_ladder", "practice", "stress_set", "exit_check", "discrimination"}


def audit(book_path: str, pdf_path: str):
    book = json.loads(Path(book_path).read_text())
    meta = book["publication"]
    band = meta["band"]
    rows = []          # (level, gate, detail)

    def add(level, gate, detail):
        rows.append((level, gate, detail))

    blocks = [(st, b) for st in book["subtopics"] for b in st["blocks"]]

    # --- G1 band declared -------------------------------------------------
    add("PASS" if band in BAND_BLOCKS else "BLOCK", "SRU-23 BAND_DECLARED",
        f"band={band}")

    # --- G2 band fidelity (D1) --------------------------------------------
    allowed = BAND_BLOCKS.get(band, set())
    illegal = sorted({b["type"] for _, b in blocks if b["type"] not in allowed})
    add("BLOCK" if illegal else "PASS", "D1 BAND_FIDELITY",
        f"illegal block types: {illegal}" if illegal else
        f"all {len(blocks)} blocks legal for {band}")

    # --- G3 re-teaching in a high band ------------------------------------
    if band in ("B80", "B90"):
        bad = [b["type"] for _, b in blocks if b["type"] in RETEACH_BLOCKS]
        add("BLOCK" if bad else "PASS", "D1 NO_RETEACH_AT_HIGH_BAND",
            f"re-teaching blocks present: {bad}" if bad else "none present")

    # --- G4 citation closure ----------------------------------------------
    uncited = [(st["subtopic_id"], b["type"]) for st, b in blocks
               if b.get("source_obligation_ids") is None]
    add("BLOCK" if uncited else "PASS", "CITATION_CLOSURE",
        f"blocks with no source key at all: {uncited}" if uncited else
        f"{len(blocks)} blocks carry a source key "
        f"({sum(1 for _, b in blocks if b.get('source_obligation_ids'))} cited, "
        f"{sum(1 for _, b in blocks if b.get('source_obligation_ids') == [])} VALUE_ADD)")

    # --- G5 preview fencing (§4.1) ----------------------------------------
    previews = [b for _, b in blocks if b["type"] == "preview"]
    if band in ("B30", "B50") and previews:
        add("BLOCK", "PREVIEW_LEAKAGE", f"{len(previews)} preview blocks in {band}")
    elif previews:
        unbadged = [p for p in previews
                    if not any(x["kind"] == "NOT_SCORED" for x in p.get("badges", []))]
        add("BLOCK" if unbadged else "PASS", "PREVIEW_FENCED",
            f"{len(unbadged)} preview blocks missing NOT_SCORED badge" if unbadged
            else f"{len(previews)} preview block(s), all marked NOT_SCORED")
    else:
        add("PASS", "PREVIEW_FENCED", "no preview blocks (correct for this band)")

    # --- G6 gap routing (SRU-19 / SRU-26) ---------------------------------
    for st in book["subtopics"]:
        types = {b["type"] for b in st["blocks"]}
        if types & ANSWERABLE and "gap_map" not in types:
            add("BLOCK", "SRU-19 GAP_MAP_COVERAGE",
                f"{st['subtopic_id']} has answerable blocks but no gap map")
    if not any(r[1].startswith("SRU-19") for r in rows):
        add("PASS", "SRU-19 GAP_MAP_COVERAGE", "every subtopic with answerable content routes errors")

    routes = [g["route"] for _, b in blocks if b["type"] == "gap_map" for g in b["rows"]]
    empty = [r for r in routes if not r.strip()]
    add("BLOCK" if empty else "PASS", "SRU-26 PREREQUISITE_ROUTED",
        f"{len(empty)} gap rows name no destination" if empty else
        f"{len(routes)} gap rows, all name a destination")

    # --- G7 prerequisite checks name a destination ------------------------
    pres = [b for _, b in blocks if b["type"] == "prereq_check"]
    if band == "B30":
        add("BLOCK" if not pres else "PASS", "B30_PREREQ_REQUIRED",
            "B30 book with no prerequisite check" if not pres
            else f"{len(pres)} prerequisite checks present")

    # --- G8 figure placeholders -------------------------------------------
    figs = [b for _, b in blocks if b["type"] == "figure"]
    bad = [f["figure_id"] for f in figs
           if not f.get("semantic_spec") or not f.get("reserve_mm")]
    add("BLOCK" if bad else "PASS", "FIGURE_PLACEHOLDER_SPEC",
        f"incomplete placeholders: {bad}" if bad else
        f"{len(figs)} placeholders, all with reserved bounds and semantic spec")

    # --- G9 symbol drift (D2) ---------------------------------------------
    declared = set(meta["symbol_table"])
    add("PASS", "D2 SYMBOL_TABLE_FROZEN", f"{len(declared)} symbols declared: {sorted(declared)}")

    # --- PDF-side gates ----------------------------------------------------
    # Content frame in PDF points, excluding running head and footer chrome.
    # Measuring those as content is how a density gate reports >100% and passes
    # a page that is actually half empty.
    FRAME_TOP, FRAME_BOT = 56.0, 790.0
    with pdfplumber.open(pdf_path) as pdf:
        npages = len(pdf.pages)
        densities = []
        glyph_hits = []
        appendix_from = None
        for i, page in enumerate(pdf.pages):
            frame_h = FRAME_BOT - FRAME_TOP
            words = [w for w in (page.extract_words() or [])
                     if w["top"] >= FRAME_TOP and w["bottom"] <= FRAME_BOT]
            rects = [r for r in (page.rects or []) + (page.lines or [])
                     if r["top"] >= FRAME_TOP and r["bottom"] <= FRAME_BOT]
            # Union of occupied vertical bands: real voids are counted as voids.
            bands = sorted([(w["top"], w["bottom"]) for w in words] +
                           [(r["top"], r["bottom"]) for r in rects])
            merged, occupied = [], 0.0
            for a, b in bands:
                if merged and a <= merged[-1][1] + 4:      # 4pt = one leading gap
                    merged[-1][1] = max(merged[-1][1], b)
                else:
                    merged.append([a, b])
            for a, b in merged:
                occupied += (b - a)
            densities.append(min(occupied / frame_h, 1.0))
            txt = page.extract_text() or ""
            if "APPENDIX" in txt[:400] and appendix_from is None:
                appendix_from = i
            for ch in ("\ufffd", "\u25a0"):
                if ch in txt:
                    glyph_hits.append(i + 1)

    add("BLOCK" if glyph_hits else "PASS", "GLYPH_INTEGRITY",
        f"missing-glyph boxes on pages {glyph_hits}" if glyph_hits else
        f"no replacement or box glyphs across {npages} pages")

    # The density floor applies to ordinary learning pages. A cover and the
    # appendix ledger are neither, and counting them hides real voids elsewhere.
    end = appendix_from if appendix_from is not None else len(densities)
    learning = densities[1:end] if end > 1 else densities
    blank = [i + 2 for i, d in enumerate(learning) if d < 0.02]
    add("BLOCK" if blank else "PASS", "NO_BLANK_PAGES",
        f"empty pages: {blank}" if blank else "no empty pages")

    low = [round(d, 2) for d in learning if 0.02 <= d < 0.70]
    add("WARN" if low else "PASS", "PAGE_DENSITY_70_85",
        f"{len(low)} learning pages below floor: {low}" if low else
        f"{len(learning)} learning pages within band "
        f"(mean {sum(learning)/max(len(learning),1):.0%})")

    add("PASS", "PAGE_COUNT", f"{npages} A4 pages")

    # --- report ------------------------------------------------------------
    w = max(len(r[1]) for r in rows)
    print(f"\nPHYSICS PUBLICATION AUDIT — {meta['publication_id']}  band={band}")
    print("=" * (w + 62))
    for level, gate, detail in rows:
        print(f"{level:<5}  {gate:<{w}}  {detail}")
    print("=" * (w + 62))
    blocks_failed = [r for r in rows if r[0] == "BLOCK"]
    warns = [r for r in rows if r[0] == "WARN"]
    print(f"{len(rows)} gates · {len(blocks_failed)} blocking · {len(warns)} warning")
    return 1 if blocks_failed else 0


if __name__ == "__main__":
    sys.exit(audit(sys.argv[1], sys.argv[2]))
