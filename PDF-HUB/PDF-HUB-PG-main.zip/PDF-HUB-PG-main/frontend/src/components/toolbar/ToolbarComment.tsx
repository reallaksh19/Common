import React from 'react';
import { Button } from '@/components/ui/Button';
import { Type, Highlighter, Underline, Stamp, Square, PenTool, MessageSquare } from 'lucide-react';
import { Tooltip } from '@/components/ui/Tooltip';
import { useEditorStore } from '@/core/editor/store';

export const ToolbarComment: React.FC = () => {
  const { activeTool, setActiveTool } = useEditorStore();

  const getVariant = (toolName: string) => activeTool === toolName ? 'secondary' : 'ghost';

  return (
    <div className="flex items-center space-x-1 border-r border-slate-200 dark:border-slate-800 pr-2 mr-2">
      <Tooltip content="Text Box">
        <Button data-testid="toolbar-btn-textbox" variant={getVariant('textBox')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('textBox')}>
          <Type className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Highlight">
        <Button variant={getVariant('highlight')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('highlight')}>
          <Highlighter className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Underline">
        <Button variant={getVariant('underline')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('underline')}>
          <Underline className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Stamp">
        <Button variant={getVariant('stamp')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('stamp')}>
          <Stamp className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Shape">
        <Button variant={getVariant('shape')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('shape')}>
          <Square className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Draw">
        <Button variant={getVariant('freehand')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('freehand')}>
          <PenTool className="w-4 h-4" />
        </Button>
      </Tooltip>
      <Tooltip content="Note">
        <Button variant={getVariant('comment')} size="icon" className="h-8 w-8" onClick={() => setActiveTool('comment')}>
          <MessageSquare className="w-4 h-4" />
        </Button>
      </Tooltip>
    </div>
  );
};
