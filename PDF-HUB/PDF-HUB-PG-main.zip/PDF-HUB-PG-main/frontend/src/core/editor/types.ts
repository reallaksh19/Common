export type ActiveTool = 'select' | 'hand' | 'textBox' | 'highlight' | 'underline' | 'stamp' | 'shape' | 'freehand' | 'comment';

export interface EditorState {
  activeTool: ActiveTool;
  sidebarTab: string;
  inspectorTab: string;
  leftPanelWidth: number;
  rightPanelWidth: number;
}
