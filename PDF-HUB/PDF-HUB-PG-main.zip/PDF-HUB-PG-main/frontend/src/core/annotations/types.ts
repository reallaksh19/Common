export type AnnotationType = 'textBox' | 'highlight' | 'underline' | 'stamp' | 'shape' | 'freehand' | 'comment';

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PdfAnnotation {
  id: string;
  type: AnnotationType;
  pageNumber: number;
  rect: Rect;
  content?: string;
  style?: Record<string, unknown>;
  createdAt: string;
}
